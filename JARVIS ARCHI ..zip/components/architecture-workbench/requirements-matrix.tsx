'use client';

import React, { useState } from 'react';
import { MASTER_REQUIREMENTS_LIST, MasterRequirement } from '@/lib/rfc-data';
import { Shield, Filter, Search, CheckCircle2, ChevronRight, Lock } from 'lucide-react';

export function RequirementsMatrix({ onSelectRfc }: { onSelectRfc?: (rfcId: string) => void }) {
  const [search, setSearch] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedPriority, setSelectedPriority] = useState<string>('ALL');

  const categories = ['ALL', 'Core', 'Security', 'Windows', 'Reliability', 'Storage', 'Simulation', 'Extensibility', 'AI', 'Voice', 'Vision', 'Memory', 'Browser', 'Deployment'];

  const filteredRequirements = MASTER_REQUIREMENTS_LIST.filter((req) => {
    const matchesCat = selectedCategory === 'ALL' || req.category === selectedCategory;
    const matchesPri = selectedPriority === 'ALL' || req.priority === selectedPriority;
    const matchesSearch =
      req.id.toLowerCase().includes(search.toLowerCase()) ||
      req.title.toLowerCase().includes(search.toLowerCase()) ||
      req.statement.toLowerCase().includes(search.toLowerCase()) ||
      req.rfcMapping.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesPri && matchesSearch;
  });

  return (
    <div className="bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
      <div className="border-b border-border/60 pb-4">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-primary text-primary-foreground">
            Traceability Matrix
          </span>
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Baseline v1.3.0 &bull; 59 Master Requirements &bull; 15 RFCs
          </span>
        </div>
        <h3 className="text-lg font-bold text-foreground mt-1">
          Master Requirements to RFC Architectural Mapping
        </h3>
        <p className="text-xs text-muted-foreground mt-1">
          Every requirement in the v1.3.0 baseline is strictly bound to an architectural RFC decision, concrete security implication, and testable verification method.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-6">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by ID, keyword, RFC (e.g. REQ-CORE-005, RFC-009)..."
            className="w-full text-xs bg-background border border-input rounded-lg px-3 py-2 font-mono"
          />
        </div>
        <div className="md:col-span-4 flex flex-wrap gap-1">
          {['ALL', 'Core', 'Security', 'Windows', 'Reliability', 'Extensibility', 'AI'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-[11px] px-2 py-1 rounded-md transition-colors ${
                selectedCategory === cat
                  ? 'bg-primary text-primary-foreground font-medium'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="md:col-span-2 text-right">
          <span className="text-xs font-mono text-muted-foreground">
            Showing {filteredRequirements.length} of {MASTER_REQUIREMENTS_LIST.length}
          </span>
        </div>
      </div>

      {/* Requirements Table */}
      <div className="border border-border/60 rounded-xl overflow-hidden bg-background">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-muted/60 text-muted-foreground font-mono text-[11px] border-b border-border/50">
              <tr>
                <th className="p-3">Req ID</th>
                <th className="p-3">Priority</th>
                <th className="p-3">Title & Requirement Statement</th>
                <th className="p-3">Security Implication</th>
                <th className="p-3">Verification</th>
                <th className="p-3">RFC Mapping</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40 font-sans">
              {filteredRequirements.map((req) => (
                <tr key={req.id} className="hover:bg-muted/20 transition-colors">
                  <td className="p-3 font-mono font-bold text-primary whitespace-nowrap">
                    {req.id}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    <span className="font-mono text-[10px] px-2 py-0.5 rounded-full font-bold bg-secondary text-secondary-foreground border border-border/40">
                      {req.priority}
                    </span>
                  </td>
                  <td className="p-3 max-w-sm">
                    <div className="font-semibold text-foreground">{req.title}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5 line-clamp-2">
                      {req.statement}
                    </div>
                  </td>
                  <td className="p-3 text-[11px] text-muted-foreground max-w-xs">
                    {req.securityImplications}
                  </td>
                  <td className="p-3 text-[11px] font-mono text-foreground/80 whitespace-nowrap">
                    {req.verificationMethod}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    {onSelectRfc ? (
                      <button
                        onClick={() => onSelectRfc(req.rfcMapping)}
                        className="font-mono text-xs font-semibold px-2.5 py-1 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors border border-primary/20 inline-flex items-center gap-1"
                      >
                        {req.rfcMapping}
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    ) : (
                      <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-muted text-foreground">
                        {req.rfcMapping}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
