'use client';

import React, { useState } from 'react';
import { RFCS_DATA, RFCRecord } from '@/lib/rfc-data';
import { 
  Shield, 
  Cpu, 
  Lock, 
  RefreshCw, 
  FileCheck, 
  Terminal, 
  Smartphone, 
  Layers, 
  Database, 
  Key, 
  CheckCircle2, 
  AlertCircle,
  Copy,
  Check,
  ChevronRight,
  Code2,
  ExternalLink
} from 'lucide-react';

export function RfcExplorer({ onSelectSimulator }: { onSelectSimulator?: (simId: string) => void }) {
  const [selectedRfcId, setSelectedRfcId] = useState<string>('RFC-001');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const categories = ['ALL', 'Core', 'Security', 'Windows', 'Reliability', 'Storage', 'Simulation', 'Extensibility', 'Android', 'Browser'];

  const filteredRfcs = RFCS_DATA.filter((rfc) => {
    const matchesCategory = selectedCategory === 'ALL' || rfc.category === selectedCategory;
    const matchesSearch = 
      rfc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rfc.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rfc.problemStatement.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rfc.impactedRequirements.some(req => req.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const activeRfc = RFCS_DATA.find((r) => r.id === selectedRfcId) || RFCS_DATA[0];

  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getSimIdForRfc = (rfcId: string): string | null => {
    switch (rfcId) {
      case 'RFC-004': return 'state-machine';
      case 'RFC-006': return 'taint-lattice';
      case 'RFC-007': return 'confirmation';
      case 'RFC-009': return 'fencing';
      case 'RFC-010': return 'audit-chain';
      default: return null;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Sidebar List */}
      <div className="lg:col-span-4 space-y-4">
        {/* Filters */}
        <div className="bg-card border border-border/60 rounded-xl p-4 shadow-xs space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider block mb-1.5">
              Search RFCs & Requirements
            </label>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by RFC, title, req ID (e.g. REQ-CORE-005)..."
              className="w-full text-sm bg-background border border-input rounded-lg px-3 py-2 focus:outline-hidden focus:ring-1 focus:ring-primary"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider block mb-1.5">
              Filter Category
            </label>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs px-2.5 py-1 rounded-md transition-colors ${
                    selectedCategory === cat
                      ? 'bg-primary text-primary-foreground font-medium'
                      : 'bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* RFC List */}
        <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
          {filteredRfcs.map((rfc) => {
            const isSelected = rfc.id === selectedRfcId;
            return (
              <button
                key={rfc.id}
                onClick={() => setSelectedRfcId(rfc.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-primary/5 border-primary/40 shadow-xs ring-1 ring-primary/30'
                    : 'bg-card border-border/60 hover:border-border hover:bg-muted/30'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground border border-border/40">
                      {rfc.id}
                    </span>
                    <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">
                      Q{rfc.questionNumber}
                    </span>
                  </div>
                  <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                    {rfc.status}
                  </span>
                </div>

                <div className="font-medium text-sm text-foreground line-clamp-1 mb-1">
                  {rfc.title}
                </div>

                <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                  {rfc.architecturalDecision}
                </p>

                <div className="flex flex-wrap gap-1">
                  {rfc.impactedRequirements.slice(0, 3).map((req) => (
                    <span
                      key={req}
                      className="font-mono text-[10px] px-1.5 py-0.5 rounded-xs bg-muted text-muted-foreground border border-border/30"
                    >
                      {req}
                    </span>
                  ))}
                  {rfc.impactedRequirements.length > 3 && (
                    <span className="text-[10px] text-muted-foreground px-1 py-0.5">
                      +{rfc.impactedRequirements.length - 3}
                    </span>
                  )}
                </div>
              </button>
            );
          })}

          {filteredRfcs.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border/80 rounded-xl">
              No RFC specifications match your query.
            </div>
          )}
        </div>
      </div>

      {/* Main Detail View */}
      <div className="lg:col-span-8 bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
        {/* Header */}
        <div className="border-b border-border/60 pb-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2.5">
              <span className="font-mono text-sm font-bold px-2.5 py-1 rounded-lg bg-primary text-primary-foreground">
                {activeRfc.id}
              </span>
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-2 py-1 bg-muted rounded-md border border-border/40">
                Architectural Question #{activeRfc.questionNumber}
              </span>
              <span className="text-xs font-semibold tracking-wider uppercase px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                {activeRfc.status}
              </span>
            </div>

            {getSimIdForRfc(activeRfc.id) && onSelectSimulator && (
              <button
                onClick={() => onSelectSimulator(getSimIdForRfc(activeRfc.id)!)}
                className="inline-flex items-center gap-1.5 text-xs font-medium bg-primary/10 text-primary hover:bg-primary/20 px-3 py-1.5 rounded-lg border border-primary/30 transition-colors"
              >
                Launch Live Simulator
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <h2 className="text-xl font-bold text-foreground tracking-tight">
            {activeRfc.title}
          </h2>
          <p className="text-sm text-muted-foreground mt-1 font-mono">
            Category: {activeRfc.category} &bull; Binding Baseline v1.3.0
          </p>
        </div>

        {/* Requirements Impacted */}
        <div>
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
            Binding Master Requirements Covered
          </h3>
          <div className="flex flex-wrap gap-2">
            {activeRfc.impactedRequirements.map((req) => (
              <span
                key={req}
                className="font-mono text-xs px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground border border-border/50 font-medium"
              >
                {req}
              </span>
            ))}
          </div>
        </div>

        {/* Problem Statement */}
        <div className="bg-muted/30 border border-border/60 rounded-xl p-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
            Problem Statement & Architectural Tension
          </h3>
          <p className="text-sm text-foreground/90 leading-relaxed">
            {activeRfc.problemStatement}
          </p>
        </div>

        {/* Architectural Decision */}
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
          <h3 className="text-xs font-semibold text-primary uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
            Approved Architectural Decision & Invariant
          </h3>
          <p className="text-sm font-medium text-foreground leading-relaxed">
            {activeRfc.architecturalDecision}
          </p>
        </div>

        {/* Key Mechanisms & Guarantees Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border border-border/60 rounded-xl p-4 bg-card/60">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-primary" />
              Core Mechanics & Protocols
            </h4>
            <div className="text-xs text-muted-foreground mb-2 font-mono bg-muted/60 p-1.5 rounded-sm">
              {activeRfc.technicalDetails.protocolOrFormat}
            </div>
            <ul className="space-y-1.5 text-xs text-foreground/80">
              {activeRfc.technicalDetails.keyMechanisms.map((mech, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-primary mt-0.5">•</span>
                  <span>{mech}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="border border-border/60 rounded-xl p-4 bg-card/60">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-500" />
              Security Guarantees & Verification
            </h4>
            <ul className="space-y-1.5 text-xs text-foreground/80 mb-3">
              {activeRfc.technicalDetails.securityGuarantees.map((guar, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-emerald-500 mt-0.5">✓</span>
                  <span>{guar}</span>
                </li>
              ))}
            </ul>
            <div className="border-t border-border/40 pt-2 text-[11px] text-muted-foreground">
              <span className="font-semibold text-foreground">Verification: </span>
              {activeRfc.technicalDetails.verificationMethod}
            </div>
          </div>
        </div>

        {/* Code / Schema Section */}
        <div className="border border-border/60 rounded-xl overflow-hidden bg-muted/20">
          <div className="flex items-center justify-between px-4 py-2.5 bg-muted/60 border-b border-border/50 text-xs">
            <span className="font-mono text-muted-foreground flex items-center gap-1.5">
              <Code2 className="w-3.5 h-3.5 text-primary" />
              Technical Implementation Pattern / Prototype
            </span>
            <button
              onClick={() => handleCopyCode(activeRfc.sampleCodeOrSchema)}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-sm text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 font-mono text-xs overflow-x-auto text-foreground/90 leading-relaxed">
            {activeRfc.sampleCodeOrSchema}
          </pre>
        </div>
      </div>
    </div>
  );
}
