'use client';

import React, { useState, useEffect } from 'react';
import { computeSha256, AuditBlock } from '@/lib/simulators';
import { Database, ShieldCheck, AlertOctagon, Plus, RefreshCw, Lock, Terminal, ShieldAlert } from 'lucide-react';

const INITIAL_GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

export function AuditChainVerifier() {
  const [blocks, setBlocks] = useState<AuditBlock[]>([
    {
      seqNo: 0,
      timestamp: '2026-09-11T12:00:00Z',
      action: 'SYSTEM_GENESIS_BOOT',
      actor: 'NT SERVICE\\JarvisCore',
      prevHash: INITIAL_GENESIS_HASH,
      currentHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    },
    {
      seqNo: 1,
      timestamp: '2026-09-11T12:00:01Z',
      action: 'AUTHENTICATE_POLICY_ED25519',
      actor: 'JarvisSecurityBroker',
      prevHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      currentHash: '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    },
  ]);

  const [tpmAnchorHash, setTpmAnchorHash] = useState<string>('7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069');
  const [newActionName, setNewActionName] = useState<string>('CONFIRMATION_GRANTED_HIGH_RISK');
  const [tamperedIndex, setTamperedIndex] = useState<number | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<'VALID' | 'TAMPERED' | 'TRUNCATED'>('VALID');

  // Verify full chain integrity against TPM anchor
  const handleVerifyChain = async () => {
    let prev = INITIAL_GENESIS_HASH;

    for (let i = 0; i < blocks.length; i++) {
      const b = blocks[i];
      if (b.prevHash !== prev) {
        setTamperedIndex(i);
        setVerificationStatus('TAMPERED');
        return;
      }

      // Recompute hash
      const payloadString = `${b.prevHash}|${b.seqNo}|${b.timestamp}|${b.action}|${b.actor}`;
      const recomputed = await computeSha256(payloadString);

      if (b.currentHash !== recomputed) {
        setTamperedIndex(i);
        setVerificationStatus('TAMPERED');
        return;
      }
      prev = b.currentHash;
    }

    // Check against independent TPM 2.0 / Registry Anchor (REQ-DEP-002b)
    const latestBlock = blocks[blocks.length - 1];
    if (latestBlock.currentHash !== tpmAnchorHash) {
      setVerificationStatus('TRUNCATED');
      return;
    }

    setTamperedIndex(null);
    setVerificationStatus('VALID');
  };

  const handleAppendBlock = async () => {
    const lastBlock = blocks[blocks.length - 1];
    const nextSeq = lastBlock.seqNo + 1;
    const nowTimestamp = new Date().toISOString();
    const prevHash = lastBlock.currentHash;

    const payloadString = `${prevHash}|${nextSeq}|${nowTimestamp}|${newActionName}|Worker_Process_7f`;
    const newHash = await computeSha256(payloadString);

    const newBlock: AuditBlock = {
      seqNo: nextSeq,
      timestamp: nowTimestamp,
      action: newActionName,
      actor: 'Worker_Process_7f',
      prevHash,
      currentHash: newHash,
    };

    const nextBlocks = [...blocks, newBlock];
    setBlocks(nextBlocks);
    setTpmAnchorHash(newHash); // TPM PCR-15 is extended
    setTamperedIndex(null);
    setVerificationStatus('VALID');
  };

  // Simulate Attack 1: Modify past block content
  const handleSimulateTamper = (index: number) => {
    const updated = [...blocks];
    updated[index] = {
      ...updated[index],
      action: 'MALICIOUS_UNLOGGED_FILE_DELETION',
      isTampered: true,
    };
    setBlocks(updated);
    setTamperedIndex(index);
    setVerificationStatus('TAMPERED');
  };

  // Simulate Attack 2: Truncate log to hide recent entries
  const handleSimulateTruncate = () => {
    if (blocks.length > 1) {
      const truncated = blocks.slice(0, blocks.length - 1);
      setBlocks(truncated);
      setVerificationStatus('TRUNCATED');
    }
  };

  const handleReset = async () => {
    const b0Hash = await computeSha256(`${INITIAL_GENESIS_HASH}|0|2026-09-11T12:00:00Z|SYSTEM_GENESIS_BOOT|NT SERVICE\\JarvisCore`);
    const b1Hash = await computeSha256(`${b0Hash}|1|2026-09-11T12:00:01Z|AUTHENTICATE_POLICY_ED25519|JarvisSecurityBroker`);

    const freshBlocks: AuditBlock[] = [
      {
        seqNo: 0,
        timestamp: '2026-09-11T12:00:00Z',
        action: 'SYSTEM_GENESIS_BOOT',
        actor: 'NT SERVICE\\JarvisCore',
        prevHash: INITIAL_GENESIS_HASH,
        currentHash: b0Hash,
      },
      {
        seqNo: 1,
        timestamp: '2026-09-11T12:00:01Z',
        action: 'AUTHENTICATE_POLICY_ED25519',
        actor: 'JarvisSecurityBroker',
        prevHash: b0Hash,
        currentHash: b1Hash,
      },
    ];

    setBlocks(freshBlocks);
    setTpmAnchorHash(b1Hash);
    setTamperedIndex(null);
    setVerificationStatus('VALID');
  };

  return (
    <div className="bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
      <div className="border-b border-border/60 pb-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-primary text-primary-foreground">
                RFC-010 Simulator
              </span>
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                REQ-DEP-002 &bull; REQ-DEP-002a &bull; REQ-DEP-002b
              </span>
            </div>
            <h3 className="text-lg font-bold text-foreground mt-1">
              Audit Log Merkle Hash-Chain & Hardware TPM Split-Anchor Verifier
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleVerifyChain}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors shadow-xs"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Run Full Boot Verification
            </button>
            <button
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-secondary text-secondary-foreground hover:bg-secondary/80 font-medium transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reset Chain
            </button>
          </div>
        </div>
      </div>

      {/* Split Anchor Display Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-muted/20 border border-border/60 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-500" />
              Independent TPM 2.0 PCR-15 Anchor
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              Hardware Bound
            </span>
          </div>
          <div className="font-mono text-[11px] text-foreground break-all bg-background p-2 rounded border border-border/40">
            {tpmAnchorHash}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Isolated outside file system; writable only via TPM2_PCR_Extend, preventing log writer from redefining root.
          </p>
        </div>

        <div className="bg-muted/20 border border-border/60 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-primary" />
              Chain Head Block Digest (Log File)
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-primary/10 text-primary">
              Block #{blocks[blocks.length - 1].seqNo}
            </span>
          </div>
          <div className="font-mono text-[11px] text-foreground break-all bg-background p-2 rounded border border-border/40">
            {blocks[blocks.length - 1].currentHash}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Matches TPM anchor when uncorrupted. Truncation or deletion immediately creates mismatch on boot.
          </p>
        </div>
      </div>

      {/* Verification Status Banner */}
      {verificationStatus === 'VALID' && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-medium flex items-center gap-2.5">
          <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-500" />
          <span>CRYPTOGRAPHIC VERIFICATION SUCCESS: All block hashes and previous hashes are contiguous, and head matches TPM 2.0 PCR-15 anchor.</span>
        </div>
      )}

      {verificationStatus === 'TAMPERED' && (
        <div className="p-3.5 rounded-xl bg-destructive/10 border border-destructive/30 text-destructive text-xs font-medium flex items-center gap-2.5">
          <AlertOctagon className="w-4 h-4 shrink-0" />
          <span>TAMPER DETECTED: Hash broken at block #{tamperedIndex}! Data was modified after signing. Core enters Halted_Requires_Inspection!</span>
        </div>
      )}

      {verificationStatus === 'TRUNCATED' && (
        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs font-medium flex items-center gap-2.5">
          <ShieldAlert className="w-4 h-4 shrink-0 text-amber-500" />
          <span>ROLLBACK/TRUNCATION DETECTED: Log head hash does not match independent TPM PCR-15 anchor! Trailing records were stripped.</span>
        </div>
      )}

      {/* Append New Block Controls */}
      <div className="bg-muted/30 border border-border/60 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <span className="text-xs text-muted-foreground font-mono">Next Event:</span>
          <input
            type="text"
            value={newActionName}
            onChange={(e) => setNewActionName(e.target.value)}
            className="flex-1 text-xs font-mono bg-background border border-input rounded px-3 py-1.5"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleAppendBlock}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Append Chained Block
          </button>
          <button
            onClick={handleSimulateTruncate}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-amber-600 text-white font-medium hover:bg-amber-700 transition-colors shadow-xs"
          >
            Simulate Truncation Attack
          </button>
        </div>
      </div>

      {/* Blocks Timeline / List */}
      <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
        {blocks.map((block, idx) => {
          const isTampered = block.isTampered || tamperedIndex === idx;
          return (
            <div
              key={block.seqNo}
              className={`p-3.5 rounded-xl border transition-all ${
                isTampered
                  ? 'bg-destructive/10 border-destructive/40 shadow-xs'
                  : 'bg-muted/20 border-border/60'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-secondary text-secondary-foreground">
                    Block #{block.seqNo}
                  </span>
                  <span className="text-xs font-mono text-foreground font-semibold">
                    {block.action}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-muted-foreground">{block.timestamp}</span>
                  {!isTampered && (
                    <button
                      onClick={() => handleSimulateTamper(idx)}
                      className="text-[10px] text-destructive hover:underline font-mono"
                    >
                      [Inject Tamper]
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] font-mono pt-1 text-muted-foreground">
                <div>PrevHash: <span className="text-foreground/80">{block.prevHash.substring(0, 24)}...</span></div>
                <div>CurrHash: <span className="text-primary font-bold">{block.currentHash.substring(0, 24)}...</span></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
