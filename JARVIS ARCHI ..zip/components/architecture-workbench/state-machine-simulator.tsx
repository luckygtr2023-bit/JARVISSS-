'use client';

import React, { useState } from 'react';
import { TaskLifecycleState, LEGAL_TRANSITIONS, TERMINAL_STATES } from '@/lib/simulators';
import { RotateCcw, AlertTriangle, CheckCircle2, ShieldAlert, Cpu, ArrowRight, Zap, RefreshCw } from 'lucide-react';

interface NodeReconciliation {
  nodeId: string;
  name: string;
  lastState: string;
  isIdempotent: boolean;
  sideEffectStatus: 'APPLIED' | 'UNAPPLIED' | 'INDETERMINATE';
  recommendation: 'SAFE_TO_RESUME' | 'SAFE_TO_RETRY' | 'SAFE_TO_ABANDON';
}

const ALL_STATES: TaskLifecycleState[] = [
  'Initiated',
  'Planning',
  'Awaiting_Confirmation',
  'Executing',
  'Verifying',
  'Completed',
  'Failed',
  'Cancelled',
  'Timed_Out',
  'Ambiguous_Uncertain',
  'Halted_Requires_Inspection',
];

export function StateMachineSimulator() {
  const [currentState, setCurrentState] = useState<TaskLifecycleState>('Initiated');
  const [transitionLog, setTransitionLog] = useState<string[]>([
    '[STATE MACHINE INITIALIZED] Task req_9x40a created in state: Initiated',
  ]);
  const [violationAlert, setViolationAlert] = useState<string | null>(null);
  const [reconciliationMatrix, setReconciliationMatrix] = useState<NodeReconciliation[] | null>(null);

  const addLog = (msg: string) => {
    setTransitionLog((prev) => [msg, ...prev.slice(0, 8)]);
  };

  const handleTransition = (targetState: TaskLifecycleState) => {
    setViolationAlert(null);
    setReconciliationMatrix(null);

    // Check if current state is terminal (REQ-CORE-002a)
    if (TERMINAL_STATES.includes(currentState)) {
      setViolationAlert(
        `VIOLATION OF REQ-CORE-002a: Current state "${currentState}" is STRICTLY TERMINAL. State resurrection or transition out is cryptographically and logically prohibited!`
      );
      addLog(`[REJECTED TRANSITION] Illegal move from terminal state ${currentState} -> ${targetState}`);
      return;
    }

    const legalTargets = LEGAL_TRANSITIONS[currentState] || [];
    if (!legalTargets.includes(targetState)) {
      setViolationAlert(
        `ILLEGAL TRANSITION: The transition "${currentState}" -> "${targetState}" is not defined in the deterministic 11-state table.`
      );
      addLog(`[ILLEGAL TRANSITION] Blocked attempt to transition ${currentState} -> ${targetState}`);
      return;
    }

    // Apply legal transition
    setCurrentState(targetState);
    addLog(`[WAL FSYNC] State transition committed: ${currentState} -> ${targetState}`);
  };

  // Simulate Sudden Crash / Power Outage (REQ-REL-003)
  const handleSimulateCrash = () => {
    setViolationAlert(null);
    if (TERMINAL_STATES.includes(currentState)) {
      addLog(`[CRASH SIMULATION] System rebooted. Task was already in terminal state "${currentState}". No reconciliation required.`);
      return;
    }

    // Ungraceful restart recovers all non-terminal tasks to Halted_Requires_Inspection
    setCurrentState('Halted_Requires_Inspection');
    addLog(`[KERNEL PANIC] Power outage simulated! Ungraceful restart initiated.`);
    addLog(`[RECOVERY WAL] REQ-REL-003: Task was in non-terminal state. Transitioned unconditionally to Halted_Requires_Inspection.`);

    // Build per-node reconciliation summary (REQ-REL-003a)
    const matrix: NodeReconciliation[] = [
      {
        nodeId: 'node_01',
        name: 'Validate Auth Token',
        lastState: 'Completed',
        isIdempotent: true,
        sideEffectStatus: 'UNAPPLIED',
        recommendation: 'SAFE_TO_RESUME',
      },
      {
        nodeId: 'node_02',
        name: 'Prepare Workspace Directory',
        lastState: 'Executing',
        isIdempotent: true,
        sideEffectStatus: 'APPLIED',
        recommendation: 'SAFE_TO_RETRY',
      },
      {
        nodeId: 'node_03',
        name: 'Dispatch Payment Transaction',
        lastState: 'Unstarted',
        isIdempotent: false,
        sideEffectStatus: 'UNAPPLIED',
        recommendation: 'SAFE_TO_ABANDON',
      },
    ];

    setReconciliationMatrix(matrix);
    addLog(`[RECONCILIATION] REQ-REL-003a: Generated per-node inspection matrix. Auto-resumption blocked.`);
  };

  const handleReset = () => {
    setCurrentState('Initiated');
    setViolationAlert(null);
    setReconciliationMatrix(null);
    setTransitionLog(['[RESET] State machine reset to Initiated']);
  };

  return (
    <div className="bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
      <div className="border-b border-border/60 pb-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-primary text-primary-foreground">
                RFC-004 Simulator
              </span>
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                REQ-CORE-002 &bull; REQ-CORE-002a &bull; REQ-REL-003 &bull; REQ-REL-003a
              </span>
            </div>
            <h3 className="text-lg font-bold text-foreground mt-1">
              Crash-Safe 11-State Machine & WAL Recovery Engine
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSimulateCrash}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-destructive text-destructive-foreground hover:bg-destructive/90 font-medium transition-colors shadow-xs"
            >
              <Zap className="w-3.5 h-3.5" />
              Simulate Sudden Power Cut / Crash
            </button>
            <button
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-secondary text-secondary-foreground hover:bg-secondary/80 font-medium transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* 11 States Visual Grid */}
      <div>
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
          Lifecycle State Space (Active State Highlighted)
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {ALL_STATES.map((state) => {
            const isActive = state === currentState;
            const isTerminal = TERMINAL_STATES.includes(state);
            const isLegalNext = (LEGAL_TRANSITIONS[currentState] || []).includes(state);

            return (
              <button
                key={state}
                onClick={() => handleTransition(state)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  isActive
                    ? 'bg-primary text-primary-foreground font-bold shadow-sm ring-2 ring-primary/40'
                    : isLegalNext
                    ? 'bg-primary/5 border-primary/40 hover:bg-primary/10 text-foreground'
                    : 'bg-muted/30 border-border/40 text-muted-foreground hover:bg-muted/60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono uppercase tracking-wider">
                    {isTerminal ? 'Terminal' : 'Active'}
                  </span>
                  {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-primary-foreground" />}
                </div>
                <div className="text-xs font-medium truncate">{state}</div>
                {isLegalNext && !isActive && (
                  <div className="text-[10px] text-primary flex items-center gap-0.5 mt-1 font-mono">
                    <ArrowRight className="w-2.5 h-2.5" /> Legal Next
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Violation Alert Banner */}
      {violationAlert && (
        <div className="p-3.5 rounded-xl bg-destructive/10 border border-destructive/30 text-destructive text-xs font-medium flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{violationAlert}</span>
        </div>
      )}

      {/* Post-Crash Reconciliation Matrix (REQ-REL-003a) */}
      {reconciliationMatrix && (
        <div className="bg-muted/20 border border-primary/20 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-primary" />
              Post-Crash Reconciliation Manifest (REQ-REL-003a)
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-primary/10 text-primary">
              Manual Inspection Required &bull; Auto-Resume Inhibited
            </span>
          </div>

          <div className="border border-border/50 rounded-lg overflow-hidden bg-background">
            <table className="w-full text-xs text-left">
              <thead className="bg-muted/60 text-muted-foreground font-mono text-[11px] border-b border-border/50">
                <tr>
                  <th className="p-2.5">Node ID</th>
                  <th className="p-2.5">Action Name</th>
                  <th className="p-2.5">Prior State</th>
                  <th className="p-2.5">Side-Effect Status</th>
                  <th className="p-2.5">Core Recommendation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40 font-mono text-[11px]">
                {reconciliationMatrix.map((rec) => (
                  <tr key={rec.nodeId} className="hover:bg-muted/20">
                    <td className="p-2.5 font-bold text-primary">{rec.nodeId}</td>
                    <td className="p-2.5 font-sans text-foreground">{rec.name}</td>
                    <td className="p-2.5 text-muted-foreground">{rec.lastState}</td>
                    <td className="p-2.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                        rec.sideEffectStatus === 'APPLIED' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400' : 'bg-muted text-muted-foreground'
                      }`}>
                        {rec.sideEffectStatus}
                      </span>
                    </td>
                    <td className="p-2.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        rec.recommendation === 'SAFE_TO_RESUME'
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : rec.recommendation === 'SAFE_TO_RETRY'
                          ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                          : 'bg-destructive/10 text-destructive'
                      }`}>
                        {rec.recommendation}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Transactional Write-Ahead Log Display */}
      <div className="bg-background border border-border/60 rounded-xl p-4 space-y-2">
        <span className="text-xs font-semibold text-muted-foreground font-mono block">
          Append-Only Write-Ahead Log (WAL) Journal Trace
        </span>
        <div className="font-mono text-[11px] bg-muted/60 p-3 rounded-lg space-y-1 text-foreground/90 max-h-36 overflow-y-auto border border-border/40">
          {transitionLog.map((log, idx) => (
            <div key={idx} className={log.includes('REJECTED') || log.includes('ILLEGAL') ? 'text-destructive font-bold' : log.includes('FSYNC') ? 'text-emerald-500' : ''}>
              {log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
