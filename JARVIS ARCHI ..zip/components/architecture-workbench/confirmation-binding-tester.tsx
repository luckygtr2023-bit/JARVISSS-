'use client';

import React, { useState, useEffect } from 'react';
import { computeHmacSha256, computeSha256 } from '@/lib/simulators';
import { ShieldAlert, CheckCircle2, XCircle, Clock, Key, Lock, RefreshCw, AlertTriangle } from 'lucide-react';

export function ConfirmationBindingTester() {
  const [requestId, setRequestId] = useState<string>('req_2026_9x40a');
  const [toolId, setToolId] = useState<string>('com.jarvis.cloud.deploy_production');
  const [targetResource, setTargetResource] = useState<string>('cloud:prod:cluster-us-east');
  const [paramPayload, setParamPayload] = useState<string>('{"replicas": 5, "image": "v1.3.0"}');
  
  // Secret management
  const [secretName, setSecretName] = useState<string>('PROD_KUBE_TOKEN');
  const [rawSecretValue, setRawSecretValue] = useState<string>('sk_live_9941a80f2b3149e8');
  
  // Generated state
  const [sessionKey, setSessionKey] = useState<string>('host_session_key_9f3b81');
  const [nonce, setNonce] = useState<string>('nonce_849201');
  const [digest, setDigest] = useState<string>('');
  const [secretFingerprint, setSecretFingerprint] = useState<string>('');
  const [expiresIn, setExpiresIn] = useState<number>(60);
  const [isExpired, setIsExpired] = useState<boolean>(false);
  
  // Tamper testing state
  const [tamperedParam, setTamperedParam] = useState<string>('{"replicas": 5, "image": "v1.3.0"}');
  const [verificationResult, setVerificationResult] = useState<'IDLE' | 'SUCCESS' | 'TAMPER_DETECTED' | 'EXPIRED'>('IDLE');

  // Compute digests on changes
  useEffect(() => {
    async function updateDigest() {
      // 1. Compute non-invertible secret fingerprint
      const secretFp = await computeSha256(`salt_2026_${secretName}_${rawSecretValue}`);
      const maskedFp = secretFp.substring(0, 10);
      setSecretFingerprint(maskedFp);

      // 2. Canonical parameter string including secret fingerprint contribution
      const canonical = `${paramPayload}::secret_fp=${maskedFp}`;
      const paramHash = await computeSha256(canonical);
      const resourceHash = await computeSha256(targetResource);

      // 3. Compute RFC-007 HMAC digest
      const messageToSign = `${requestId}|${toolId}|${paramHash}|${resourceHash}|${nonce}`;
      const computed = await computeHmacSha256(sessionKey, messageToSign);
      setDigest(computed);
      setTamperedParam(paramPayload);
      setVerificationResult('IDLE');
    }

    updateDigest();
  }, [requestId, toolId, targetResource, paramPayload, secretName, rawSecretValue, sessionKey, nonce]);

  // Countdown timer
  useEffect(() => {
    if (expiresIn <= 0) {
      setIsExpired(true);
      return;
    }
    const timer = setInterval(() => {
      setExpiresIn((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [expiresIn]);

  const handleResetChallenge = () => {
    const newNonce = 'nonce_' + Math.floor(Math.random() * 900000 + 100000);
    setNonce(newNonce);
    setExpiresIn(60);
    setIsExpired(false);
    setVerificationResult('IDLE');
  };

  const handleTestVerification = async () => {
    if (isExpired) {
      setVerificationResult('EXPIRED');
      return;
    }

    // Recompute digest based on whatever parameters are in the test response
    const secretFp = await computeSha256(`salt_2026_${secretName}_${rawSecretValue}`);
    const maskedFp = secretFp.substring(0, 10);
    const testCanonical = `${tamperedParam}::secret_fp=${maskedFp}`;
    const testParamHash = await computeSha256(testCanonical);
    const testResourceHash = await computeSha256(targetResource);

    const testMessage = `${requestId}|${toolId}|${testParamHash}|${testResourceHash}|${nonce}`;
    const recomputedDigest = await computeHmacSha256(sessionKey, testMessage);

    if (recomputedDigest === digest) {
      setVerificationResult('SUCCESS');
    } else {
      setVerificationResult('TAMPER_DETECTED');
    }
  };

  return (
    <div className="bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
      <div className="border-b border-border/60 pb-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-primary text-primary-foreground">
                RFC-007 Simulator
              </span>
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                REQ-CORE-004 &bull; REQ-SEC-007 &bull; REQ-SEC-008
              </span>
            </div>
            <h3 className="text-lg font-bold text-foreground mt-1">
              Cryptographic Confirmation Binding & Secret Obfuscation Engine
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono font-medium border ${
              isExpired ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-muted text-foreground border-border/60'
            }`}>
              <Clock className="w-3.5 h-3.5" />
              <span>{isExpired ? 'EXPIRED (Cancelled)' : `Expires in: ${expiresIn}s`}</span>
            </div>
            <button
              onClick={handleResetChallenge}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              New Challenge
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left Column: Authoritative Operation Inputs */}
        <div className="space-y-4">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-primary" />
            1. Core Authoritative Operation Payload
          </h4>

          <div>
            <label className="text-xs text-muted-foreground font-mono block mb-1">Request ID (Core Owned)</label>
            <input
              type="text"
              value={requestId}
              onChange={(e) => setRequestId(e.target.value)}
              className="w-full text-xs font-mono bg-background border border-input rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground font-mono block mb-1">Tool Manifest ID</label>
            <input
              type="text"
              value={toolId}
              onChange={(e) => setToolId(e.target.value)}
              className="w-full text-xs font-mono bg-background border border-input rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground font-mono block mb-1">Target Resource Key</label>
            <input
              type="text"
              value={targetResource}
              onChange={(e) => setTargetResource(e.target.value)}
              className="w-full text-xs font-mono bg-background border border-input rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground font-mono block mb-1">Non-Secret Parameters (JSON)</label>
            <textarea
              rows={2}
              value={paramPayload}
              onChange={(e) => setParamPayload(e.target.value)}
              className="w-full text-xs font-mono bg-background border border-input rounded-lg px-3 py-2"
            />
          </div>

          <div className="bg-muted/40 p-3 rounded-lg border border-border/50 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-foreground">
              <Key className="w-3.5 h-3.5 text-amber-500" />
              Secret Parameter Handling (REQ-SEC-008)
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] text-muted-foreground block">Secret Identifier / Name</span>
                <input
                  type="text"
                  value={secretName}
                  onChange={(e) => setSecretName(e.target.value)}
                  className="w-full text-xs font-mono bg-background border border-input rounded px-2 py-1 mt-0.5"
                />
              </div>
              <div>
                <span className="text-[10px] text-muted-foreground block">Raw Secret (Kept in Host Vault)</span>
                <input
                  type="password"
                  value={rawSecretValue}
                  onChange={(e) => setRawSecretValue(e.target.value)}
                  className="w-full text-xs font-mono bg-background border border-input rounded px-2 py-1 mt-0.5"
                />
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Raw secret is strictly isolated in OS credential store. UI receives only the non-invertible token identifier.
            </p>
          </div>
        </div>

        {/* Right Column: Confirmation Presentation & Digest */}
        <div className="space-y-4">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-emerald-500" />
            2. Confirmation Display & Cryptographic Digest
          </h4>

          {/* User Confirmation Card Mockup */}
          <div className="bg-muted/20 border border-primary/20 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-border/40 pb-2">
              <span className="text-xs font-bold text-foreground">Pending Human Confirmation</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-primary/10 text-primary">
                HIGH_RISK_SIDE_EFFECT
              </span>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Operation:</span>
                <span className="font-mono text-foreground font-medium">{toolId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Resource:</span>
                <span className="font-mono text-foreground">{targetResource}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Protected Secret:</span>
                <span className="font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-semibold">
                  [Vault: &quot;{secretName}&quot; (FP: #{secretFingerprint})]
                </span>
              </div>
              <div className="text-[11px] text-muted-foreground italic pt-1">
                Notice: Zero partial secret exposure (no last-N characters) preventing oracle attacks.
              </div>
            </div>
          </div>

          {/* Cryptographic Digest Display */}
          <div className="bg-background border border-border/60 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground font-mono">HMAC-SHA256 Operation Digest</span>
              <span className="text-[10px] font-mono text-muted-foreground">Nonce: {nonce}</span>
            </div>
            <div className="font-mono text-[11px] bg-muted/60 p-2.5 rounded-lg text-primary break-all border border-border/40">
              {digest || 'Computing...'}
            </div>
          </div>

          {/* Tamper Simulation Section */}
          <div className="bg-muted/30 border border-border/60 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                Simulate UI-Layer Tampering / MITM
              </span>
              <button
                onClick={() => setTamperedParam('{"replicas": 999, "image": "malicious:v2"}')}
                className="text-[10px] text-destructive hover:underline font-mono"
              >
                Inject Malicious Param
              </button>
            </div>

            <textarea
              rows={2}
              value={tamperedParam}
              onChange={(e) => setTamperedParam(e.target.value)}
              className="w-full text-xs font-mono bg-background border border-input rounded-lg px-2.5 py-1.5"
            />

            <button
              onClick={handleTestVerification}
              className="w-full py-2 px-4 rounded-lg bg-primary text-primary-foreground font-medium text-xs hover:bg-primary/90 transition-colors shadow-xs"
            >
              Verify User Confirmation Response
            </button>

            {verificationResult === 'SUCCESS' && (
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-medium">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Confirmation Valid: Parameters verified against Core HMAC digest. Authorized for execution.</span>
              </div>
            )}

            {verificationResult === 'TAMPER_DETECTED' && (
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-xs font-medium">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>SECURITY VIOLATION DETECTED: Tampered parameters do not match HMAC digest. Request rejected!</span>
              </div>
            )}

            {verificationResult === 'EXPIRED' && (
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-medium">
                <Clock className="w-4 h-4 shrink-0" />
                <span>CONFIRMATION EXPIRED (REQ-SEC-007a): Request transitioned to Cancelled, not Approved.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
