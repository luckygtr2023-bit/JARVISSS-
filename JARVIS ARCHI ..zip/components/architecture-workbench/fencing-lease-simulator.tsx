'use client';

import React, { useState } from 'react';
import { Shield, Clock, AlertOctagon, CheckCircle2, XCircle, RotateCcw, Lock, Unlock, Cpu } from 'lucide-react';

export function FencingLeaseSimulator() {
  const [resourceKey, setResourceKey] = useState<string>('fs:workspace:production_db.sqlite');
  const [currentEpoch, setCurrentEpoch] = useState<number>(101);
  const [activeWorkerPid, setActiveWorkerPid] = useState<number | null>(8492);
  const [workerTicketEpoch, setWorkerTicketEpoch] = useState<number>(101);
  const [resourceState, setResourceState] = useState<'ACQUIRED' | 'RELEASED' | 'AMBIGUOUS_HOLD'>('ACQUIRED');
  const [isToolIdempotent, setIsToolIdempotent] = useState<boolean>(false);
  const [isWorkerResponsive, setIsWorkerResponsive] = useState<boolean>(false);
  const [logEvents, setLogEvents] = useState<string[]>([
    '[INIT] Resource lock acquired for fs:workspace:production_db.sqlite',
    '[LEASE] Issued capability lease: Epoch=101, WorkerPID=8492, Expiry=5000ms',
  ]);

  const addLog = (msg: string) => {
    setLogEvents((prev) => [msg, ...prev.slice(0, 7)]);
  };

  // Scenario 1: Worker normal commit
  const handleWorkerCommit = () => {
    if (workerTicketEpoch !== currentEpoch) {
      addLog(`[REJECTED] Stale Worker PID=${activeWorkerPid} attempted write with Epoch=${workerTicketEpoch}. Current Epoch=${currentEpoch}. Write FENCED!`);
      return;
    }
    setResourceState('RELEASED');
    setActiveWorkerPid(null);
    addLog(`[SUCCESS] Worker PID=${activeWorkerPid} committed side effect matching Epoch=${currentEpoch}. Resource unlocked.`);
  };

  // Scenario 2: Core revokes lease (timeout or cancel)
  const handleCoreRevocation = () => {
    const nextEpoch = currentEpoch + 1;
    setCurrentEpoch(nextEpoch);
    addLog(`[REVOCATION] Core incremented Generation Epoch to ${nextEpoch}. Worker PID=${activeWorkerPid} write lease invalidated.`);
    addLog(`[KERNEL] Dispatched TerminateJobObject(WorkerPID=${activeWorkerPid}).`);

    if (isWorkerResponsive) {
      setResourceState('RELEASED');
      setActiveWorkerPid(null);
      addLog(`[TERMINATED] Worker process exited cooperatively within 500ms grace window. Resource key released.`);
    } else {
      // Unresponsive worker
      if (isToolIdempotent) {
        setResourceState('RELEASED');
        setActiveWorkerPid(null);
        addLog(`[TIMED_OUT] Tool declared idempotent & safely abortable. Transitioned to Timed_Out. Resource released per REQ-REL-001.`);
      } else {
        setResourceState('AMBIGUOUS_HOLD');
        addLog(`[AMBIGUOUS_UNCERTAIN] Worker did not acknowledge termination within 500ms. Resource key locked in AMBIGUOUS HOLD per REQ-CORE-005.`);
      }
    }
  };

  // Scenario 3: Stale Worker attempts commit after revocation
  const handleStaleWriteAttempt = () => {
    if (workerTicketEpoch !== currentEpoch) {
      addLog(`[CRITICAL FENCE] Stale worker write blocked by storage fencing gate: Presented Epoch=${workerTicketEpoch} < Active Lock Epoch=${currentEpoch}.`);
    } else {
      addLog(`[ERROR] Worker ticket is still valid. Core has not revoked lease yet.`);
    }
  };

  // Reset
  const handleReset = () => {
    setCurrentEpoch(101);
    setWorkerTicketEpoch(101);
    setActiveWorkerPid(8492);
    setResourceState('ACQUIRED');
    setLogEvents([
      '[RESET] Engine reset.',
      '[INIT] Resource lock acquired for fs:workspace:production_db.sqlite',
      '[LEASE] Issued capability lease: Epoch=101, WorkerPID=8492',
    ]);
  };

  return (
    <div className="bg-card border border-border/60 rounded-xl p-6 shadow-xs space-y-6">
      <div className="border-b border-border/60 pb-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-primary text-primary-foreground">
                RFC-009 Simulator
              </span>
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                REQ-CORE-005 &bull; REQ-CORE-003 &bull; REQ-REL-001 &bull; REQ-SIM-002
              </span>
            </div>
            <h3 className="text-lg font-bold text-foreground mt-1">
              Execution Ownership Fencing & Revocation Leases
            </h3>
          </div>
          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-secondary text-secondary-foreground hover:bg-secondary/80 font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Simulator
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Resource Lock State Card */}
        <div className="bg-muted/20 border border-border/60 rounded-xl p-4 space-y-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
            Target Resource Key
          </span>
          <div className="font-mono text-xs font-bold text-foreground break-all">
            {resourceKey}
          </div>
          <div className="pt-2 flex items-center gap-2">
            {resourceState === 'ACQUIRED' && (
              <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400 font-medium border border-amber-500/20">
                <Lock className="w-3.5 h-3.5" />
                LOCKED (Active Lease)
              </span>
            )}
            {resourceState === 'RELEASED' && (
              <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium border border-emerald-500/20">
                <Unlock className="w-3.5 h-3.5" />
                RELEASED (Idle)
              </span>
            )}
            {resourceState === 'AMBIGUOUS_HOLD' && (
              <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-md bg-destructive/10 text-destructive font-bold border border-destructive/20">
                <AlertOctagon className="w-3.5 h-3.5" />
                AMBIGUOUS HOLD (Frozen)
              </span>
            )}
          </div>
        </div>

        {/* Generation Epoch */}
        <div className="bg-muted/20 border border-border/60 rounded-xl p-4 space-y-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
            Monotonic Generation Epoch
          </span>
          <div className="font-mono text-2xl font-bold text-primary">
            {currentEpoch}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Any write token with epoch &lt; {currentEpoch} is rejected instantly by the storage fencing layer.
          </p>
        </div>

        {/* Worker Capability Ticket */}
        <div className="bg-muted/20 border border-border/60 rounded-xl p-4 space-y-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
            Active Sub-Process Lease
          </span>
          <div className="font-mono text-xs text-foreground space-y-1">
            <div>Worker PID: <span className="font-semibold">{activeWorkerPid ? activeWorkerPid : 'NONE'}</span></div>
            <div>Ticket Epoch: <span className="font-semibold text-primary">{workerTicketEpoch}</span></div>
          </div>
          <div className="text-[11px] text-muted-foreground">
            Valid only while Ticket Epoch == Generation Epoch.
          </div>
        </div>
      </div>

      {/* Simulator Controls */}
      <div className="bg-muted/30 border border-border/60 rounded-xl p-5 space-y-4">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Fault Injection & Execution Controls
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-2">
          <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={isToolIdempotent}
              onChange={(e) => setIsToolIdempotent(e.target.checked)}
              className="w-4 h-4 rounded text-primary"
            />
            <span>Manifest: Declared Idempotent & Safely Abortable (REQ-EXT-005)</span>
          </label>

          <label className="flex items-center gap-2 text-xs text-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={isWorkerResponsive}
              onChange={(e) => setIsWorkerResponsive(e.target.checked)}
              className="w-4 h-4 rounded text-primary"
            />
            <span>Worker is Responsive (Exits within 500ms grace period)</span>
          </label>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={handleWorkerCommit}
            disabled={resourceState !== 'ACQUIRED'}
            className="px-3.5 py-2 rounded-lg bg-emerald-600 text-white font-medium text-xs hover:bg-emerald-700 disabled:opacity-50 transition-colors shadow-xs"
          >
            Worker Normal Commit (Valid Ticket)
          </button>

          <button
            onClick={handleCoreRevocation}
            disabled={resourceState === 'RELEASED'}
            className="px-3.5 py-2 rounded-lg bg-amber-600 text-white font-medium text-xs hover:bg-amber-700 disabled:opacity-50 transition-colors shadow-xs"
          >
            Core Times Out / Cancels (Increment Epoch & Terminate)
          </button>

          <button
            onClick={handleStaleWriteAttempt}
            className="px-3.5 py-2 rounded-lg bg-destructive text-destructive-foreground font-medium text-xs hover:bg-destructive/90 transition-colors shadow-xs"
          >
            Stale Worker Attempts Write (Old Epoch Ticket)
          </button>
        </div>
      </div>

      {/* Audit Log / Event Feed */}
      <div className="bg-background border border-border/60 rounded-xl p-4 space-y-2">
        <span className="text-xs font-semibold text-muted-foreground font-mono block">
          Live Fencing Kernel & Storage Log
        </span>
        <div className="font-mono text-[11px] bg-muted/60 p-3 rounded-lg space-y-1 text-foreground/90 max-h-40 overflow-y-auto border border-border/40">
          {logEvents.map((evt, idx) => (
            <div key={idx} className={evt.includes('REJECTED') || evt.includes('CRITICAL') ? 'text-destructive font-bold' : evt.includes('SUCCESS') ? 'text-emerald-500 font-bold' : ''}>
              {evt}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
