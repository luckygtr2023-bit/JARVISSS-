# JARVIS Architecture Specification & Technical RFC Compendium

* **Specification Version:** 1.3.0-ARCH-RFC
* **Status:** Binding Architectural Baseline (Approved for Implementation)
* **Alignment:** Aligned with `JARVIS_MASTER_REQUIREMENTS.md` v1.3.0 and `REQUIREMENTS_ASSUMPTIONS.md` v1.3.0
* **Target Environment:** Windows 10/11 x64 (Primary), Android Companion (Secondary)
* **Scope:** Authoritative resolution of Architectural Questions 1 through 15

---

## Executive Summary & System Architecture Overview

The JARVIS Architecture is constructed upon a single non-negotiable invariant: **Non-Authoritative AI with Bounded Execution Authority**. Artificial intelligence reasoning engines, memory stores, and untrusted network inputs are strictly untrusted sources of intent decomposition; authorization derives exclusively from authenticated cryptographic policies and deterministic host-side state machines.

```
+----------------------------------------------------------------------------------------------------+
|                                      USER INTERACTION SURFACE                                      |
|   +-----------------------+      +---------------------------+      +--------------------------+   |
|   |  Direct Voice / TTS   |      |  UI Shell (Less Trusted)  |      | Android Companion Client |   |
|   |  (Local Audio Buffer) |      | (WPF / WinUI3 Sandboxed)  |      |   (Out-of-Band Paired)   |   |
|   +-----------+-----------+      +-------------+-------------+      +------------+-------------+   |
+---------------|--------------------------------|---------------------------------|-----------------+
                |                                | (RFC-007 Binding)               | (RFC-008 mTLS)
                v                                v                                 v
+----------------------------------------------------------------------------------------------------+
|                                    JARVIS CONTROL CORE (DAEMON)                                     |
|  +-----------------------------------------------------------------------------------------------+ |
|  | State Machine Engine (RFC-004: 11 States, WAL, Crash-Safe Recover to Halted_Requires_Inspection)    | |
|  +-----------------------------------------------------------------------------------------------+ |
|  | Security Policy Evaluator (RFC-005: Authenticated Ed25519 Policy, 4-Tier Risk Matrix)          | |
|  +-----------------------------------------------------------------------------------------------+ |
|  | Provenance & Taint Lattice (RFC-006: Transitive Propagation, Tainted-Write Confirmation Gate)  | |
|  +-----------------------------------------------------------------------------------------------+ |
|  | Resource Serializer & Fencing Lease Manager (RFC-009: 64-bit Epoch Leases, Ambiguity Holds)     | |
|  +-----------------------------------------------------------------------------------------------+ |
|  | Semantic Deduplication Key Derivation Engine (RFC-011: RFC-8785 Canonical JSON Hashing)        | |
|  +-----------------------------------------------------------------------------------------------+ |
|  | Audit Log & Anchor Controller (RFC-010: Cryptographic Hash Chain, Independent TPM/ACL Anchor)  | |
+------------------------------------------------+---------------------------------------------------+
                                                 |
                                                 | (RFC-001 Named Pipes with Security Descriptors)
                                                 v
+----------------------------------------------------------------------------------------------------+
|                                     ISOLATED WORKER PROCESSES                                      |
|  +---------------------------+   +---------------------------+   +-------------------------------+ |
|  | Windows UIA Automation    |   | Chromium Automation       |   | Third-Party Tool Plugins      | |
|  | (RFC-002: UIA v3 COM)     |   | (RFC-015: Ephemeral Prof) |   | (RFC-001/013: Sandboxed IL)   | |
|  +---------------------------+   +---------------------------+   +-------------------------------+ |
+----------------------------------------------------------------------------------------------------+
```

---

# Detailed RFC Specifications

---

## RFC-001: Core IPC Mechanics & Process Topology
* **Addresses:** Architectural Question 1
* **Binding Requirements:** `REQ-CORE-001`, `REQ-CORE-004`, `REQ-EXT-002`, `REQ-EXT-002a`, `REQ-EXT-006`
* **Status:** APPROVED

### 1. Problem Statement
The JARVIS Control Core must communicate with isolated worker processes (tool runners), local user interface shells, and auxiliary capture daemons. The transport mechanism must minimize attack surface, provide sub-millisecond local latency, enforce mandatory access controls (MAC), and strictly prevent worker-to-worker crosstalk.

### 2. Architectural Decision
The system adopts **Local Windows Named Pipes** (`\\.\pipe\jarvis-core-{SessionId}-{ProcessRole}`) configured with **Explicit Security Descriptors (SDDL)** and **Framed Length-Prefixed Protocol Buffers (Protobuf v3)**.

### 3. Technical Specification
1. **Pipe Configuration & Security Descriptors:**
   - The Core daemon creates listening pipe instances using `CreateNamedPipeW` with `PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE | FILE_FLAG_OVERLAPPED`.
   - The SDDL string enforces `D:(A;;GRGW;;;PS)(A;;GRGW;;;OW)` (Permit Principal Self and Owner only). Low-integrity workers (AppContainers) receive granular read-write access only to their dedicated pipe instance, denying access to `Authenticated Users` or `Everyone`.
2. **Process Privilege & Sandbox Topology:**
   - **Control Core:** Runs under standard user interactive token (Medium Integrity Level) or Elevated Service Mode (`REQ-WIN-002`).
   - **UI Shell:** Separate unprivileged process (Low Integrity or Restricted Token).
   - **Tool Sub-Processes:** Spawned via `CreateProcessAsUserW` within a Windows Job Object (`JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`, restricted token with `SE_ASSIGNPRIMARYTOKEN_NAME` stripped, null privileges, and AppContainer SID).
3. **No Worker-to-Worker Cross-Talk (`REQ-EXT-006`):**
   - Direct IPC between sub-processes is blocked by Windows Object Manager namespaces. Pipes are anchored exclusively in the Core's private server handle pool.
4. **Wire Framing:**
   ```
   [4 Bytes Magic (0x4A415256)] [4 Bytes Big-Endian Length] [1 Byte Frame Type] [N Bytes Protobuf Payload] [4 Bytes CRC32C]
   ```

---

## RFC-002: Desktop Accessibility vs. Direct Visual Manipulation
* **Addresses:** Architectural Question 2
* **Binding Requirements:** `REQ-WIN-001`, `REQ-VIS-001`, `REQ-VIS-003`
* **Status:** APPROVED

### 1. Problem Statement
Windows automation must balance deterministic execution, UI integrity, accessibility surfaces, and fallback visual/OCR manipulation without introducing misdirected clicks or race conditions.

### 2. Architectural Decision
The automation engine implements a strict **Three-Tier Automation Strategy**: Tier 1: Windows UI Automation (UIA v3 COM) -> Tier 2: Standard Win32 Window Messages (`WM_COMMAND`/Accessible Object) -> Tier 3: Coordinate-based Visual Synthesis with Mandatory Fallback Telemetry.

### 3. Technical Specification
1. **Tier 1 (Mandatory Default):**
   - Uses `IUIAutomation6` COM interface. Elements are resolved by stable property condition trees (`AutomationId`, `ControlType`, `Name`, `FrameworkId`).
   - Invocation utilizes native patterns (`IUIAutomationInvokePattern`, `IUIAutomationValuePattern`, `IUIAutomationSelectionItemPattern`).
2. **Tier 3 Fallback Gating (`REQ-WIN-001`):**
   - Coordinate-based input synthesis (`SendInput`) is prohibited unless Tier 1 and Tier 2 return `UIA_E_ELEMENTNOTAVAILABLE` or target a declared custom rendering surface (e.g., DirectX/WPF canvas without accessibility peers).
   - Every Tier 3 action MUST emit a structured audit log entry containing:
     - `reason`: `E_UIA_UNAVAILABLE` or `E_CUSTOM_SURFACE`
     - `target_hwnd`: Hexadecimal window handle
     - `target_process_name`: Canonical executable name
     - `target_bounding_rect`: Expected physical coordinates verified by screen capture bounding checks
3. **Visual Content Integrity (`REQ-VIS-003`):**
   - Text extracted via OCR from screen regions is tagged `PROV_UNTRUSTED_OCR` and enters the taint tracking engine, preventing visual prompt injection from altering policy evaluations.

---

## RFC-003: Local Storage Key Management & DPAPI / TPM Strategy
* **Addresses:** Architectural Question 3
* **Binding Requirements:** `REQ-MEM-002`, `REQ-MEM-006`, `REQ-WIN-004`, `REQ-SEC-003`
* **Status:** APPROVED

### 1. Problem Statement
Vector memory, conversation logs, and secret tokens must be stored in encrypted local databases without requiring manual user passphrases on background service wake-up, while guaranteeing cryptographic clearing upon user logout or session switch.

### 2. Architectural Decision
A **Two-Tier Envelope Key Architecture** utilizing **Windows DPAPI (`CryptProtectData`) with User-Bound Entropy** and **Hardware TPM 2.0 PCR Validation**.

### 3. Technical Specification
1. **Key Hierarchy:**
   - **Root Key (MK):** 256-bit AES-GCM key generated at initial user onboarding.
   - **Key Protection:** Sealed using `CryptProtectData` with `CRYPTPROTECT_UI_FORBIDDEN` and user-specific persistent salt (stored in Windows Credential Manager).
   - **Database Encryption:** SQLite databases (vector store and relational history) use **SQLCipher (AES-256-GCM)** with page-level HMAC-SHA512.
2. **User Session Lifecycle (`REQ-MEM-006`, `REQ-WIN-004`):**
   - Decrypted MK is held exclusively in non-paged volatile process memory (`VirtualLock`).
   - On Windows session events (`WM_WTSSESSION_CHANGE` -> `WTS_SESSION_LOGOFF` or `WTS_SESSION_LOCK`), the Core invokes `SecureZeroMemory` over all decrypted key material and closes open database connection handles.
   - Background tasks executing while logged out operate in `READ_ONLY` mode with no credential access.

---

## RFC-004: Crash-Safe State Machine & WAL Recovery Protocol
* **Addresses:** Architectural Question 4
* **Binding Requirements:** `REQ-CORE-002`, `REQ-CORE-002a`, `REQ-REL-003`, `REQ-REL-003a`, `REQ-REL-003b`, `REQ-REL-006`
* **Status:** APPROVED

### 1. Problem Statement
Ungraceful termination (kernel panic, power loss, process termination) must never leave tasks in ambiguous or partially executed states that could lead to double execution or state corruption on reboot.

### 2. Architectural Decision
The Control Core implements an **Append-Only Write-Ahead Log (WAL)** governing the 11-State Lifecycle Engine. On reboot, every non-terminal task is transitioned to `Halted_Requires_Inspection`.

### 3. State Machine Specification
```
[Initiated] ---> [Planning] ---> [Awaiting_Confirmation] ---> [Executing] ---> [Verifying] ---> [Completed] (Terminal)
      |              |                     |                      |                |
      v              v                     v                      v                v
  [Failed]       [Failed]             [Cancelled]          [Ambiguous_       [Failed]
 (Terminal)     (Terminal)            (Terminal)            Uncertain]      (Terminal)
                                           |                      |
                                           v                      v
                                      [Timed_Out]      [Halted_Requires_Inspection]
```

### 4. Recovery Protocol Steps:
1. **Journal Flush Invariant:** Before any state transition is visible to workers or UI, a `StateTransitionLogRecord` is written and flushed with `FILE_FLAG_WRITE_THROUGH` (`fsync`).
2. **Crash Ingestion:**
   - On startup, the Core inspects all requests in the journal.
   - Any request not in terminal states (`Completed`, `Failed`, `Cancelled`) is forced into `Halted_Requires_Inspection`.
   - A reconciliation manifest is generated per node declaring:
     - `last_known_state`
     - `side_effect_status`: `VERIFIED_APPLIED` | `VERIFIED_UNAPPLIED` | `INDETERMINATE`
     - `action_recommendation`: `SAFE_TO_RESUME` | `SAFE_TO_RETRY` | `SAFE_TO_ABANDON`
   - No task is auto-resumed; human inspection is mandatory before new requests are dispatched.

---

## RFC-005: Manifest and Policy Authenticity Specification
* **Addresses:** Architectural Question 5
* **Binding Requirements:** `REQ-EXT-003`, `REQ-EXT-004`, `REQ-SEC-001a`, `REQ-DEP-003`
* **Status:** APPROVED

### 1. Problem Statement
Tool manifests declare capability boundaries and risk tiers. A modified manifest or injected policy can bypass security checks. Authenticity must be cryptographically verified prior to loading.

### 2. Architectural Decision
Manifests and policy files are packaged as **Detached Ed25519 Signed Artifacts** verified against a pinned Root-of-Trust Hardware Keystore.

### 3. Technical Specification
1. **Artifact Format:**
   ```json
   {
     "payload": {
       "manifest_id": "com.jarvis.filesystem.workspace",
       "version": "1.3.0",
       "publisher_id": "pub_core_official_01",
       "risk_tier": "LOW_RISK_SIDE_EFFECT",
       "resource_keys": ["fs:workspace:{id}"],
       "idempotent": true,
       "simulation_level": "FULLY_SIMULATABLE",
       "declared_uncertainties": ["UNC_PARTIAL_FILE_FLUSH"]
     },
     "signature": {
       "algorithm": "Ed25519",
       "key_id": "key_2026_jarvis_release",
       "signature_base64": "9f8a...c3d1"
     }
   }
   ```
2. **Verification Pipeline:**
   - Canonical JSON (RFC 8785) serialization of `payload`.
   - Ed25519 verification against the local trust anchor stored in `%ProgramFiles%\JARVIS\trust\root.pub` (protected by Administrator ACL `F:BU`, read-only to User).
   - In-memory lock: Once verified, manifest objects are marked read-only via memory page protection (`VirtualProtect` `PAGE_READONLY`). Attempted modification triggers a memory violation fault and immediately unloads the tool (`REQ-EXT-004`).

---

## RFC-006: Untrusted-Content Provenance & Taint Lattice
* **Addresses:** Architectural Question 6
* **Binding Requirements:** `REQ-SEC-005`, `REQ-BRW-004`, `REQ-VIS-003`, `REQ-MEM-007`, `REQ-AI-008`
* **Status:** APPROVED

### 1. Problem Statement
External content (web text, OCR, external tool responses, user files) can carry indirect prompt injection. Taint must propagate transitively across data transformations and memory records, elevating any tainted write action to mandatory human confirmation.

### 2. Architectural Decision
The engine adopts a **Finite Provenance Lattice ($\mathcal{L}$)** where every value carries an immutable 16-bit bitfield taint tag.

### 3. Taint Lattice Bitfield Schema
| Bit | Name | Source / Description |
| :--- | :--- | :--- |
| `0x00` | `CLEAN_POLICY` | Internal authenticated policy or direct user voice/text prompt |
| `0x01` | `TAINT_WEB` | Web pages, search snippets, external REST API payloads |
| `0x02` | `TAINT_OCR` | Text recognized from screen/window captures |
| `0x04` | `TAINT_EXT_TOOL` | Return payloads from isolated plugin sub-processes |
| `0x08` | `TAINT_EXT_MODEL` | Unverified output from remote or third-party LLM providers |
| `0x10` | `TAINT_MEM_DERIVED` | Memory records synthesized from tainted past observations |

### 4. Propagation & Over-Tainting Suppression Rules:
1. **Transitive Propagation:** If value $C = f(A, B)$, then $\text{Taint}(C) = \text{Taint}(A) \lor \text{Taint}(B)$.
2. **Metadata Non-Propagation Invariant (`REQ-SEC-005`):**
   - Pure structural metadata (array length, string byte count, structural token count, timestamp of arrival, content MIME type) does **not** inherit taint, preventing system-wide gridlock.
   - Exception: If the metadata value directly dictates an execution parameter (e.g. `truncate_at = length(tainted_str)`), taint binds to the resulting parameter.
3. **Write-Action Gating:**
   - Any DAG node whose parameters or tool selection carry $\text{Taint} \neq 0$ and whose manifest action alters state (`LOW_RISK_SIDE_EFFECT`, `HIGH_RISK_SIDE_EFFECT`, or `CRITICAL_SYSTEM`) is **force-escalated** to require explicit human confirmation.

---

## RFC-007: Cryptographic Confirmation Binding & Secret Obfuscation
* **Addresses:** Architectural Question 7
* **Binding Requirements:** `REQ-CORE-004`, `REQ-SEC-007`, `REQ-SEC-008`
* **Status:** APPROVED

### 1. Problem Statement
The UI layer is less trusted than the Core (`REQ-CORE-004`). Confirmation prompts must accurately convey the exact action to the user while protecting secret parameters from leakage in prompts, display windows, logs, or side-channel oracles.

### 2. Architectural Decision
Confirmation signals are bound via **HMAC-SHA256 Operation Digests** with **Non-Invertible Secret Fingerprinting**.

### 3. Mathematical Binding Contract
The Core emits an authorization challenge containing:
$$\text{Digest} = \text{HMAC-SHA256}\Big(K_{\text{session}}, \text{ReqID} \parallel \text{ToolID} \parallel H(\text{CanonicalParams}) \parallel H(\text{ResourceKeys})\Big)$$
When the user clicks "Approve", the UI responds with:
$$\text{ConfirmationResponse} = \Big(\text{ReqID}, \text{Digest}, \text{Timestamp}, \text{UserGestureNonce}\Big)$$
The Core verifies:
1. `ReqID` matches an active request currently in `Awaiting_Confirmation`.
2. `Timestamp` is within the validity window (default 60 seconds; expires to `Cancelled` per `REQ-SEC-007a`).
3. Recomputed $\text{Digest}$ matches exactly. Any parameter tampering causes instant rejection.

### 4. Secret Parameter Handling (`REQ-SEC-008`):
- Raw secret strings (API keys, passwords) are NEVER sent to UI or logged.
- The UI displays: `[Vault Credential: "Prod_Database_Password" (KeyID: #sec_7f9a2)]`.
- In the digest computation, the secret's contribution is:
  $$\text{Fingerprint} = \text{HMAC-SHA256}(\text{HostSalt}, \text{RawSecret})$$
- No prefix, suffix, or partial characters (last-N) are revealed.

---

## RFC-008: Companion Channel Out-of-Band Pairing & Zero-Trust Protocol
* **Addresses:** Architectural Question 8
* **Binding Requirements:** `REQ-AND-002` through `REQ-AND-009`
* **Status:** APPROVED

### 1. Problem Statement
The Android companion communicates remotely over local Wi-Fi or cloud relays. It must be treated as an untrusted remote source until verified, and companion compromise must not authorize high-risk actions.

### 2. Architectural Decision
The channel utilizes the **Noise Protocol Framework (`Noise_XX_25519_ChaChaPoly_BLAKE2s`)** with **QR-Code Out-of-Band Pairing** and **Host-Side Confirmation Interlock**.

### 3. Protocol Flow
1. **Out-of-Band Pairing Ceremony (`REQ-AND-002`):**
   - Windows Host renders an ephemeral high-entropy QR Code containing:
     $$\text{QR} = \Big(\text{HostStaticPubKey}, \text{IPv4/IPv6 Port}, \text{PairingNonce}, \text{Expiry}\Big)$$
   - Android scans QR code and exchanges static public keys via Bluetooth LE or direct Wi-Fi probe.
2. **Session Replay Protection (`REQ-AND-003`):**
   - Every frame includes a strictly monotonically increasing 64-bit sequence counter and UTC timestamp. Replayed or out-of-window packets (>5000ms drift) are dropped silently.
3. **Host-Side Confirmation Interlock (`REQ-AND-009`):**
   - For commands classified as `HIGH_RISK_SIDE_EFFECT` or `CRITICAL_SYSTEM`, even if initiated from the companion, execution remains suspended in `Awaiting_Confirmation` on the Windows host desktop until confirmed physically on the host.

---

## RFC-009: Execution Ownership Fencing & Revocation Leases
* **Addresses:** Architectural Question 9
* **Binding Requirements:** `REQ-CORE-005`, `REQ-CORE-003`, `REQ-REL-001`, `REQ-SIM-002`
* **Status:** APPROVED

### 1. Problem Statement
When a tool times out, is cancelled, or the Core crashes and restarts, stale worker processes might still be running and attempt to write to resources. Simple timeout without fencing creates race conditions and state corruption.

### 2. Architectural Decision
Execution is governed by **Revocable Ephemeral Capability Leases** tied to **64-bit Monotonic Generation Epochs** and **Kernel Job Object Fencing**.

### 3. Technical Mechanics
1. **Generation Token Binding:**
   - Every resource key lock is associated with a tuple: $(\text{EpochID}, \text{LeaseExpiryUtc}, \text{WorkerPID})$.
   - The tool process receives a capability handle valid only while $\text{CurrentEpoch} = \text{LockEpoch}$.
2. **Revocation & Fencing Invariant:**
   - When the Core cancels or times out an operation:
     1. It increments $\text{EpochID}$, immediately invalidating any write ticket presented by the worker.
     2. It issues a hard kernel termination to the worker's Job Object (`TerminateJobObject`).
3. **Ambiguity Hold Rule (`REQ-CORE-005`):**
   - If the worker process does not exit within 500ms, or if the tool modified external state without acknowledging completion:
     - The state transitions to `Ambiguous_Uncertain`.
     - The resource key remains **LOCKED**. No subsequent operation can acquire this resource key until explicit user inspection or recovery resolves the ambiguity.
   - Exception: If the tool manifest declared the action `idempotent` and `safely_abortable`, the Core safely transitions to `Timed_Out` and releases the resource key.

---

## RFC-010: Audit Log Chain Integrity & Split-Anchor Protection
* **Addresses:** Architectural Question 10
* **Binding Requirements:** `REQ-DEP-002`, `REQ-DEP-002a`, `REQ-DEP-002b`
* **Status:** APPROVED

### 1. Problem Statement
The audit log must be tamper-evident against truncation, modification, rollback, and anchor replacement, even if the primary logging process is compromised.

### 2. Architectural Decision
The log implements a **Merkle Hash-Chained Write-Ahead Ledger** with **Split-Anchor Protection via Hardware TPM 2.0 PCR Extension and Windows Protected Service Registry Anchor**.

### 3. Cryptographic Chain Formulation
Each entry $E_i$ is formatted as:
$$H_i = \text{SHA-256}\Big(H_{i-1} \parallel \text{SeqNo}_i \parallel \text{Timestamp}_i \parallel \text{EventPayload}_i\Big)$$
where $H_0 = \text{GenesisHash}$.

### 4. Anchor Protection Mechanics (`REQ-DEP-002b`):
1. **TPM PCR Extension:** On every block of 100 entries (or on task completion), the Core extends TPM 2.0 PCR 15:
   $$\text{PCR}_{15} \leftarrow \text{TPM2\_PCR\_Extend}(\text{PCR}_{15}, H_{\text{current}})$$
2. **Split Anchor Store:** The head hash $H_{\text{current}}$ is simultaneously written to an isolated service registry key readable by the audit verifier but write-protected against standard user processes via a dedicated NT SERVICE SID (`NT SERVICE\JarvisAuditGuardian`).
3. **Boot-Time Verification Procedure:**
   - On every Core boot, before new log entries are permitted, the verification engine re-hashes the log file from Genesis to Head.
   - The computed hash is compared against the TPM and Guardian Registry anchor.
   - If a mismatch, truncation, or gap is detected, the system fails closed into `Halted_Requires_Inspection`.

---

## RFC-011: Semantic Deduplication Key Derivation Engine
* **Addresses:** Architectural Question 11
* **Binding Requirements:** `REQ-EXT-005`, `REQ-EXT-007`, `REQ-REL-006`, `REQ-REL-003b`
* **Status:** APPROVED

### 1. Problem Statement
Retries, crash recovery, and DAG replanning must never duplicate non-idempotent real-world side effects (e.g., sending an email, submitting a financial transaction, writing a file).

### 2. Architectural Decision
Deduplication keys are derived from **Semantic Identity Hashes** calculated over **RFC 8785 Canonical JSON**, completely independent of plan node instance IDs or timestamps.

### 3. Derivation Formulation
$$\text{DedupKey} = \text{SHA-256}\Big(\text{Namespace} \parallel \text{ToolID} \parallel \text{Canonicalize}(\text{SemanticParameters}) \parallel \text{TargetResourceKey}\Big)$$
1. **Volatile Exclusion:** Ephemeral parameters (client request ID, display animation speed, UI session trace) are tagged `volatile: true` in the manifest schema and excluded from canonicalization.
2. **Replan & Recovery Mapping (`REQ-REL-006`):**
   - When a DAG is replanned mid-execution, new nodes that address the same logical goal inherit the pre-calculated `DedupKey`.
   - The Core maintains an in-memory and WAL-persisted index of observed `(DedupKey, Outcome)`.
   - If an operation with an identical `DedupKey` is submitted, it is immediately rejected unless its prior recorded outcome is definitively `Failed`.

---

## RFC-012: Concrete Uncertainty Taxonomy & Recovery Engine
* **Addresses:** Architectural Question 12
* **Binding Requirements:** `REQ-SIM-002a`, `REQ-SIM-002b`, `REQ-SIM-002`, `REQ-REL-005`
* **Status:** APPROVED

### 1. Problem Statement
A single `Ambiguous_Uncertain` state cannot drive intelligent recovery. Failures have different physical signatures (e.g., socket closed after POST vs. disk write stall vs. sub-process crash).

### 2. Architectural Decision
The system instantiates a **Formal 5-Class Uncertainty Taxonomy** with deterministic per-class recovery state handlers.

### 3. Concrete Uncertainty Taxonomy Table
| Class Code | Name | Cause Description | Manifest Declaration | Automated Action | User Recovery Options |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `UNC-01` | `NETWORK_INDETERMINATE_POST` | HTTP socket drop or timeout after headers/body sent | `network_io: true` | Hold resource key; halt downstream | [Probe Target Status] [Assume Success] [Rollback] |
| `UNC-02` | `PARTIAL_FILE_FLUSH` | Process died during file write before atomic rename | `filesystem: write` | Quarantine temporary write file; inspect size | [Revert to Backup] [Force Overwrite] [Inspect Temp] |
| `UNC-03` | `SUBPROCESS_CRASH_UNACK` | Sub-process terminated without emitting exit packet | All external plugins | Capture exit code & mini-dump; hold resource keys | [Inspect Dump] [Mark Failed] [Re-execute] |
| `UNC-04` | `EXTERNAL_SYSTEM_DESYNC` | Third-party API returned 500 but state may be modified | `service_integration` | Quarantine operation deduplication key | [Query External Audit] [Manual Reconciliation] |
| `UNC-05` | `TIMEOUT_WITH_ACTIVE_HANDLE` | Sub-process timed out but refuses kernel shutdown | Complex long-running | Issue `TerminateJobObject`; flag for crash inspection | [Force Kill] [Inspect Orphan State] |

---

## RFC-013: Simulation Fidelity Model & Operational Completeness
* **Addresses:** Architectural Question 13
* **Binding Requirements:** `REQ-SIM-001`, `REQ-SIM-001a`, `REQ-SIM-001b`
* **Status:** APPROVED

### 1. Problem Statement
The system must dry-run multi-step plans before real execution. Because not all tools can simulate external state (e.g. sending a physical fax or executing an irreversible remote API call), simulation fidelity must be formally categorized and communicated.

### 2. Architectural Decision
A **Three-Tier Operational Fidelity Model** with **Mandatory Explicit Risk Acknowledgment Contracts**.

### 3. Fidelity Categories
1. **`FULLY_SIMULATABLE`:** Tool implements an isolated sandbox test double (e.g. temporary directory file staging, memory-only SQLite, mocked read API). Emits guaranteed mock side effects without real OS handles or network sockets.
2. **`PARTIALLY_SIMULATABLE`:** Tool validates input schemas, checks resource availability, evaluates permissions and quotas, but cannot simulate external remote system changes.
3. **`NOT_SIMULATABLE`:** Tool can only perform static parameter checks; side effects cannot be staged.

### 4. Operational Gating (`REQ-SIM-001b`):
- Any DAG containing at least one node declared `PARTIALLY_SIMULATABLE` or `NOT_SIMULATABLE` is flagged `SIMULATION_INCOMPLETE`.
- Before executing a `SIMULATION_INCOMPLETE` plan, the UI displays an explicit warning highlighting the exact nodes with incomplete dry-run coverage. The user must provide a distinct gesture: `"I acknowledge that steps [2, 4] carry unverified simulation risk."`

---

## RFC-014: Windows Session Boundary & Credential Purge Protocol
* **Addresses:** Architectural Question 14
* **Binding Requirements:** `REQ-WIN-004`, `REQ-MEM-006`, `REQ-MEM-001`
* **Status:** APPROVED

### 1. Problem Statement
Background services must not leak memory, credentials, or session history across Windows user switches, desktop locks, or logouts.

### 2. Architectural Decision
A **Session Event Controller** listening directly to Windows Terminal Services Notifications (`WTSRegisterSessionNotification`) coupled with a **Zero-Residual Memory Scrubber**.

### 3. Protocol Transitions
```
+------------------------+      WTS_SESSION_LOCK       +------------------------+
|   Interactive Active   | --------------------------> |    Locked / Dormant    |
| (Full Credential Ring) | <-------------------------- |  (Credentials Zeroed)  |
+------------------------+      WTS_SESSION_UNLOCK     +------------------------+
            |                                                      |
            | WTS_SESSION_LOGOFF                                   | WTS_SESSION_LOGOFF
            v                                                      v
+-------------------------------------------------------------------------------+
|                       Session Purged / Background Only                        |
| - SecureZeroMemory on all Master Keys and In-Memory Auth Tokens               |
| - Volatile short-term context flushed and destroyed                           |
| - Credential-dependent queued tasks frozen; only READ_ONLY tasks may run      |
+-------------------------------------------------------------------------------+
```

---

## RFC-015: Browser External Side-Effect Classifier & Contract Parser
* **Addresses:** Architectural Question 15
* **Binding Requirements:** `REQ-BRW-005`, `REQ-SEC-001`, `REQ-SEC-005`
* **Status:** APPROVED

### 1. Problem Statement
Modern web applications frequently use HTTP `POST` for idempotent data retrieval (e.g. GraphQL queries, search endpoints, vector retrieval). Classifying all POST requests as destructive side effects paralyzes navigation; conversely, treating them as harmless read-only calls exposes the system to CSRF and state changes.

### 2. Architectural Decision
A **Multi-Stage Semantic Classifier** combining **Declarative Endpoint Contracts (OpenAPI/GraphQL AST inspection)** with **Safe Conservative Fallbacks**.

### 3. Classification Engine Rules
1. **Contract Declarations (Fast Path):**
   - If an endpoint exposes a machine-readable OpenAPI specification where the operation is marked `readOnly: true`, or a GraphQL payload contains exclusively the root AST `query` operation (and zero `mutation`), it is classified as `READ_ONLY`.
2. **Deterministic Conservative Fallback (`REQ-BRW-005`):**
   - In the absence of an authenticated machine-readable contract:
     - All `POST`, `PUT`, `DELETE`, `PATCH` requests are conservatively classified as `LOW_RISK_SIDE_EFFECT` or `HIGH_RISK_SIDE_EFFECT` depending on the domain security reputation.
     - Form submissions that trigger cookies, payment checkouts, or external state mutations require explicit confirmation.
3. **Headless Profile Segregation (`REQ-BRW-002`):**
   - Automated browser sessions execute in separate ephemeral Chromium user data directories (`--user-data-dir=%TEMP%\jarvis-profile-{UUID}`) with zero access to the user's primary login cookies or credentials.

---

# Requirements Traceability Cross-Reference

| RFC ID | Title | Master Requirements Covered | Key Invariants Enforced |
| :--- | :--- | :--- | :--- |
| **RFC-001** | Core IPC & Sandboxing | `REQ-CORE-001`, `REQ-CORE-004`, `REQ-EXT-002`, `REQ-EXT-002a`, `REQ-EXT-006` | AppContainer isolation, zero plugin-to-plugin cross-talk |
| **RFC-002** | Windows Desktop Automation | `REQ-WIN-001`, `REQ-VIS-001`, `REQ-VIS-003` | UIA v3 COM prioritized, audit logged on coordinate fallback |
| **RFC-003** | Local Storage Encryption | `REQ-MEM-002`, `REQ-MEM-006`, `REQ-WIN-004`, `REQ-SEC-003` | DPAPI + SQLCipher, volatile zeroization on lock/logout |
| **RFC-004** | Crash-Safe State Machine | `REQ-CORE-002`, `REQ-CORE-002a`, `REQ-REL-003`, `REQ-REL-003a`, `REQ-REL-003b`, `REQ-REL-006` | 11 states, WAL fsync journal, restart to Halted_Requires_Inspection |
| **RFC-005** | Manifest & Policy Authenticity | `REQ-EXT-003`, `REQ-EXT-004`, `REQ-SEC-001a`, `REQ-DEP-003` | Ed25519 detached signatures, immutable in-memory pages |
| **RFC-006** | Provenance & Taint Lattice | `REQ-SEC-005`, `REQ-BRW-004`, `REQ-VIS-003`, `REQ-MEM-007`, `REQ-AI-008` | Finite lattice bitfield, non-propagating metadata, write-escalation |
| **RFC-007** | Cryptographic Confirmation Binding | `REQ-CORE-004`, `REQ-SEC-007`, `REQ-SEC-008` | HMAC-SHA256 digest, masked secrets, gesture nonces |
| **RFC-008** | Companion Zero-Trust Protocol | `REQ-AND-002` through `REQ-AND-009` | Noise_XX handshake, replay window, host-side physical confirmation |
| **RFC-009** | Execution Ownership Fencing | `REQ-CORE-005`, `REQ-CORE-003`, `REQ-REL-001`, `REQ-SIM-002` | 64-bit epoch tokens, TerminateJobObject, Ambiguous_Uncertain hold |
| **RFC-010** | Audit Log Hash-Chain & Anchor | `REQ-DEP-002`, `REQ-DEP-002a`, `REQ-DEP-002b` | SHA-256 Merkle chain, TPM 2.0 PCR 15, boot verification |
| **RFC-011** | Deduplication Key Derivation | `REQ-EXT-005`, `REQ-EXT-007`, `REQ-REL-006`, `REQ-REL-003b` | RFC 8785 Canonical JSON, volatile exclusion, crash resilience |
| **RFC-012** | Concrete Uncertainty Taxonomy | `REQ-SIM-002a`, `REQ-SIM-002b`, `REQ-SIM-002`, `REQ-REL-005` | 5 concrete ambiguity classes, structured error packets, recovery rules |
| **RFC-013** | Simulation Fidelity Model | `REQ-SIM-001`, `REQ-SIM-001a`, `REQ-SIM-001b` | 3 fidelity levels, SIMULATION_INCOMPLETE explicit waiver token |
| **RFC-014** | Windows Session Boundary | `REQ-WIN-004`, `REQ-MEM-006`, `REQ-MEM-001` | WTSRegisterSessionNotification, memory scrubbing on logout |
| **RFC-015** | Browser Side-Effect Classifier | `REQ-BRW-005`, `REQ-SEC-001`, `REQ-SEC-005` | OpenAPI/GraphQL AST parse, conservative POST fallback, isolated profile |
