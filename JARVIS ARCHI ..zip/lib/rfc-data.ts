export interface RFCRecord {
  id: string;
  number: number;
  questionNumber: number;
  title: string;
  shortTitle: string;
  category: 'Core' | 'Security' | 'Reliability' | 'Windows' | 'Simulation' | 'Browser' | 'Extensibility' | 'Android' | 'Storage';
  status: 'APPROVED' | 'IN_REVIEW' | 'PROPOSED';
  impactedRequirements: string[];
  problemStatement: string;
  architecturalDecision: string;
  technicalDetails: {
    protocolOrFormat: string;
    keyMechanisms: string[];
    securityGuarantees: string[];
    failureModes: string[];
    verificationMethod: string;
  };
  sampleCodeOrSchema: string;
}

export interface MasterRequirement {
  id: string;
  priority: 'MUST' | 'SHOULD' | 'MAY' | 'MUST-if';
  category: string;
  title: string;
  statement: string;
  securityImplications: string;
  verificationMethod: string;
  rfcMapping: string;
}

export const RFCS_DATA: RFCRecord[] = [
  {
    id: 'RFC-001',
    number: 1,
    questionNumber: 1,
    title: 'Core IPC Mechanics & Sandboxed Process Broker',
    shortTitle: 'Core IPC & Broker',
    category: 'Core',
    status: 'APPROVED',
    impactedRequirements: ['REQ-CORE-001', 'REQ-CORE-004', 'REQ-EXT-002', 'REQ-EXT-002a', 'REQ-EXT-006'],
    problemStatement: 'What IPC framework provides minimal attack surface and sub-millisecond latency between core daemon, isolated tool sub-processes, and UI layer, while strictly precluding worker-to-worker crosstalk?',
    architecturalDecision: 'Windows Named Pipes with Explicit Security Descriptors (SDDL), AppContainer / Restricted Token isolation, and CRC32C-checked Protobuf v3 framing.',
    technicalDetails: {
      protocolOrFormat: 'Protobuf v3 over duplex Windows Named Pipe with 4-byte magic (0x4A415256) + length prefix + CRC32C',
      keyMechanisms: [
        'Dedicated pipe per worker instance (\\\\.\\pipe\\jarvis-core-{SessionId}-{ProcessRole})',
        'SDDL D:(A;;GRGW;;;PS)(A;;GRGW;;;OW) restricting connection to Principal Self and Owner',
        'Job Object confinement (JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE) preventing orphan survival',
        'Tool sub-processes run under stripped tokens with no network/workspace access outside manifest declaration',
      ],
      securityGuarantees: [
        'Zero direct worker-to-worker IPC paths (isolated Windows Object Manager namespaces)',
        'UI process restricted to low-privilege pipe with no direct tool-execution capabilities',
        'Non-bypassable central control core entry point for all operations',
      ],
      failureModes: [
        'Pipe disconnection triggers immediate state freeze and worker termination',
        'Malformed framing or CRC mismatch drops connection and logs security alert',
      ],
      verificationMethod: 'Static analysis of reachable tool entry points; isolation boundary penetration test.',
    },
    sampleCodeOrSchema: `// Pipe SDDL Security Descriptor Definition
const string CorePipeSDDL = "D:(A;;GRGW;;;PS)(A;;GRGW;;;OW)";
HANDLE hPipe = CreateNamedPipeW(
    L"\\\\\\\\.\\\\pipe\\\\jarvis-core-worker-7a4f",
    PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED | FILE_FLAG_FIRST_PIPE_INSTANCE,
    PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
    1, // Max instances: strictly 1 per worker
    65536, 65536, 1000, &securityAttributes
);`,
  },
  {
    id: 'RFC-002',
    number: 2,
    questionNumber: 2,
    title: 'Desktop Automation: UI Automation (UIA) vs. Coordinate/OCR Fallback',
    shortTitle: 'Desktop Automation Hierarchy',
    category: 'Windows',
    status: 'APPROVED',
    impactedRequirements: ['REQ-WIN-001', 'REQ-VIS-001', 'REQ-VIS-003'],
    problemStatement: 'Should the Windows automation engine prioritize structured semantic surfaces or coordinate + OCR fallback, and how is the fallback strictly auditable and gated?',
    architecturalDecision: 'Three-Tier Automation Cascade: Tier 1: Windows UI Automation (UIA v3 COM) -> Tier 2: Win32 Accessible Objects -> Tier 3: Coordinate Synthesis with Mandatory Audit Log Telemetry.',
    technicalDetails: {
      protocolOrFormat: 'Windows UI Automation COM interfaces (IUIAutomation6) with programmatic element patterns',
      keyMechanisms: [
        'Semantic tree addressing via AutomationId, ControlType, Name, and RuntimeId',
        'Coordinate synthesis (SendInput) completely blocked unless Tier 1/2 returns UIA_E_ELEMENTNOTAVAILABLE',
        'Every coordinate action emits mandatory audit log with target HWND, process identity, and verified bounding box',
        'Extracted OCR text tagged PROV_UNTRUSTED_OCR to prevent visual prompt injection',
      ],
      securityGuarantees: [
        'Mitigates misdirected clicks caused by UI redraw, focus change, or screen resolution shifts',
        'Cross-integrity elevation checks: cannot interact with processes at higher integrity levels (UAC/System)',
      ],
      failureModes: [
        'If target window changes Z-order or HWND before invocation, operation aborts with E_TARGET_DESYNC',
      ],
      verificationMethod: 'Automated test suite against Win32, WPF, and Chromium controls verifying UIA preference.',
    },
    sampleCodeOrSchema: `// Tier 1 to Tier 3 Fallback Dispatcher
if (TryResolveUIAElement(targetSpec, out IUIAutomationElement* element)) {
    return InvokeUIAPattern(element);
} else {
    // REQ-WIN-001: Mandatory audit reason log for coordinate fallback
    AuditLog.RecordTier3Fallback(targetSpec.WindowHwnd, FallbackReason.UIA_UNAVAILABLE);
    return SynthesizeCoordinateInput(targetSpec.CalculatedBounds);
}`,
  },
  {
    id: 'RFC-003',
    number: 3,
    questionNumber: 3,
    title: 'Local Storage Key Management & DPAPI / TPM Strategy',
    shortTitle: 'Local Key Hierarchy',
    category: 'Storage',
    status: 'APPROVED',
    impactedRequirements: ['REQ-MEM-002', 'REQ-MEM-006', 'REQ-WIN-004', 'REQ-SEC-003'],
    problemStatement: 'How to manage cryptographic keys for persistent vector memory and local secrets across reboots without requiring user passphrases on background service start, while clearing them on logout?',
    architecturalDecision: 'Two-Tier Envelope Key Hierarchy: Windows DPAPI (CryptProtectData) with user entropy + SQLCipher database encryption + volatile memory zeroization on session lock/logout.',
    technicalDetails: {
      protocolOrFormat: 'AES-256-GCM envelope encryption with SQLCipher page-level HMAC-SHA512',
      keyMechanisms: [
        'Master Key (MK) generated via CSPRNG (256-bit AES) and sealed with DPAPI CryptProtectData',
        'Volatile MK held only in locked non-paged memory (VirtualLock)',
        'Session monitor intercepts WTS_SESSION_LOGOFF and executes SecureZeroMemory',
        'Background execution outside user session restricted to uncredentialed READ_ONLY mode',
      ],
      securityGuarantees: [
        'Database files on disk are completely unreadable without user Windows interactive logon',
        'No plaintext secrets in pagefiles, crash dumps, or hibernation images',
      ],
      failureModes: [
        'DPAPI unprotect failure during user session switch fails closed and denies database decryption',
      ],
      verificationMethod: 'Test with simulated fast user switching, session lock, and cold memory dump analysis.',
    },
    sampleCodeOrSchema: `// Memory zeroization on Windows session change
void OnSessionStateChanged(WTS_SESSION_NOTIFICATION* notification) {
    if (notification->dwState == WTS_SESSION_LOGOFF || notification->dwState == WTS_SESSION_LOCK) {
        SecureZeroMemory(g_DecryptedMasterKey, sizeof(g_DecryptedMasterKey));
        sqlite3_close(g_EncryptedDbHandle);
        g_SessionActive = false;
    }
}`,
  },
  {
    id: 'RFC-004',
    number: 4,
    questionNumber: 4,
    title: 'Crash-Safe State Machine & WAL Recovery Protocol',
    shortTitle: 'State Machine & WAL',
    category: 'Core',
    status: 'APPROVED',
    impactedRequirements: ['REQ-CORE-002', 'REQ-CORE-002a', 'REQ-REL-003', 'REQ-REL-003a', 'REQ-REL-003b', 'REQ-REL-006'],
    problemStatement: 'What transactional logging and recovery mechanism guarantees atomic recovery of incomplete task plans following ungraceful shutdowns without blind auto-resumption?',
    architecturalDecision: '11-State Deterministic Lifecycle Engine with Write-Ahead Log (WAL) and mandatory startup reconciliation to Halted_Requires_Inspection.',
    technicalDetails: {
      protocolOrFormat: 'Append-only binary WAL with CRC32 frame checksums and sync writes (FILE_FLAG_WRITE_THROUGH)',
      keyMechanisms: [
        '11 Explicit States: Initiated, Planning, Awaiting_Confirmation, Executing, Verifying, Completed, Failed, Cancelled, Timed_Out, Ambiguous_Uncertain, Halted_Requires_Inspection',
        'Completed, Failed, and Cancelled are strictly terminal; no transitions out permitted',
        'Post-crash startup recovers all uncompleted tasks to Halted_Requires_Inspection',
        'Per-node reconciliation summary: safe-to-resume, safe-to-retry, or safe-to-abandon',
      ],
      securityGuarantees: [
        'No task ever blindly executes side effects upon computer reboot or service crash',
        'Cumulative side-effect budget reconstructed directly from audit log',
      ],
      failureModes: [
        'Corrupt journal frame isolates damaged task and alerts user while maintaining safety locks',
      ],
      verificationMethod: 'Fault-injection power-cut simulation and terminal transition enforcement test.',
    },
    sampleCodeOrSchema: `// Recovery reconciliation evaluator
foreach (var task in UnfinishedTasksInJournal) {
    task.TransitionTo(TaskState.Halted_Requires_Inspection);
    task.ReconciliationMatrix = task.Nodes.Select(node => new NodeReconcileRecord {
        NodeId = node.Id,
        LastState = node.State,
        SideEffectApplied = CheckSideEffectStatus(node),
        SafeToResume = node.IsIdempotent || node.HasValidDedupKey,
        SafeToRetry = node.IsIdempotent,
        SafeToAbandon = !node.IsCriticalPath
    }).ToList();
}`,
  },
  {
    id: 'RFC-005',
    number: 5,
    questionNumber: 5,
    title: 'Manifest and Policy Authenticity Specification',
    shortTitle: 'Manifest & Policy Auth',
    category: 'Extensibility',
    status: 'APPROVED',
    impactedRequirements: ['REQ-EXT-003', 'REQ-EXT-004', 'REQ-SEC-001a', 'REQ-DEP-003'],
    problemStatement: 'What mechanism authenticates tool manifests and policy artifacts without prescribing vendor lock-in, while guaranteeing runtime immutability?',
    architecturalDecision: 'Detached Ed25519 Signatures with RFC 8785 Canonical JSON Serialization and Hardware/ACL-Protected Root Trust Anchor.',
    technicalDetails: {
      protocolOrFormat: 'Ed25519 (RFC 8032) signatures over Canonical JSON (RFC 8785)',
      keyMechanisms: [
        'Publisher manifest paired with .sig envelope verified before process spawn',
        'Root public keys pinned in Administrator-only protected filesystem directory (%ProgramFiles%\\JARVIS\\trust)',
        'In-memory manifest struct protected by VirtualProtect(PAGE_READONLY)',
        'Any memory tampering attempts trigger structured security fault and instant tool unload',
      ],
      securityGuarantees: [
        'Zero unauthorized modification of tool risk tiers, capabilities, or resource keys',
        'Policy artifact changes require HIGH_RISK_SIDE_EFFECT explicit authorization path',
      ],
      failureModes: [
        'Signature mismatch, expired publisher cert, or malformed canonical JSON causes immediate fail-closed rejection',
      ],
      verificationMethod: 'Cryptographic signature verification test suite and in-memory page write tamper attack.',
    },
    sampleCodeOrSchema: `// Canonical JSON hashing & Ed25519 verification
byte[] canonicalBytes = CanonicalJson.Serialize(manifest.Payload);
bool isValid = Ed25519.Verify(manifest.SignatureBytes, canonicalBytes, trustedPublisherPublicKey);
if (!isValid) {
    throw new SecurityIntegrityException("Tool manifest authenticity verification failed.");
}`,
  },
  {
    id: 'RFC-006',
    number: 6,
    questionNumber: 6,
    title: 'Untrusted-Content Provenance & Taint Lattice',
    shortTitle: 'Taint & Provenance Lattice',
    category: 'Security',
    status: 'APPROVED',
    impactedRequirements: ['REQ-SEC-005', 'REQ-BRW-004', 'REQ-VIS-003', 'REQ-MEM-007', 'REQ-AI-008'],
    problemStatement: 'How should provenance/taint metadata be attached, propagated transitively through summaries, memory, and intermediate transformations, and consumed by the confirmation gate?',
    architecturalDecision: '16-bit Bitfield Taint Lattice with Strict Transitive Propagation, Structural Metadata Non-Propagation, and Forced Write Confirmation.',
    technicalDetails: {
      protocolOrFormat: 'Bitfield Taint Lattice: 0x01 (Web), 0x02 (OCR), 0x04 (Plugin Output), 0x08 (Ext Model), 0x10 (Memory Derived)',
      keyMechanisms: [
        'Transitive rule: Any output value derived from tainted inputs inherits bitwise OR of parent taints',
        'Metadata exception: Pure structural metadata (length, type tag, structural position) does NOT propagate taint unless used as semantic parameter',
        'Memory laundering block: Memory records store taint bitfield; reading tainted memory taints downstream DAG nodes',
        'Write-action escalation: Any node with Taint != 0 that produces a write side-effect requires explicit human confirmation',
      ],
      securityGuarantees: [
        'Indirect prompt injection through web scraping or OCR cannot trigger silent automated writes',
        'AI reasoning cannot strip or sanitize taint tags',
      ],
      failureModes: [
        'If taint tag cannot be determined for external input, it defaults to 0xFFFF (MAX_TAINT)',
      ],
      verificationMethod: 'Adversarial prompt injection test suite; memory round-trip taint verification.',
    },
    sampleCodeOrSchema: `// Taint evaluation at plan node authorization
ushort combinedTaint = node.Parameters.Select(p => p.TaintFlags).Aggregate((a, b) => (ushort)(a | b));
if (combinedTaint != 0 && node.DeclaredSideEffect != SideEffectTier.READ_ONLY) {
    node.RequiredAuthTier = RiskClassification.HIGH_RISK_SIDE_EFFECT;
    node.FlaggedForTaintedWrite = true;
}`,
  },
  {
    id: 'RFC-007',
    number: 7,
    questionNumber: 7,
    title: 'Cryptographic Confirmation Binding & Secret Obfuscation',
    shortTitle: 'Confirmation Binding & Secrets',
    category: 'Security',
    status: 'APPROVED',
    impactedRequirements: ['REQ-CORE-004', 'REQ-SEC-007', 'REQ-SEC-008'],
    problemStatement: 'How should the confirmation payload be bound to the authorized operation (request ID, tool, parameters, resource keys, secrets) such that a less-trusted UI cannot spoof or transform authorizations, and secrets are not leaked?',
    architecturalDecision: 'HMAC-SHA256 Operation Digests with Non-Invertible Secret Token Fingerprints and Ephemeral User Gesture Nonces.',
    technicalDetails: {
      protocolOrFormat: 'HMAC-SHA256(SessionKey, ReqID || ToolID || ParamDigest || ResourceKeysDigest)',
      keyMechanisms: [
        'Digest binds request ID, tool identity, canonical parameters, and target resource keys',
        'Secret-bearing parameters displayed as Vault Credential KeyID (e.g., "[KeyID: #db_pass_9f]")',
        'No partial disclosure (last-N characters strictly prohibited to prevent oracle extraction)',
        'Secret contribution in digest uses HMAC-SHA256(HostSalt, RawSecret)',
        'Pending confirmation expires in 60s to Cancelled (not Approved)',
      ],
      securityGuarantees: [
        'Compromised UI cannot forge confirmation for an unprompted action or modify parameters in-flight',
        'Zero plaintext secret leakage into UI process memory, logs, or prompt views',
      ],
      failureModes: [
        'Parameter mismatch or expired nonce drops request immediately and logs security event',
      ],
      verificationMethod: 'Test with maliciously altered confirmation responses and replay attacks.',
    },
    sampleCodeOrSchema: `// Core verification of UI confirmation response
byte[] expectedDigest = ComputeHMAC(sessionKey, request.Id, request.ToolId, request.ParamHash, request.ResourceHash);
if (!CryptographicOperations.FixedTimeEquals(userResponse.Digest, expectedDigest)) {
    throw new SecurityException("Confirmation digest mismatch: operation parameters were tampered with!");
}`,
  },
  {
    id: 'RFC-008',
    number: 8,
    questionNumber: 8,
    title: 'Companion Channel Out-of-Band Pairing & Zero-Trust Protocol',
    shortTitle: 'Companion Trust Protocol',
    category: 'Android',
    status: 'APPROVED',
    impactedRequirements: ['REQ-AND-002', 'REQ-AND-003', 'REQ-AND-004', 'REQ-AND-005', 'REQ-AND-006', 'REQ-AND-007', 'REQ-AND-008', 'REQ-AND-009'],
    problemStatement: 'What pairing, session establishment, replay protection, revocation, and host-side confirmation mechanism ensures an Android companion cannot execute high-risk commands if compromised?',
    architecturalDecision: 'Noise Protocol Framework (Noise_XX_25519_ChaChaPoly) with QR-Code Proximity Pairing and Mandatory Host-Side Physical Confirmation for High-Risk Actions.',
    technicalDetails: {
      protocolOrFormat: 'Noise_XX with ephemeral ECDH X25519, ChaCha20-Poly1305, and BLAKE2s',
      keyMechanisms: [
        'Out-of-band QR code pairing exchanging static pubkeys via Bluetooth LE or direct probe',
        'Monotonic 64-bit sequence counters and +/- 5000ms timestamp replay window',
        'Host-side confirmation interlock: HIGH_RISK or CRITICAL commands require desktop user gesture',
        'Unconditional host revocation invalidating pairing token without companion cooperation',
      ],
      securityGuarantees: [
        'Compromise of mobile companion cannot silently execute financial, destructive, or OS actions',
        'Zero plaintext transmission over local Wi-Fi or relay networks',
      ],
      failureModes: [
        'Replayed sequence number drops connection immediately; idle session expires after 15 minutes',
      ],
      verificationMethod: 'Penetration test simulating stolen companion tokens and intercepted replays.',
    },
    sampleCodeOrSchema: `// Companion command ingress evaluation
if (cmd.RiskTier >= RiskClassification.HIGH_RISK_SIDE_EFFECT) {
    // REQ-AND-009: Mandatory host-side confirmation for companion commands
    Core.EnqueueHostConfirmationPrompt(cmd, source: "Companion_Device_" + cmd.DeviceId);
    return CommandStatus.AwaitingHostDesktopConfirmation;
}`,
  },
  {
    id: 'RFC-009',
    number: 9,
    questionNumber: 9,
    title: 'Execution Ownership Fencing & Revocation Leases',
    shortTitle: 'Fencing & Execution Leases',
    category: 'Core',
    status: 'APPROVED',
    impactedRequirements: ['REQ-CORE-005', 'REQ-CORE-003', 'REQ-REL-001', 'REQ-SIM-002'],
    problemStatement: 'How to realize execution-ownership such that stale workers cannot produce side effects after timeout or cancellation, and ambiguity holds are strictly enforced?',
    architecturalDecision: 'Monotonically Increasing 64-bit Generation Epochs, Capability Write-Leases, and Kernel Job Object Hard Fencing.',
    technicalDetails: {
      protocolOrFormat: '64-bit Generation Epoch tuple (EpochId, LeaseExpiryUtc, WorkerPID) stored in Core lock table',
      keyMechanisms: [
        'Every tool write ticket checks if CurrentEpoch == LockEpoch; ticket is rejected if epoch advanced',
        'On timeout or cancellation, Core increments EpochId and issues TerminateJobObject',
        'Ambiguity Hold Rule: If sub-process does not terminate cleanly within 500ms, state transitions to Ambiguous_Uncertain and resource keys remain LOCKED',
        'Timed_Out release permitted ONLY if tool manifest declared idempotent and safely abortable',
      ],
      securityGuarantees: [
        'Zero stale worker writes permitted after cancellation or timeout',
        'Prevents write/write race conditions between dead workers and fresh operations',
      ],
      failureModes: [
        'Worker process survivability results in Ambiguous_Uncertain lock until explicit human inspection',
      ],
      verificationMethod: 'Fault injection killing core mid-write and testing stale worker write rejection.',
    },
    sampleCodeOrSchema: `// Core fencing revocation routine
public void RevokeOwnership(ResourceKey key) {
    lock (resourceLockTable) {
        var lease = resourceLockTable[key];
        lease.CurrentEpoch++; // Invalidates all in-flight worker write tickets
        TerminateJobObject(lease.JobHandle, 1);
        if (!WaitForProcessExit(lease.ProcessHandle, 500)) {
            TransitionTo(TaskState.Ambiguous_Uncertain);
            // Resource key remains held per REQ-CORE-005
        }
    }
}`,
  },
  {
    id: 'RFC-010',
    number: 10,
    questionNumber: 10,
    title: 'Audit Log Hash-Chain & Split-Anchor Protection',
    shortTitle: 'Audit Hash-Chain & TPM Anchor',
    category: 'Reliability',
    status: 'APPROVED',
    impactedRequirements: ['REQ-DEP-002', 'REQ-DEP-002a', 'REQ-DEP-002b'],
    problemStatement: 'How to protect the audit-log chain anchor independently from the log itself so a writer with log access cannot redefine the anchor, and truncation/rollback is detectable on reboot?',
    architecturalDecision: 'Merkle Hash-Chained Write-Ahead Ledger with TPM 2.0 PCR-15 Extension and Windows Protected Service Registry Anchor.',
    technicalDetails: {
      protocolOrFormat: 'SHA-256 Merkle chain: H_i = SHA-256(H_{i-1} || SeqNo || Timestamp || Payload)',
      keyMechanisms: [
        'Every log record references digest of previous record back to GenesisHash',
        'Split Anchor: Latest head hash written to registry protected by dedicated NT SERVICE SID and extended into TPM 2.0 PCR-15',
        'Log directory isolated outside all workspace paths (%ProgramData%\\JARVIS\\audit)',
        'Boot-time verification: Full log re-hash verified against TPM and registry anchor before new tasks dispatch',
      ],
      securityGuarantees: [
        'Tamper evidence across entry modification, deletion, trailing truncation, and rollback',
        'Log writer cannot unilaterally redefine the anchor without triggering boot failure',
      ],
      failureModes: [
        'Anchor mismatch halts system in Halted_Requires_Inspection; audit corruption alert displayed',
      ],
      verificationMethod: 'Truncation and modification attack tests; reboot verification procedure test.',
    },
    sampleCodeOrSchema: `// Audit log record hashing & TPM extension
byte[] newHash = SHA256.HashData(Concat(previousHash, record.SeqNo, record.TimestampUtc, record.PayloadBytes));
record.CurrentHash = newHash;
AppendRecord(record);
Tpm2.PcrExtend(PcrIndex.Pcr15, newHash);
IsolatedServiceRegistry.UpdateAnchor(newHash);`,
  },
  {
    id: 'RFC-011',
    number: 11,
    questionNumber: 11,
    title: 'Semantic Deduplication Key Derivation Engine',
    shortTitle: 'Semantic Dedup Keys',
    category: 'Extensibility',
    status: 'APPROVED',
    impactedRequirements: ['REQ-EXT-005', 'REQ-EXT-007', 'REQ-REL-006', 'REQ-REL-003b'],
    problemStatement: 'How to derive deduplication keys for non-idempotent tools such that derivation is stable across replans, crash recovery, and user retries while sensitive to semantic parameter changes?',
    architecturalDecision: 'RFC 8785 Canonical JSON Hashing of Semantic Parameters (excluding volatile fields) mapped across DAG replan identities.',
    technicalDetails: {
      protocolOrFormat: 'DedupKey = SHA-256(Namespace || ToolId || CanonicalJson(SemanticParams) || ResourceKey)',
      keyMechanisms: [
        'Volatile fields (UI session ID, animation tick, debug trace) flagged in manifest and omitted from hash',
        'Replan identity mapping (REQ-REL-006) preserves DedupKey across substituted replacement nodes',
        'Persistent deduplication ledger consulted before dispatching any non-idempotent action',
        'User-initiated retries subject to identical deduplication gate',
      ],
      securityGuarantees: [
        'Prevents duplicate real-world side effects (double emails, repeated charges, duplicate file creates)',
      ],
      failureModes: [
        'Matched deduplication key rejects re-execution unless previous instance was definitively Failed',
      ],
      verificationMethod: 'Test across DAG replan boundaries and crash recovery scenarios.',
    },
    sampleCodeOrSchema: `// Semantic deduplication key derivation
var filteredParams = node.Parameters.Where(p => !p.IsVolatile).ToDictionary(p => p.Key, p => p.Value);
byte[] canonicalBytes = CanonicalJson.Serialize(filteredParams);
string dedupKey = Convert.ToHexString(SHA256.HashData(Concat(node.ToolId, canonicalBytes, node.ResourceKey)));
if (DedupLedger.HasExecutedSuccessfully(dedupKey)) {
    throw new DuplicateExecutionBlockedException(dedupKey);
}`,
  },
  {
    id: 'RFC-012',
    number: 12,
    questionNumber: 12,
    title: 'Concrete Uncertainty Taxonomy & Per-Class Recovery Engine',
    shortTitle: 'Uncertainty Taxonomy',
    category: 'Simulation',
    status: 'APPROVED',
    impactedRequirements: ['REQ-SIM-002a', 'REQ-SIM-002b', 'REQ-SIM-002', 'REQ-REL-005'],
    problemStatement: 'What concrete uncertainty classes and per-class recovery rules populate the taxonomy required by REQ-SIM-002a, and how do manifests declare which apply?',
    architecturalDecision: '5 Concrete Ambiguity Classes (Network Drop, Partial Flush, Crash Unack, External Desync, Active Handle Timeout) with Structured Error Payloads.',
    technicalDetails: {
      protocolOrFormat: 'Structured Ambiguous_Uncertain error packet declaring ambiguity class code and inspected resource state',
      keyMechanisms: [
        'UNC-01 (NETWORK_INDETERMINATE_POST): Holds locks; offers status probe or manual rollback',
        'UNC-02 (PARTIAL_FILE_FLUSH): Quarantines temp file; offers revert to backup or overwrite',
        'UNC-03 (SUBPROCESS_CRASH_UNACK): Mini-dump captured; resource locked until manual inspection',
        'UNC-04 (EXTERNAL_SYSTEM_DESYNC): Quarantines dedup key; offers audit query',
        'UNC-05 (TIMEOUT_WITH_ACTIVE_HANDLE): Hard kills process; flags for crash recovery',
      ],
      securityGuarantees: [
        'Eliminates uniform generic failure handling for physically diverse failure modes',
        'UI strictly distinguishes Failed vs Ambiguous_Uncertain vs Completed',
      ],
      failureModes: [
        'Tool failing to return structured ambiguity when state is indeterminate is flagged as manifest violation',
      ],
      verificationMethod: 'Fault injection per uncertainty class; UI distinction verification.',
    },
    sampleCodeOrSchema: `// Tool structured ambiguity result
public class AmbiguousExecutionResult : ToolResult {
    public UncertaintyClass ClassCode { get; set; } = UncertaintyClass.UNC_01_NETWORK_INDETERMINATE_POST;
    public string Details { get; set; } = "TCP connection reset after HTTP POST body sent.";
    public ResourceSnapshot TentativeState { get; set; }
}`,
  },
  {
    id: 'RFC-013',
    number: 13,
    questionNumber: 13,
    title: 'Simulation Fidelity Model & Operational Completeness',
    shortTitle: 'Simulation Fidelity Model',
    category: 'Simulation',
    status: 'APPROVED',
    impactedRequirements: ['REQ-SIM-001', 'REQ-SIM-001a', 'REQ-SIM-001b'],
    problemStatement: 'How should FULLY_SIMULATABLE, PARTIALLY_SIMULATABLE, and NOT_SIMULATABLE be operationally defined, and how does SIMULATION_INCOMPLETE gate execution?',
    architecturalDecision: 'Three-Tier Operational Fidelity Classification with Mandatory Risk Acknowledgment Waivers for Incomplete Nodes.',
    technicalDetails: {
      protocolOrFormat: 'Manifest simulation enum + DAG Simulation Completeness Token',
      keyMechanisms: [
        'FULLY_SIMULATABLE: Implements isolated sandbox test-double with zero real OS handles or network calls',
        'PARTIALLY_SIMULATABLE: Validates parameters, schemas, and resource availability but cannot mock remote state',
        'NOT_SIMULATABLE: Only static type/syntax checks possible',
        'SIMULATION_INCOMPLETE token required if any node is PARTIAL or NOT simulatable',
      ],
      securityGuarantees: [
        'Zero accidental real-world side effects during dry-run simulation',
        'User is explicitly warned which specific nodes carry unverified dry-run risk',
      ],
      failureModes: [
        'Simulation attempting to acquire real network socket or real filesystem handle fails closed',
      ],
      verificationMethod: 'Simulation sandbox isolation test; incomplete DAG authorization waiver test.',
    },
    sampleCodeOrSchema: `// Plan simulation completeness evaluator
var incompleteNodes = plan.Nodes.Where(n => n.SimulationLevel != SimulationFidelity.FULLY_SIMULATABLE).ToList();
if (incompleteNodes.Any()) {
    plan.Status = PlanStatus.SIMULATION_INCOMPLETE;
    plan.IncompleteNodeIds = incompleteNodes.Select(n => n.Id).ToList();
    // Requires distinct user acknowledgment per REQ-SIM-001b
}`,
  },
  {
    id: 'RFC-014',
    number: 14,
    questionNumber: 14,
    title: 'Windows Session Boundary & Credential Purge Protocol',
    shortTitle: 'Session Boundary Protocol',
    category: 'Windows',
    status: 'APPROVED',
    impactedRequirements: ['REQ-WIN-004', 'REQ-MEM-006', 'REQ-MEM-001'],
    problemStatement: 'How to enforce the background-service boundary across Windows logon, logoff, lock, and fast user switch events so credentials are wiped on logout while queues persist?',
    architecturalDecision: 'WTSRegisterSessionNotification Event Controller with In-Memory Cryptographic Zeroization and Queued Task Freezing.',
    technicalDetails: {
      protocolOrFormat: 'Win32 WTSRegisterSessionNotification API and SecureZeroMemory',
      keyMechanisms: [
        'Intercepts WTS_SESSION_LOGOFF, WTS_SESSION_LOCK, WTS_CONSOLE_DISCONNECT',
        'On logoff: Decrypted master keys, JWTs, and passwords scrubbed via SecureZeroMemory',
        'Volatile short-term context destroyed; persistent encrypted databases closed',
        'Credential-dependent tasks paused in queue; only declared READ_ONLY background tasks may run',
      ],
      securityGuarantees: [
        'Zero credential leakage across shared multi-user workstations',
        'Background execution cannot impersonate logged-off user tokens',
      ],
      failureModes: [
        'Service crash during zeroization safely defaults to locked disk databases',
      ],
      verificationMethod: 'Automated fast user switching and session lock integration tests.',
    },
    sampleCodeOrSchema: `// Windows Session notification hook
LRESULT CALLBACK SessionWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    if (uMsg == WM_WTSSESSION_CHANGE) {
        if (wParam == WTS_SESSION_LOGOFF) {
            CredentialManager.ScrubAllKeys();
            TaskQueue.FreezeCredentialDependentTasks();
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}`,
  },
  {
    id: 'RFC-015',
    number: 15,
    questionNumber: 15,
    title: 'Browser External Side-Effect Classifier & Contract Parser',
    shortTitle: 'Browser Side-Effect Classifier',
    category: 'Browser',
    status: 'APPROVED',
    impactedRequirements: ['REQ-BRW-005', 'REQ-SEC-001', 'REQ-SEC-005'],
    problemStatement: 'How to classify browser-initiated requests by observed/declared external effect rather than HTTP verb, reconciling read-only POSTs with destructive mutations?',
    architecturalDecision: 'Declarative Contract Parser (OpenAPI/GraphQL AST) with Conservative HTTP POST Mutation Fallback and Ephemeral Profile Segregation.',
    technicalDetails: {
      protocolOrFormat: 'HTTP network interceptor analyzing OpenAPI contracts, GraphQL query roots, and form semantics',
      keyMechanisms: [
        'Fast Path: Declared read-only contracts (OpenAPI readOnly: true or GraphQL query { ... }) classified as READ_ONLY',
        'Fallback: In the absence of machine-readable contract, POST/PUT/DELETE conservatively classified as LOW_RISK_SIDE_EFFECT or HIGH_RISK_SIDE_EFFECT',
        'Browser automation runs in ephemeral isolated Chromium profile with zero access to user primary session',
      ],
      securityGuarantees: [
        'No stealth external side effects (billing, account changes, emails) without risk gating',
        'User main session cookies and passwords completely isolated from automated sessions',
      ],
      failureModes: [
        'Ambiguous endpoint contract defaults to conservative side-effect classification',
      ],
      verificationMethod: 'Test with GraphQL queries vs mutations and undeclared POST endpoints.',
    },
    sampleCodeOrSchema: `// Request side-effect classifier
public SideEffectTier ClassifyBrowserRequest(HttpRequest req) {
    if (req.Method == "GET") return SideEffectTier.READ_ONLY;
    if (IsDeclaredReadOnlyContract(req.Endpoint)) return SideEffectTier.READ_ONLY;
    if (IsGraphQLPureQuery(req.Body)) return SideEffectTier.READ_ONLY;
    // REQ-BRW-005: Conservative fallback for uncontracted POST
    return SideEffectTier.LOW_RISK_SIDE_EFFECT;
}`,
  },
];

export const MASTER_REQUIREMENTS_LIST: MasterRequirement[] = [
  { id: 'REQ-CORE-001', priority: 'MUST', category: 'Core', title: 'Centralized Control Core', statement: 'All requests, events, and UI interactions parsed and executed exclusively through single control core.', securityImplications: 'Eliminates direct tool invocation from UI or rogue threads.', verificationMethod: 'Static Analysis', rfcMapping: 'RFC-001' },
  { id: 'REQ-CORE-002', priority: 'MUST', category: 'Core', title: 'Deterministic Lifecycle State Machine', statement: 'Core maintains deterministic lifecycle state machine for every request with versioned transition table.', securityImplications: 'Prevents orphan tool execution during state transition delays.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-CORE-002a', priority: 'MUST', category: 'Core', title: 'Terminal State Lock', statement: 'Completed, Failed, and Cancelled are strictly terminal; no transitions out permitted.', securityImplications: 'Blocks replay of completed side effects via state manipulation.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-CORE-003', priority: 'MUST', category: 'Core', title: 'Resource-Keyed Serialization', statement: 'Serializes all actions classified LOW_RISK_SIDE_EFFECT or higher against declared resource keys.', securityImplications: 'Prevents race-condition privilege escalation and file corruption.', verificationMethod: 'Concurrency Test', rfcMapping: 'RFC-009' },
  { id: 'REQ-CORE-003a', priority: 'MUST', category: 'Core', title: 'Replan/Write Interleaving Prohibition', statement: 'Replanning deltas shall not be merged into in-flight serialized writes.', securityImplications: 'Blocks TOCTOU permission escalation across replans.', verificationMethod: 'Fault Injection', rfcMapping: 'RFC-004' },
  { id: 'REQ-CORE-004', priority: 'MUST', category: 'Core', title: 'UI Trust Boundary', statement: 'UI process treated as less trusted than control core; confirmations bound to request ID & digest.', securityImplications: 'Prevents compromised UI from impersonating confirmations or altering parameters.', verificationMethod: 'Test with Tampered Payloads', rfcMapping: 'RFC-007' },
  { id: 'REQ-CORE-005', priority: 'MUST', category: 'Core', title: 'Execution Ownership / Fencing', statement: 'Operations hold revocable ownership grant; revoked workers prevented from producing side effects.', securityImplications: 'Prevents stale or orphaned workers from mutating state.', verificationMethod: 'Fault Injection', rfcMapping: 'RFC-009' },
  { id: 'REQ-AI-001', priority: 'MUST', category: 'AI', title: 'Provider Substitution Without Core Change', statement: 'Support substituting reasoning, planning, vision, local, or fast-response providers without core logic modification.', securityImplications: 'Vendor independence and zero lock-in.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-001' },
  { id: 'REQ-AI-002', priority: 'MUST', category: 'AI', title: 'Privacy-Hard-Filtered Routing', statement: 'Route model calls at runtime according to declared task attributes; privacy constraints are hard filter.', securityImplications: 'Prevents privacy-violating fallback under cost or latency pressure.', verificationMethod: 'Test', rfcMapping: 'RFC-006' },
  { id: 'REQ-AI-003', priority: 'MUST', category: 'AI', title: 'Explicit DAG Planning', statement: 'Decompose complex intents into explicit DAG plan with manifest IDs and concrete parameters before execution.', securityImplications: 'Prevents hidden steps without plan re-validation.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-AI-004', priority: 'MUST', category: 'AI', title: 'Replan Against Original Intent', statement: 'Replanning mid-execution resubmits entire delta through policy evaluator and budget checks.', securityImplications: 'Blocks privilege escalation via iterative context manipulation.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-AI-004a', priority: 'MUST', category: 'AI', title: 'Cumulative Side-Effect Budget', statement: 'Maintain cumulative side-effect budget per request; exceeding budget halts execution.', securityImplications: 'Closes boiling frog escalation vector.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-AI-005', priority: 'MUST', category: 'AI', title: 'External Endpoint Integrity', statement: 'Model communications encrypted; verify endpoint identity before prompt transmission.', securityImplications: 'Prevents prompt exposure to impersonated endpoints.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-AI-006', priority: 'MUST', category: 'AI', title: 'Provider Failure Fail-Closed', statement: 'If provider fails or returns malformed output, fail closed; no silent downgrade.', securityImplications: 'Closes fallback-based downgrade paths.', verificationMethod: 'Fault Injection', rfcMapping: 'RFC-012' },
  { id: 'REQ-AI-007', priority: 'MUST', category: 'AI', title: 'Endpoint Disclosure', statement: 'Maintain inspectable record of external endpoints contacted, categories of data sent, and user consent.', securityImplications: 'Ensures third-party disclosure is auditable.', verificationMethod: 'Inspection', rfcMapping: 'RFC-010' },
  { id: 'REQ-AI-008', priority: 'MUST', category: 'AI', title: 'Manifest-Derived Classification', statement: 'Risk classification derived exclusively from manifest and parameters; AI cannot provide risk labels.', securityImplications: 'Primary defense against AI-mediated privilege escalation.', verificationMethod: 'Test with Mislabelled Plans', rfcMapping: 'RFC-005' },
  { id: 'REQ-AI-009', priority: 'MUST', category: 'AI', title: 'Model Output Schema Validation', statement: 'All model outputs validated against versioned schema before use; invalid output fails closed.', securityImplications: 'Blocks injection via malformed model responses.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-AI-011', priority: 'MUST', category: 'AI', title: 'Degraded Offline Mode', statement: 'Define degraded operating mode for absence of external providers with zero relaxed security.', securityImplications: 'Prevents offline mode from becoming security-relaxed state.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-012' },
  { id: 'REQ-AI-012', priority: 'MUST', category: 'AI', title: 'Quota Exhaustion Fail-Closed', statement: 'Provider quota exhaustion fails closed with user-visible reason; no automatic downgrade.', securityImplications: 'Closes quota-pressure downgrade path.', verificationMethod: 'Test', rfcMapping: 'RFC-012' },
  { id: 'REQ-VOI-001', priority: 'MUST', category: 'Voice', title: 'Pre/Post-Wake Audio Boundary', statement: 'Continuously monitor local wake word; pre-wake audio shall not leave host.', securityImplications: 'Zero ambient audio exfiltration prior to wake.', verificationMethod: 'Network Analysis', rfcMapping: 'RFC-001' },
  { id: 'REQ-VOI-002', priority: 'MUST', category: 'Voice', title: 'Tiered STT Latency Target', statement: 'Sub-500ms partial transcript on recommended tier; sub-1500ms final on minimum baseline.', securityImplications: 'Local speech models isolated.', verificationMethod: 'Benchmark', rfcMapping: 'RFC-001' },
  { id: 'REQ-VOI-003', priority: 'MUST', category: 'Voice', title: 'Barge-In With State-Machine Routing', statement: 'Streaming TTS output immediately interrupted on speech; barge-in routes through core state machine.', securityImplications: 'Prevents ambiguous cancellation of high-risk actions.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-VOI-004', priority: 'MUST', category: 'Voice', title: 'Microphone Capture Indicator', statement: 'Persistent user-visible indicator reflecting actual capture state, not requested state.', securityImplications: 'Prevents silent capture states.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-001' },
  { id: 'REQ-VIS-001', priority: 'MUST', category: 'Vision', title: 'Consent-Bounded Capture', statement: 'Capture display regions only upon explicit user request or declared plan node manifest scope.', securityImplications: 'Bounds visual capture authority.', verificationMethod: 'Test', rfcMapping: 'RFC-002' },
  { id: 'REQ-VIS-002', priority: 'MUST', category: 'Vision', title: 'Partial Redaction, No Guarantee', statement: 'Apply local redaction pass for passwords, cards, and keys before external transmission.', securityImplications: 'Critical privacy layer, acknowledged as partial.', verificationMethod: 'Test', rfcMapping: 'RFC-007' },
  { id: 'REQ-VIS-003', priority: 'MUST', category: 'Vision', title: 'Screen Text As Untrusted', statement: 'Text extracted from screen captures treated as untrusted under REQ-SEC-005.', securityImplications: 'Blocks visual prompt-injection escalation.', verificationMethod: 'Test', rfcMapping: 'RFC-006' },
  { id: 'REQ-MEM-001', priority: 'MUST', category: 'Memory', title: 'Volatile Short-Term Context', statement: 'Maintain volatile session memory cleared upon exit or logout.', securityImplications: 'Prevents cross-session context bleed.', verificationMethod: 'Test', rfcMapping: 'RFC-014' },
  { id: 'REQ-MEM-002', priority: 'MUST', category: 'Memory', title: 'Encrypted Local Memory', statement: 'Long-term memory stored in encrypted store protected by OS user-bound secret storage.', securityImplications: 'Key bound to authenticated user identity.', verificationMethod: 'Inspection & Test', rfcMapping: 'RFC-003' },
  { id: 'REQ-MEM-003', priority: 'MUST', category: 'Memory', title: 'Memory Audit UI With Partition Display', statement: 'User interface to inspect, modify, export, and hard-delete memory with provenance tags.', securityImplications: 'Guarantees hard-deletion semantics.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-006' },
  { id: 'REQ-MEM-004', priority: 'MUST', category: 'Memory', title: 'No Authorization From Memory', statement: 'Long-term memory shall never grant persistent permission overrides or bypass security.', securityImplications: 'Direct defense against permission bypass via memory.', verificationMethod: 'Static Analysis', rfcMapping: 'RFC-005' },
  { id: 'REQ-MEM-005', priority: 'MUST', category: 'Memory', title: 'Retention & Minimization', statement: 'Configurable default retention periods for audio, captures, and logs; raw audio not persisted.', securityImplications: 'Reduces sensitive data exposure window.', verificationMethod: 'Test', rfcMapping: 'RFC-003' },
  { id: 'REQ-MEM-006', priority: 'MUST', category: 'Memory', title: 'Per-User Isolation', statement: 'Memory, credentials, and session state scoped to user identity; cleared on logout.', securityImplications: 'Enforces per-user workstation isolation.', verificationMethod: 'Test', rfcMapping: 'RFC-014' },
  { id: 'REQ-MEM-007', priority: 'MUST', category: 'Memory', title: 'Memory Provenance', statement: 'Memory records carry provenance; untrusted sources remain untrusted when retrieved.', securityImplications: 'Closes memory-laundering injection vector.', verificationMethod: 'Test', rfcMapping: 'RFC-006' },
  { id: 'REQ-BRW-001', priority: 'MUST', category: 'Browser', title: 'Untrusted Retrieval', statement: 'Browser subsystem treats all retrieved web content as untrusted input; scripts disabled in extraction.', securityImplications: 'Web content is primary prompt-injection vector.', verificationMethod: 'Test', rfcMapping: 'RFC-015' },
  { id: 'REQ-BRW-002', priority: 'MUST', category: 'Browser', title: 'Credential-Isolated Automation', statement: 'Browser automation runs in isolated profile distinct from primary browser session.', securityImplications: 'Protects active browser cookies and credentials.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-015' },
  { id: 'REQ-BRW-003', priority: 'MUST', category: 'Browser', title: 'Download/File Boundary', statement: 'Downloads and file access constrained strictly to designated workspace.', securityImplications: 'Closes download-based sandbox escape.', verificationMethod: 'Test', rfcMapping: 'RFC-015' },
  { id: 'REQ-BRW-004', priority: 'MUST', category: 'Browser', title: 'Web Content Cannot Modify Security State', statement: 'Retrieved content tagged with provenance and cannot alter manifests, policy, or authorization.', securityImplications: 'Primary defense against web prompt injection.', verificationMethod: 'Test', rfcMapping: 'RFC-006' },
  { id: 'REQ-BRW-005', priority: 'MUST', category: 'Browser', title: 'Browser External Side-Effect Classification', statement: 'Outbound requests classified by observed/declared effect, not HTTP verb; uncontracted POST is side-effect.', securityImplications: 'Closes browser-mediated side-effect bypass.', verificationMethod: 'Test', rfcMapping: 'RFC-015' },
  { id: 'REQ-WIN-001', priority: 'MUST', category: 'Windows', title: 'Structured-Surface-First Automation', statement: 'Prefer structured semantically-addressed automation; coordinate synthesis is logged fallback.', securityImplications: 'Reduces misdirected input and unintended targets.', verificationMethod: 'Inspection & Test', rfcMapping: 'RFC-002' },
  { id: 'REQ-WIN-002', priority: 'MUST', category: 'Windows', title: 'Cross-Integrity Prohibition', statement: 'Cannot interact with process whose integrity exceeds system own; unsigned binaries require critical mode.', securityImplications: 'Prevents unauthorized UAC elevation.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-WIN-003', priority: 'MUST', category: 'Windows', title: 'Absolute Workspace Write Containment', statement: 'File modifications strictly constrained to user workspaces; path traversal and symlinks canonicalized.', securityImplications: 'Eliminates path traversal and OS corruption.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-WIN-004', priority: 'MUST', category: 'Windows', title: 'Background Session Boundary', statement: 'Background operation without user session limited to uncredentialed READ_ONLY tasks.', securityImplications: 'Preserves user session trust boundary.', verificationMethod: 'Test', rfcMapping: 'RFC-014' },
  { id: 'REQ-WIN-005', priority: 'MUST', category: 'Windows', title: 'Persistence-Relevant Actions Are High-Risk', statement: 'Actions modifying autostart, scheduled tasks, or security config classified HIGH_RISK minimum.', securityImplications: 'Closes reversible-persistence escalation.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-EXT-001', priority: 'MUST', category: 'Extensibility', title: 'Complete Manifest Schema', statement: 'Every tool exposes strongly-typed manifest with side-effects, risk class, resource keys, and idempotency.', securityImplications: 'Tools strictly scoped to declared manifest.', verificationMethod: 'Inspection', rfcMapping: 'RFC-005' },
  { id: 'REQ-EXT-002', priority: 'MUST', category: 'Extensibility', title: 'Testable Isolation Bounds', statement: 'Plugins run in sandboxed sub-processes with restricted tokens and bounded workspace/network.', securityImplications: 'Out-of-bounds access blocked by OS boundaries.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-EXT-003', priority: 'MUST', category: 'Extensibility', title: 'Manifest Authenticity', statement: 'Every manifest authenticated by publisher identity before loading; unauthenticated rejected.', securityImplications: 'Blocks silent downgrade of tool risk class.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-EXT-004', priority: 'MUST', category: 'Extensibility', title: 'Manifest Immutability at Runtime', statement: 'Manifest risk classifications immutable at runtime; attempted modification unloads tool.', securityImplications: 'Reinforces classification integrity.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-EXT-005', priority: 'MUST', category: 'Extensibility', title: 'Idempotency Declaration', statement: 'Every manifest declares idempotency; retries permitted only for idempotent or dedup-keyed tools.', securityImplications: 'Prevents duplicate side effects.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-EXT-006', priority: 'MUST', category: 'Extensibility', title: 'Plugin-to-Plugin Isolation', statement: 'Plugins communicate only with control core, never directly with other plugins.', securityImplications: 'Contains cross-plugin confused-deputy attacks.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-EXT-007', priority: 'MUST', category: 'Extensibility', title: 'Stable Deduplication Identity', statement: 'Non-idempotent nodes carry dedup key derived from semantic identity, not instance ID.', securityImplications: 'Closes duplication-based authorization bypass.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-EXT-008', priority: 'MUST', category: 'Extensibility', title: 'Idempotency Mismatch Detection', statement: 'Detect and log idempotency mismatches; revoke declaration if tool duplicates side effects.', securityImplications: 'Feedback loop for false idempotency claims.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-SEC-001', priority: 'MUST', category: 'Security', title: 'Four-Tier Risk Framework', statement: 'Actions categorized into READ_ONLY, LOW_RISK_SIDE_EFFECT, HIGH_RISK_SIDE_EFFECT, CRITICAL_SYSTEM.', securityImplications: 'Primary core defense against runaways and injection.', verificationMethod: 'Demonstration & Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-SEC-001a', priority: 'MUST', category: 'Security', title: 'Authenticated Policy Artifact', statement: 'Auto-approval policy defined in authenticated versioned policy artifact modifiable only via HIGH_RISK.', securityImplications: 'Prevents policy injection.', verificationMethod: 'Inspection & Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-SEC-001b', priority: 'MUST', category: 'Security', title: 'Parameter-Based Tier Re-Evaluation', statement: 'Risk classification re-evaluated against actual parameter values at execution time.', securityImplications: 'Closes parameter-based tier downgrade.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-SEC-001c', priority: 'MUST', category: 'Security', title: 'Classification Precedence', statement: 'When multiple risk criteria apply, classify at highest applicable tier.', securityImplications: 'Prevents lowest-denominator classification.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
  { id: 'REQ-SEC-003', priority: 'MUST', category: 'Security', title: 'OS-Protected Credential Store', statement: 'Credentials stored in OS credential store; never logged, prompt-injected, or exposed.', securityImplications: 'Prevents credential exfiltration.', verificationMethod: 'Static Analysis', rfcMapping: 'RFC-003' },
  { id: 'REQ-SEC-004', priority: 'MUST', category: 'Security', title: 'No Cached Permission Bypass', statement: 'Cached runtime state or historical approvals shall never bypass security checks for new tasks.', securityImplications: 'Direct defense against TOCTOU.', verificationMethod: 'Test', rfcMapping: 'RFC-004' },
  { id: 'REQ-SEC-005', priority: 'MUST', category: 'Security', title: 'Untrusted-Content Provenance & Containment', statement: 'Untrusted content tagged with provenance; tainted writes force explicit human confirmation.', securityImplications: 'Primary containment for untrusted-content attacks.', verificationMethod: 'Test', rfcMapping: 'RFC-006' },
  { id: 'REQ-SEC-006', priority: 'MUST', category: 'Security', title: 'Clock-Manipulation Resistance', statement: 'Security-relevant time comparisons resistant to wall-clock manipulation; backwards jump fails closed.', securityImplications: 'Closes clock-manipulation bypass.', verificationMethod: 'Test', rfcMapping: 'RFC-010' },
  { id: 'REQ-SEC-007', priority: 'MUST', category: 'Security', title: 'Confirmation Integrity & Binding', statement: 'Confirmation prompts describe actual operation from authenticated data; bound to request & digest.', securityImplications: 'Blocks confirmation spoofing and replay.', verificationMethod: 'Test', rfcMapping: 'RFC-007' },
  { id: 'REQ-SEC-007a', priority: 'MUST', category: 'Security', title: 'Confirmation Lifetime', statement: 'Pending confirmations expire to Cancelled, not Approved; user notified at next session.', securityImplications: 'Closes timeout-as-approval vector.', verificationMethod: 'Test', rfcMapping: 'RFC-007' },
  { id: 'REQ-SEC-008', priority: 'MUST', category: 'Security', title: 'Secret Parameters in Confirmation', statement: 'Confirmation prompts display non-invertible identifiers; zero partial disclosure (no last-N characters).', securityImplications: 'Prevents secret leakage via confirmation UI.', verificationMethod: 'Test', rfcMapping: 'RFC-007' },
  { id: 'REQ-SIM-001', priority: 'MUST', category: 'Simulation', title: 'Isolated Dry-Run (Attempt)', statement: 'Support dry-run simulation mode executing in isolated mock environment without real OS handles.', securityImplications: 'Non-destructive verification boundary.', verificationMethod: 'Test', rfcMapping: 'RFC-013' },
  { id: 'REQ-SIM-001a', priority: 'MUST', category: 'Simulation', title: 'Fidelity Declaration', statement: 'Manifests declare FULLY_SIMULATABLE, PARTIALLY_SIMULATABLE, or NOT_SIMULATABLE.', securityImplications: 'Prevents false confidence from partial simulation.', verificationMethod: 'Inspection', rfcMapping: 'RFC-013' },
  { id: 'REQ-SIM-001b', priority: 'MUST', category: 'Simulation', title: 'Incomplete-Simulation Communication', statement: 'Plans with partial simulation marked SIMULATION_INCOMPLETE; requires explicit acknowledgment.', securityImplications: 'Prevents authorization based on false simulation completeness.', verificationMethod: 'Test', rfcMapping: 'RFC-013' },
  { id: 'REQ-SIM-002', priority: 'MUST', category: 'Simulation', title: 'Ambiguity Halting Engine', statement: 'Non-deterministic outcome flags Ambiguous_Uncertain; halts downstream; locks resource keys.', securityImplications: 'Stops unsafe retries and duplicate side effects.', verificationMethod: 'Fault Injection', rfcMapping: 'RFC-012' },
  { id: 'REQ-SIM-002a', priority: 'MUST', category: 'Simulation', title: 'Uncertainty Taxonomy', statement: 'Define taxonomy of uncertain outcomes with per-class recovery rules; manifests declare applicable classes.', securityImplications: 'Prevents uniform handling of non-uniform failures.', verificationMethod: 'Test', rfcMapping: 'RFC-012' },
  { id: 'REQ-SIM-002b', priority: 'MUST', category: 'Simulation', title: 'Structured Ambiguity Reporting', statement: 'Tools returning ambiguous condition must return structured Ambiguous_Uncertain packet.', securityImplications: 'Prevents loss of ambiguity information.', verificationMethod: 'Test', rfcMapping: 'RFC-012' },
  { id: 'REQ-SIM-002c', priority: 'MUST', category: 'Simulation', title: 'User-Facing Uncertainty Distinction', statement: 'UI distinguishes Failed, Ambiguous_Uncertain, and Completed with distinct presentation.', securityImplications: 'Preserves user decision quality.', verificationMethod: 'Demonstration', rfcMapping: 'RFC-012' },
  { id: 'REQ-REL-001', priority: 'MUST', category: 'Reliability', title: 'Timeout With Observable Cancellation', statement: 'Execution timeout revokes ownership; cancellation observable as inability to produce side effects.', securityImplications: 'Mitigates resource starvation and unsafe timeouts.', verificationMethod: 'Test', rfcMapping: 'RFC-009' },
  { id: 'REQ-REL-002', priority: 'MUST', category: 'Reliability', title: 'Retry Prohibition on Side Effects', statement: 'Prohibit background retry for HIGH_RISK or CRITICAL; LOW_RISK retry only if idempotent or dedup-keyed.', securityImplications: 'Eliminates automated compounding side effects.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-REL-003', priority: 'MUST', category: 'Reliability', title: 'Safe Crash Recovery', statement: 'On ungraceful restart, recover all unfinished tasks to Halted_Requires_Inspection; no auto-resume.', securityImplications: 'Mitigates unsafe crash-recovery assumptions.', verificationMethod: 'Crash Simulation', rfcMapping: 'RFC-004' },
  { id: 'REQ-REL-003a', priority: 'MUST', category: 'Reliability', title: 'Per-Node Reconciliation', statement: 'Post-crash summary presents safe-to-resume, safe-to-retry, or safe-to-abandon per node.', securityImplications: 'Prevents unsafe auto-resumption.', verificationMethod: 'Crash Simulation', rfcMapping: 'RFC-004' },
  { id: 'REQ-REL-003b', priority: 'MUST', category: 'Reliability', title: 'Crash Recovery Deduplication', statement: 'Manual resumption or retry after crash subject to deduplication check.', securityImplications: 'Closes crash-recovery duplication path.', verificationMethod: 'Crash Simulation', rfcMapping: 'RFC-011' },
  { id: 'REQ-REL-004', priority: 'MUST', category: 'Reliability', title: 'Resource Bounds', statement: 'Enforce bounds on concurrent requests, queue size, per-tool memory, and process count; fails closed.', securityImplications: 'Mitigates local resource-starvation DoS.', verificationMethod: 'Test', rfcMapping: 'RFC-001' },
  { id: 'REQ-REL-005', priority: 'MUST', category: 'Reliability', title: 'Tool Crash Classification', statement: 'Tool crash without structured outcome recorded as Ambiguous_Uncertain unless declared safely abortable.', securityImplications: 'Prevents silent outcome loss on crash.', verificationMethod: 'Fault Injection', rfcMapping: 'RFC-012' },
  { id: 'REQ-REL-006', priority: 'MUST', category: 'Reliability', title: 'Stable Node Identity Across Replans', statement: 'Plan nodes assigned stable identity; replanned node mapping exposed to recovery and dedup.', securityImplications: 'Prevents duplicate execution via identity confusion.', verificationMethod: 'Test', rfcMapping: 'RFC-011' },
  { id: 'REQ-DEP-001', priority: 'MUST', category: 'Deployment', title: 'Declared-Registration Packaging', statement: 'Production target deployable as isolated package declaring all host registrations in manifest.', securityImplications: 'Prevents dependency hijacking.', verificationMethod: 'Inspection', rfcMapping: 'RFC-001' },
  { id: 'REQ-DEP-002', priority: 'MUST', category: 'Deployment', title: 'Chained Tamper-Evident Logging', statement: 'Audit logs record every command, plan, security decision, and outcome with cryptographic chaining.', securityImplications: 'Detects modification, deletion, truncation, and rollback.', verificationMethod: 'Audit Test', rfcMapping: 'RFC-010' },
  { id: 'REQ-DEP-002a', priority: 'MUST', category: 'Deployment', title: 'Log Storage Isolation', statement: 'Audit log storage outside all tool-writable workspaces; plugins cannot rewrite logs.', securityImplications: 'Preserves audit trail integrity.', verificationMethod: 'Test', rfcMapping: 'RFC-010' },
  { id: 'REQ-DEP-002b', priority: 'MUST', category: 'Deployment', title: 'Anchor Verification & Timestamp Protection', statement: 'Chain anchor protected independently from log; verify chain against anchor on restart.', securityImplications: 'Closes restart-time rollback and anchor replacement.', verificationMethod: 'Test', rfcMapping: 'RFC-010' },
  { id: 'REQ-DEP-003', priority: 'MUST', category: 'Deployment', title: 'Authenticated Updates', statement: 'All updates to system or manifests authenticated before application; rollback blocked without consent.', securityImplications: 'Prevents malicious update injection.', verificationMethod: 'Test', rfcMapping: 'RFC-005' },
];
