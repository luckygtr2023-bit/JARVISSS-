// Deterministic in-browser crypto and state machine utilities for architectural verification

export async function computeSha256(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function computeHmacSha256(key: string, message: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(key);
  const msgData = encoder.encode(message);

  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign('HMAC', cryptoKey, msgData);
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// RFC-006 Taint Lattice Flags
export const TAINT_FLAGS = {
  CLEAN_POLICY: 0x00,
  TAINT_WEB: 0x01,
  TAINT_OCR: 0x02,
  TAINT_EXT_TOOL: 0x04,
  TAINT_EXT_MODEL: 0x08,
  TAINT_MEM_DERIVED: 0x10,
};

export interface TaintSource {
  id: string;
  name: string;
  flag: number;
  description: string;
  active: boolean;
  samplePayload: string;
}

// RFC-004 State Machine
export type TaskLifecycleState =
  | 'Initiated'
  | 'Planning'
  | 'Awaiting_Confirmation'
  | 'Executing'
  | 'Verifying'
  | 'Completed'
  | 'Failed'
  | 'Cancelled'
  | 'Timed_Out'
  | 'Ambiguous_Uncertain'
  | 'Halted_Requires_Inspection';

export const LEGAL_TRANSITIONS: Record<TaskLifecycleState, TaskLifecycleState[]> = {
  Initiated: ['Planning', 'Failed', 'Cancelled'],
  Planning: ['Awaiting_Confirmation', 'Executing', 'Failed', 'Cancelled'],
  Awaiting_Confirmation: ['Executing', 'Cancelled', 'Timed_Out', 'Failed'],
  Executing: ['Verifying', 'Completed', 'Failed', 'Cancelled', 'Timed_Out', 'Ambiguous_Uncertain'],
  Verifying: ['Completed', 'Failed', 'Ambiguous_Uncertain'],
  Completed: [], // Strictly Terminal (REQ-CORE-002a)
  Failed: [],    // Strictly Terminal (REQ-CORE-002a)
  Cancelled: [], // Strictly Terminal (REQ-CORE-002a)
  Timed_Out: ['Halted_Requires_Inspection', 'Failed', 'Cancelled'],
  Ambiguous_Uncertain: ['Halted_Requires_Inspection', 'Cancelled'],
  Halted_Requires_Inspection: ['Awaiting_Confirmation', 'Failed', 'Cancelled'],
};

export const TERMINAL_STATES: TaskLifecycleState[] = ['Completed', 'Failed', 'Cancelled'];

// RFC-010 Audit Log Entry
export interface AuditBlock {
  seqNo: number;
  timestamp: string;
  action: string;
  actor: string;
  prevHash: string;
  currentHash: string;
  isTampered?: boolean;
}
