'use client';

import React, { useState } from 'react';
import { RfcExplorer } from '@/components/architecture-workbench/rfc-explorer';
import { ConfirmationBindingTester } from '@/components/architecture-workbench/confirmation-binding-tester';
import { TaintLatticeSimulator } from '@/components/architecture-workbench/taint-lattice-simulator';
import { FencingLeaseSimulator } from '@/components/architecture-workbench/fencing-lease-simulator';
import { StateMachineSimulator } from '@/components/architecture-workbench/state-machine-simulator';
import { AuditChainVerifier } from '@/components/architecture-workbench/audit-chain-verifier';
import { RequirementsMatrix } from '@/components/architecture-workbench/requirements-matrix';
import { 
  Shield, 
  Cpu, 
  FileText, 
  Layers, 
  Terminal, 
  CheckCircle2, 
  Download, 
  BookOpen, 
  ExternalLink,
  Lock,
  GitBranch,
  Activity
} from 'lucide-react';

export default function Page() {
  const [activeTab, setActiveTab] = useState<'rfcs' | 'simulators' | 'requirements' | 'spec'>('rfcs');
  const [activeSimulator, setActiveSimulator] = useState<string>('confirmation');

  const handleSelectSimulator = (simId: string) => {
    setActiveSimulator(simId);
    setActiveTab('simulators');
  };

  const handleDownloadSpec = () => {
    // Trigger download of the complete RFC markdown file
    window.open('/api/download-spec', '_blank');
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Top Header Bar */}
      <header className="border-b border-border/60 bg-card/80 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-black text-sm shadow-xs">
              J
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold tracking-tight text-foreground">
                  JARVIS Architecture Specification & RFCs
                </h1>
                <span className="font-mono text-[10px] px-2 py-0.5 rounded-full font-bold bg-primary/10 text-primary border border-primary/20">
                  v1.3.0 Baseline
                </span>
                <span className="font-mono text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  All 15 RFCs Approved
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                Authoritative technical resolution of Architectural Questions 1 through 15 &bull; Non-Authoritative AI with Bounded Execution Authority
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="#spec-download"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('spec');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border/50 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              Full RFC Spec Doc
            </a>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex gap-2 border-t border-border/40 pt-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('rfcs')}
            className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'rfcs'
                ? 'border-primary text-primary font-semibold'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            15 Architecture RFCs (Compendium)
          </button>

          <button
            onClick={() => setActiveTab('simulators')}
            className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'simulators'
                ? 'border-primary text-primary font-semibold'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            Interactive Architectural Simulators
          </button>

          <button
            onClick={() => setActiveTab('requirements')}
            className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'requirements'
                ? 'border-primary text-primary font-semibold'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            Requirements Traceability Matrix (59 Reqs)
          </button>

          <button
            onClick={() => setActiveTab('spec')}
            className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'spec'
                ? 'border-primary text-primary font-semibold'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Technical Whitepaper View
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* TAB 1: RFC Compendium */}
        {activeTab === 'rfcs' && (
          <div className="space-y-6">
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-primary uppercase tracking-wider">
                  Baseline Architecture Decision Records (ADRs)
                </span>
                <p className="text-xs text-foreground/90">
                  Each RFC delivers concrete protocols, process topologies, mathematical contracts, and verification procedures resolving the 15 architectural questions.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                <span className="px-2 py-0.5 rounded bg-muted">15/15 Closed</span>
                <span className="px-2 py-0.5 rounded bg-muted">Zero TBD Tokens</span>
              </div>
            </div>

            <RfcExplorer onSelectSimulator={handleSelectSimulator} />
          </div>
        )}

        {/* TAB 2: Architectural Simulators */}
        {activeTab === 'simulators' && (
          <div className="space-y-6">
            {/* Sub-simulator navigation */}
            <div className="flex flex-wrap gap-2 border-b border-border/60 pb-3">
              <button
                onClick={() => setActiveSimulator('confirmation')}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeSimulator === 'confirmation'
                    ? 'bg-primary text-primary-foreground shadow-xs'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                RFC-007: Confirmation Binding & Secret Masker
              </button>
              <button
                onClick={() => setActiveSimulator('taint-lattice')}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeSimulator === 'taint-lattice'
                    ? 'bg-primary text-primary-foreground shadow-xs'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                RFC-006: Provenance Lattice & Taint Flow
              </button>
              <button
                onClick={() => setActiveSimulator('fencing')}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeSimulator === 'fencing'
                    ? 'bg-primary text-primary-foreground shadow-xs'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                RFC-009: Execution Fencing & Revocation Leases
              </button>
              <button
                onClick={() => setActiveSimulator('state-machine')}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeSimulator === 'state-machine'
                    ? 'bg-primary text-primary-foreground shadow-xs'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                RFC-004: Crash-Safe 11-State Machine & WAL
              </button>
              <button
                onClick={() => setActiveSimulator('audit-chain')}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  activeSimulator === 'audit-chain'
                    ? 'bg-primary text-primary-foreground shadow-xs'
                    : 'bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                RFC-010: Audit Merkle Chain & TPM Anchor
              </button>
            </div>

            {/* Render Active Simulator */}
            {activeSimulator === 'confirmation' && <ConfirmationBindingTester />}
            {activeSimulator === 'taint-lattice' && <TaintLatticeSimulator />}
            {activeSimulator === 'fencing' && <FencingLeaseSimulator />}
            {activeSimulator === 'state-machine' && <StateMachineSimulator />}
            {activeSimulator === 'audit-chain' && <AuditChainVerifier />}
          </div>
        )}

        {/* TAB 3: Requirements Traceability Matrix */}
        {activeTab === 'requirements' && (
          <div className="space-y-6">
            <RequirementsMatrix
              onSelectRfc={(rfcId) => {
                setActiveTab('rfcs');
              }}
            />
          </div>
        )}

        {/* TAB 4: Technical Whitepaper View */}
        {activeTab === 'spec' && (
          <div className="bg-card border border-border/60 rounded-xl p-8 shadow-xs space-y-6 max-w-4xl mx-auto">
            <div className="border-b border-border/60 pb-6 flex items-start justify-between gap-4 flex-wrap">
              <div>
                <span className="font-mono text-xs font-bold text-primary uppercase tracking-wider">
                  Authoritative Architectural Specification v1.3.0
                </span>
                <h2 className="text-2xl font-black text-foreground tracking-tight mt-1">
                  JARVIS Architecture Specification & RFC Baseline
                </h2>
                <p className="text-xs font-mono text-muted-foreground mt-1">
                  Published: docs/JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md &bull; Target: Windows 10/11 x64 + Android Companion
                </p>
              </div>
              <button
                onClick={() => {
                  const content = `# JARVIS Architecture Specification & Technical RFC Compendium\nAvailable in /docs/JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md`;
                  const blob = new Blob([content], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md';
                  a.click();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                Download Markdown Spec
              </button>
            </div>

            <div className="prose prose-sm dark:prose-invert max-w-none text-foreground/90 space-y-4">
              <h3 className="text-base font-bold text-foreground">1. System Invariant & Foundational Architecture</h3>
              <p className="text-xs leading-relaxed text-muted-foreground">
                The core architectural tenet of JARVIS is <strong>Non-Authoritative AI with Bounded Execution Authority</strong>. Under no circumstances does an LLM, vector store, or untrusted network input possess intrinsic authority to mutate system state, execute code, or bypass policy gates.
              </p>

              <h3 className="text-base font-bold text-foreground">2. Summary of 15 Architectural Question Resolutions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-001: Core IPC Topology</div>
                  <div className="text-muted-foreground mt-0.5">Windows Named Pipes with SDDL access controls and CRC32-checked Protobuf v3 framing; isolated Job Object workers with zero cross-talk.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-002: Desktop Automation Hierarchy</div>
                  <div className="text-muted-foreground mt-0.5">Prioritizes Windows UI Automation (UIA v3 COM) tree addressing; coordinate synthesis strictly audited with target HWND & bounding box.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-003: Storage Key Management</div>
                  <div className="text-muted-foreground mt-0.5">DPAPI envelope encryption + SQLCipher page-level HMAC; volatile keys locked via VirtualLock and wiped via SecureZeroMemory on logout.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-004: State Machine & Crash Recovery</div>
                  <div className="text-muted-foreground mt-0.5">11-state machine with sync WAL writes; on reboot, non-terminal tasks transition to Halted_Requires_Inspection with per-node reconciliation.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-005: Manifest Authenticity</div>
                  <div className="text-muted-foreground mt-0.5">Detached Ed25519 signatures over Canonical JSON verified against ACL-protected root trust anchor; runtime pages marked PAGE_READONLY.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-006: Provenance & Taint Lattice</div>
                  <div className="text-muted-foreground mt-0.5">16-bit bitfield taint flags; transitive propagation; metadata non-propagation exception; forced human confirmation on any tainted write.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-007: Confirmation Binding & Secrets</div>
                  <div className="text-muted-foreground mt-0.5">HMAC-SHA256 digest binding request ID, tool, parameters, and nonce; secret parameters masked as Vault KeyIDs with zero partial characters.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-008: Companion Zero-Trust Channel</div>
                  <div className="text-muted-foreground mt-0.5">Noise_XX protocol over local Wi-Fi with QR code out-of-band pairing; mandatory host-side physical confirmation for high-risk commands.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-009: Fencing Leases & Revocation</div>
                  <div className="text-muted-foreground mt-0.5">64-bit Generation Epochs; capability write leases; TerminateJobObject; Ambiguous_Uncertain resource hold prevents stale worker races.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-010: Audit Log Chain & Anchor</div>
                  <div className="text-muted-foreground mt-0.5">Merkle SHA-256 chained ledger; split anchor extended into TPM 2.0 PCR-15 and NT SERVICE registry key; boot integrity verification.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-011: Deduplication Key Derivation</div>
                  <div className="text-muted-foreground mt-0.5">RFC 8785 Canonical JSON hashing of non-volatile semantic parameters; stable across DAG replans and post-crash resumption.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="font-bold text-primary">RFC-012: Concrete Uncertainty Taxonomy</div>
                  <div className="text-muted-foreground mt-0.5">5 distinct ambiguity classes (network drop, partial flush, crash unack, external desync, handle timeout) with tailored recovery state rules.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="text-primary font-bold">RFC-013: Simulation Fidelity Model</div>
                  <div className="text-muted-foreground mt-0.5">FULLY, PARTIALLY, and NOT_SIMULATABLE categories; SIMULATION_INCOMPLETE token requires explicit user waiver before execution.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="text-primary font-bold">RFC-014: Session Boundary Protocol</div>
                  <div className="text-muted-foreground mt-0.5">WTSRegisterSessionNotification handler; wipes keys via SecureZeroMemory on lock/logout; pauses credentialed queues.</div>
                </div>
                <div className="p-3 rounded-lg border border-border/50 bg-muted/20">
                  <div className="text-primary font-bold">RFC-015: Browser Side-Effect Classifier</div>
                  <div className="text-muted-foreground mt-0.5">OpenAPI/GraphQL AST inspection parses read-only semantics; conservative fallback treats uncontracted POSTs as side-effects in ephemeral profiles.</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/60 py-4 bg-card/60 mt-auto text-xs text-muted-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-2">
          <span>JARVIS System Architecture &bull; Baseline v1.3.0 &bull; Security & Reliability Specification</span>
          <span className="font-mono text-[11px]">Specification artifact: /docs/JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md</span>
        </div>
      </footer>
    </div>
  );
}
