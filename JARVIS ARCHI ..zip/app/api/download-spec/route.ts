import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
  const filePath = path.join(process.cwd(), 'docs', 'JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md');
  
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    return new NextResponse(fileContent, {
      status: 200,
      headers: {
        'Content-Type': 'text/markdown; charset=utf-8',
        'Content-Disposition': 'attachment; filename="JARVIS_ARCHITECTURE_SPECIFICATION_v1.3.0.md"',
      },
    });
  } catch (err) {
    return new NextResponse('Specification file not found', { status: 404 });
  }
}
