# COMPREHENSIVE SYSTEM THREAT MODEL
Document Identifier: JARVIS-ARCH-030
Status: DRAFT

---

## 1. STRIDE-AI THREAT MATRIX

The architecture defends against 24 specific adversarial threats across the AI, Operating System, Network, and Memory vectors.

| Threat ID | Threat Vector | Target Subsystem | Architectural Defense | Residual Risk | Verification Method |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `THR-01` | Prompt Injection via Malicious Webpage | `SYS-AI`, `SYS-PLAN` | Structural XML encapsulation; strict GBNF schema decoding; non-authoritative AI. | Model refusal hallucination. | Failure-injection suite: Web injection harness. |
| `THR-02` | Stale Worker Write Race Condition | `SYS-EXEC`, `SYS-TOOL` | Monotonic `OwnershipEpoch` fencing tokens validated pre-write. | Delayed read locks. | Race condition injector: Delayed worker write. |
| `THR-03` | Silent Audit Ledger Tampering | `SYS-AUD` | SHA-256 hash chaining; periodic signed Merkle anchors; fail-stop lockdown. | Block device rollback. | Byte-corruption test of audit ledger file. |
| `THR-04` | Malicious Plugin Sandbox Escape | `SYS-PLUGINS` | Windows AppContainer isolation; zero direct OS API handles; restricted DACLs. | 0-day Windows kernel bug.| Automated container escape test suite. |
| `THR-05` | Forged User Confirmation via Clickjack | `SYS-FE`, `SYS-SEC` | Topmost secure window overlays; randomized interaction targets; focus validation. | Physical human error. | Focus-stealing and mouse-event injection tests. |
| `THR-06` | Android Companion Man-in-the-Middle | `SYS-AND` | Noise Protocol E2EE with out-of-band pinned Ed25519 public keys. | Compromised Android OS. | TLS/Noise packet tampering test harness. |
| `THR-07` | Filesystem Symlink Traversal Attack | `SYS-WIN`, `SYS-TOOL` | Kernel path canonicalization via `GetFinalPathNameByHandleW`. | NTFS lock contention. | Path-traversal fuzzing (`..\..`, junctions). |
| `THR-08` | Zombie Worker Surviving Core Crash | `SYS-EXEC` | Windows Job Objects configured with `KillOnJobClose`; startup PID sweep. | Slow OS process teardown.| Core kill -9 stress test. |
| `THR-09` | Secret Exfiltration via Outbound Prompts | `SYS-AI`, `SYS-NET` | In-memory Aho-Corasick secret scrubber; DPAPI-bound key isolation. | Novel representation of key.| Prompt egress scanner audit. |
| `THR-10` | Memory Poisoning via Untrusted Chat | `SYS-MEM` | Explicit provenance tracking; unverified assertions barred from long-term memory. | Subtle user preference drift.| Memory poison insertion test. |
| `THR-11` | Denial of Service via Resource Exhaustion| `SYS-EXEC` | Hard Job Object memory limits; per-task timeout budgets; rate limiters. | Temporary task queue delay.| Fork-bomb / memory-leak tool injection. |
| `THR-12` | Ambiguous Re-execution of Financial Tool | `SYS-CORE`, `SYS-PLAN`| Strict non-idempotent deduplication keys; automatic transition to `AMBIGUOUS_HALTED`.| User manual retry delay. | Network drop during HTTP POST test. |
| `THR-13` | UI Automation Desynchronization | `SYS-WIN`, `SYS-VIS` | Semantic UIA validation coupled with OCR spatial visual fallback. | Flashing UI/dynamic animations.| Dynamic UI repositioning test. |
| `THR-14` | Insecure IPC Client Spoofing | `SYS-IPC` | Client PID validation, binary digital signature, and DACL pipe checks. | Local Administrator rootkit.| Rogue named pipe connection attempt. |
| `THR-15` | Malicious Audio Ingestion (Ultrasonic) | `SYS-VOX` | Bandpass audio filtering (300Hz - 8kHz); explicit wake-word confirmation. | Acoustic interference. | High-frequency audio injection test. |
| `THR-16` | Configuration Downgrade Attack | `SYS-CONF` | Cryptographically signed policy manifests; immutable precedence hierarchy. | Physical disk replacement.| Tampered `policy.json` startup test. |
| `THR-17` | Infinite Replanning Loop | `SYS-PLAN` | Hard ceiling on replan attempts (max 3); cycle detection algorithms. | Task premature termination. | Cyclic DAG failure injection. |
| `THR-18` | Screen Capture Data Leak (Passwords) | `SYS-VIS` | Local CV/OCR PII redaction engine with Gaussian blurring before routing. | Unrecognized custom UI fields. | Screen capture with mock password fields. |
| `THR-19` | Replay Attack on Remote Intent | `SYS-AND`, `SYS-IPC` | Monotonic 64-bit sequence counters; sliding nonce cache (300s window). | Local clock skew. | IPC packet replay injection. |
| `THR-20` | Browser DOM Script Injection (XSS) | `SYS-BROWSER` | Strip `<script>`, `<iframe>`; execute in isolated headless CDP sandbox. | Dynamic DOM mutation tricks.| Injected XSS payload test suite. |
| `THR-21` | Clipboard Hijacking & Data Leak | `SYS-TOOL`, `SYS-SEC` | Scoped clipboard access; auto-clear clipboard timers for sensitive data. | Third-party clipboard spy. | Clipboard read/write fuzzing. |
| `THR-22` | Elevation of Privilege via UAC Bypass | `SYS-WIN`, `SYS-SEC` | Core runs as Standard User; elevation delegated strictly to out-of-process UAC. | Social engineering of user. | Mock UAC trigger validation. |
| `THR-23` | Database Corruption via Power Cut | `SYS-DATA` | SQLite WAL mode with synchronous=NORMAL; cold boot `integrity_check`. | Storage hardware failure. | Power-loss simulation / WAL kill test. |
| `THR-24` | Model Provider Outage / Token Starvation| `SYS-AI` | Provider-agnostic router; local model circuit-breaker fallback. | Degraded reasoning capacity. | Synthetic 503 provider injection. |
