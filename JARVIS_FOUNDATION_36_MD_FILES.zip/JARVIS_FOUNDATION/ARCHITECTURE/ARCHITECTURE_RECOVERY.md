# CRASH RECOVERY & STATE RECONCILIATION
Document Identifier: JARVIS-ARCH-008
Status: DRAFT

---

## 1. RECOVERY PRINCIPLES

1. Zero Silent Resumption: The system shall never blindly re-execute non-idempotent operations following a crash or restart.
2. Conservative Ambiguity Classification: Any task in-flight during a crash whose verified completion cannot be proven through sensory observation is classified as `AMBIGUOUS_HALTED`.
3. Deterministic Journal Replay: Upon startup, the Core Orchestrator reconciles its in-memory task graph strictly from the append-only SQLite WAL transaction log.

---

## 2. CRASH RECONCILIATION PROTOCOL

```text
            +----------------------------+
            |    System Boot / Restart   |
            +----------------------------+
                          |
                          v
            +----------------------------+
            |    Audit Log Hash Check    |
            +----------------------------+
                          |
             +------------+------------+
             |                         |
     (Integrity OK)             (Hash Mismatch)
             v                         v
+----------------------------+ +----------------------------+
| Scan SQLite Task Journal | | ENTER SAFE LOCKDOWN |
+----------------------------+ | Halt all execution |
| +----------------------------+
v
+-------------------------------------------------------+
| Identify Tasks in EXECUTING / DISPATCHED Status |
+-------------------------------------------------------+
|
v
+-------------------------------------------------------+
| Query Verification Plane for Target Resource State |
+-------------------------------------------------------+
|
+----------+-----------------------+
| |
(State Proved Unchanged) (State Mutated or Unknown)
v v
+----------------------------+ +----------------------------+
| Mark Task as FAILED | | Mark Task as |
| Safe to Replan | | AMBIGUOUS_HALTED |
+----------------------------+ | Human Intervention Required|
+----------------------------+
```


---

## 3. ORPHAN PROCESS & RESOURCE RECLAMATION

1. Job Object Cleanup: Because worker processes are bound to Windows Job Objects with `KillOnJobClose`, an abrupt termination of the Core process triggers the operating system kernel to automatically terminate all associated worker processes.
2. Zombie Process Sweeper: On initialization, the Core enumerates all active processes matching the binary signature `jarvis-worker-*.exe`. Any worker process not linked to an active Core lease handle is forcefully killed using Win32 `TerminateProcess`.
3. Staged Workspace Eviction: Uncommitted files located in `C:\ProgramData\JARVIS\Staging\` older than 3600 seconds are safely purged to prevent disk bloat.
