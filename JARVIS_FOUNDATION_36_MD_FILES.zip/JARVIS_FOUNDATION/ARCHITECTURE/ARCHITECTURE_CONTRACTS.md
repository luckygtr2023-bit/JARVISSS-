# FORMAL INTERFACE CONTRACTS SPECIFICATION
Document Identifier: JARVIS-ARCH-002
Status: DRAFT

---

## 1. PROTOCOL FRAMING & TRANSPORT

All internal communication between the Core Orchestrator and out-of-process workers, daemons, and frontends operates over Windows Named Pipes utilizing a length-prefixed, binary-encoded framing protocol (Protocol Buffers v3 / Canonical JSON).

### 1.1 Wire Frame Structure
```text
+-------------------------------------------------------------------------+
| Magic (4B) | Version (2B) | Flags (2B) | Payload Length (4B) | Msg ID (16B) |
+-------------------------------------------------------------------------+
| Nonce (12B) | Epoch Token (8B) | Target Service ID (4B) |
+-------------------------------------------------------------------------+
| Payload Data (Encrypted / Authenticated via AEAD or Signed Struct) |
+-------------------------------------------------------------------------+
| HMAC / Poly1305 Authentication Tag (16B) |
+-------------------------------------------------------------------------+
```


---

## 2. CRITICAL INTERFACE CONTRACTS

### 2.1 Contract CTR-001: Frontend Request Submission
* Caller: Presentation Layer (`SYS-FE`)
* Receiver: Core Orchestrator (`SYS-CORE`)
* Transport: Named Pipe `\\.\pipe\jarvis-core-frontend`
* Request Schema (`SubmitRequest`):
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SubmitRequest",
  "type": "object",
  "properties": {
    "request_id": { "type": "string", "format": "uuid" },
    "session_id": { "type": "string", "format": "uuid" },
    "timestamp_utc": { "type": "string", "format": "date-time" },
    "actor": {
      "type": "object",
      "properties": {
        "user_id": { "type": "string" },
        "auth_token": { "type": "string" }
      },
      "required": ["user_id", "auth_token"]
    },
    "input_modality": { "type": "string", "enum": ["TEXT", "VOICE", "EVENT"] },
    "raw_payload": { "type": "string", "maxLength": 32768 },
    "client_context": {
      "type": "object",
      "properties": {
        "active_window_hwnd": { "type": "integer" },
        "cursor_position": { "type": "array", "items": { "type": "integer" }, "minItems": 2, "maxItems": 2 }
      }
    }
  },
  "required": ["request_id", "session_id", "timestamp_utc", "actor", "input_modality", "raw_payload"]
}
```
Response Schema (SubmitResponse):

```json
{
  "request_id": "c4b1b369-0e42-4f05-8839-bc55b4b7a2d1",
  "status": "ACCEPTED",
  "assigned_task_id": "7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77",
  "error": null
}
```
Invariants & Constraints:
Replay Protection: Nonce cache checked against a 300-second sliding window.
Idempotency: Duplicate request_id within active session returns identical assigned_task_id.
Timeout: 2500ms synchronous ACK deadline.
2.2 Contract CTR-002: Plan Node Execution Dispatch
Caller: Execution Controller (SYS-EXEC)
Receiver: Capability Worker Host (SYS-WORKER)
Transport: Named Pipe \\.\pipe\jarvis-worker-{worker_id}
Request Schema (DispatchExecution):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "DispatchExecution",
  "type": "object",
  "properties": {
    "execution_id": { "type": "string", "format": "uuid" },
    "task_id": { "type": "string", "format": "uuid" },
    "node_id": { "type": "string" },
    "attempt_id": { "type": "integer", "minimum": 1 },
    "capability_name": { "type": "string" },
    "tool_action": { "type": "string" },
    "parameters": { "type": "object" },
    "ownership_grant": {
      "type": "object",
      "properties": {
        "resource_key": { "type": "string" },
        "epoch_id": { "type": "integer" },
        "grant_token": { "type": "string" },
        "expires_at_utc": { "type": "string", "format": "date-time" }
      },
      "required": ["resource_key", "epoch_id", "grant_token", "expires_at_utc"]
    },
    "timeout_ms": { "type": "integer", "maximum": 60000 }
  },
  "required": ["execution_id", "task_id", "node_id", "attempt_id", "capability_name", "tool_action", "parameters", "ownership_grant", "timeout_ms"]
}
```
Response Schema (ExecutionResult):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "ExecutionResult",
  "type": "object",
  "properties": {
    "execution_id": { "type": "string", "format": "uuid" },
    "node_id": { "type": "string" },
    "attempt_id": { "type": "integer" },
    "status": { "type": "string", "enum": ["COMPLETED", "FAILED", "TIMED_OUT", "REVOKED"] },
    "observed_output": { "type": "object" },
    "error": {
      "type": "object",
      "properties": {
        "code": { "type": "string" },
        "message": { "type": "string" },
        "retryable": { "type": "boolean" }
      }
    },
    "fence_validation": { "type": "string", "enum": ["VALID", "STALE_EPOCH_REJECTED"] },
    "execution_duration_ms": { "type": "integer" }
  },
  "required": ["execution_id", "node_id", "attempt_id", "status", "fence_validation", "execution_duration_ms"]
}
```
2.3 Contract CTR-003: Policy Authorization Challenge
Caller: Core Orchestrator (SYS-CORE)
Receiver: Security Kernel (SYS-SEC)
Request Schema (EvaluatePolicy):

```json
{
  "task_id": "7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77",
  "node_id": "node_04_delete_file",
  "capability": "filesystem.delete",
  "parameters": {
    "canonical_path": "C:\\Users\\Default\\AppData\\Local\\Temp\\test.tmp"
  },
  "risk_tier": "TIER_2_MEDIUM_REVERSIBLE",
  "context": {
    "user_confirmed": false,
    "interactive_session": true
  }
}
```
Response Schema (PolicyDecision):

```json
{
  "decision": "CONFIRMATION_REQUIRED",
  "required_tier": "TIER_2_MEDIUM_REVERSIBLE",
  "challenge_token": "f3a2c1b0-9e8d-4c7b-6a5f-4e3d2c1b0a9f",
  "confirmation_prompt": "Confirm deletion of temporary file: C:\\Users\\Default\\AppData\\Local\\Temp\\test.tmp",
  "authorization_grant": null
}
```
