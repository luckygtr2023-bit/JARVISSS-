# PLUGIN & EXTENSIBILITY ARCHITECTURE
Document Identifier: JARVIS-ARCH-019
Status: DRAFT

---

## 1. PLUGIN MANIFEST & SIGNATURE VALIDATION

Third-party extensions are strictly constrained by digital signatures and explicit permission manifests.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "PluginManifest",
  "type": "object",
  "properties": {
    "plugin_id": { "type": "string", "pattern": "^[a-z0-9_\\-]+$" },
    "version": { "type": "string" },
    "developer_signature": { "type": "string" },
    "requested_permissions": {
      "type": "array",
      "items": { "type": "string", "enum": ["NETWORK_ACCESS", "FILESYSTEM_READ_SCOPED", "CLIPBOARD_READ"] }
    },
    "entry_point": { "type": "string" },
    "declared_capabilities": { "type": "array", "items": { "type": "string" } }
  },
  "required": ["plugin_id", "version", "developer_signature", "requested_permissions", "entry_point"]
}
```
2. APPCONTAINER SANDBOXING
Plugins run within an isolated Windows AppContainer sandbox:

Filesystem Boundary: Read/write access is restricted to the plugin's private sandboxed directory (C:\ProgramData\JARVIS\Plugins\Data\{plugin_id}\). All access to the user's home directory or system folders is blocked at the NT kernel boundary.
Network Isolation: Inbound connections are prohibited. Outbound network traffic is blocked by default unless explicitly granted in the manifest and authorized by the user.
Broker Architecture: Plugins interact with JARVIS capabilities strictly via the Core IPC broker, subjecting every request to the central Policy Engine.
