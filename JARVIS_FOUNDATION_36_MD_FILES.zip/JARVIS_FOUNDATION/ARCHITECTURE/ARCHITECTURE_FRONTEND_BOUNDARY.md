# PRESENTATION LAYER & FRONTEND BOUNDARY
Document Identifier: JARVIS-ARCH-027
Status: DRAFT

---

## 1. DECOUPLING PRINCIPLE & UNTRUSTED UI

The Presentation Layer (Desktop WinUI overlay, HUD, System Tray, Web View) is classified as an untrusted client. The frontend has zero execution authority and cannot perform actions directly.
```text
+--------------------------------------------------------------------------+
| Presentation Layer (Untrusted Frontend) |
| - Captures user text/voice input. |
| - Displays state telemetry, DAG visualizations, and chat messages. |
| - Renders confirmation request modals. |
+--------------------------------------------------------------------------+
|
| IPC via Local Named Pipe
v
+--------------------------------------------------------------------------+
| Core Authority Boundary (Trusted Core) |
| - Validates authenticity of all incoming UI events. |
| - Independently enforces authorization and confirmation logic. |
+--------------------------------------------------------------------------+
```


---

## 2. ANTI-CLICKJACKING & SECURE CONFIRMATION MODALS

To prevent malicious software from spoofing user confirmations via UI redress or clickjacking:
1. High-Risk Modals: Confirmation dialogs for Tier 3 and Tier 4 operations are drawn directly by a privileged Core helper window using topmost, hardware-accelerated Win32 overlays with secure window styles (`WS_EX_TOPMOST | WS_EX_LAYERED`).
2. Interaction Randomization: High-risk confirmation buttons randomize their screen coordinate placement slightly or require an explicit slider drag/hold interaction to prevent automated mouse event injection (`mouse_event` spoofing).
3. Foreground Verification: The Core verifies via Win32 `GetForegroundWindow` that the confirmation dialog has active user focus at the exact millisecond of click input.
