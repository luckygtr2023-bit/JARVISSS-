# VOICE & AUDIO PROCESSING SPECIFICATION
Document Identifier: JARVIS-ARCH-014
Status: DRAFT

---

## 1. VOICE PROCESSING PIPELINE
```text
+--------------------------------------------------------------------------+
| 1. HARDWARE CAPTURE & DSP |
| - Continuous circular audio ring buffer (16kHz, 16-bit PCM). |
| - Acoustic Echo Cancellation (AEC) & Noise Suppression. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 2. LOCAL WAKE-WORD ENGINE (Zero Network Egress) |
| - Lightweight ONNX model continuously evaluating wake-word probability. |
| - Power-efficient background operation; low CPU utilization (< 1%). |
+--------------------------------------------------------------------------+
| (Wake-Word Detected)
v
+--------------------------------------------------------------------------+
| 3. STREAMING SPEECH-TO-TEXT (STT) |
| - Local streaming model (Whisper.cpp) or low-latency cloud WebSocket. |
| - Emits partial transcript tokens in real-time. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 4. BARGE-IN & INTERRUPTION DETECTOR |
| - Monitors user voice activity during active system TTS playback. |
| - Immediately halts audio output upon user speech onset (< 50ms latency).|
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 5. NEURAL TEXT-TO-SPEECH (TTS) SYNTHESIS |
| - Low-latency streaming neural synthesis engine. |
+--------------------------------------------------------------------------+
```


---

## 2. PRIVACY CONTROLS & PHYSICAL INDICATORS

1. Hardware Mute Honor: The system listens to OS-level audio device state changes and updates its internal state when hardware mute switches are toggled.
2. Visual Recording Indication: Whenever the audio pipeline captures audio beyond the local wake-word buffer, a high-contrast recording indicator is rendered on the desktop and companion HUD.
3. Voice Cancellation: The user can interrupt and abort any in-flight operation by issuing authoritative cancellation phrases ("JARVIS, cancel", "Stop execution").
