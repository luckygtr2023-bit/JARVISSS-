# EXECUTION CONTROLLER & FENCING SPECIFICATION
Document Identifier: JARVIS-ARCH-007
Status: DRAFT

---

## 1. WORKER SUPERVISION & PROCESS MODEL

Capabilities never execute within the Core Orchestrator process. Execution is delegated to sandboxed child worker processes monitored via Windows Job Objects.
```text
+------------------------------------------------------------------+
| Core Orchestrator Process |
| (Medium Integrity / Host) |
+------------------------------------------------------------------+
| |
| IPC (Named Pipe) | IPC (Named Pipe)
v v
+-------------------------------+ +-------------------------------+
| Windows Worker Process | | Browser Daemon Process |
| (Low/Medium Integrity Job) | | (Low Integrity Job) |
| - Win32 Automation | | - Chromium Instance |
| - Filesystem Adapters | | - CDP Session |
+-------------------------------+ +-------------------------------+
```


### 1.1 Process Sandboxing & Job Limits
* Windows Job Object Limits:
  * `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`: Ensures that if the Core process crashes, all running worker processes are terminated instantly by the Windows kernel.
  * `JOB_OBJECT_LIMIT_ACTIVE_PROCESS`: Restricts worker processes from spawning arbitrary untracked subprocesses.
  * Memory Commit Limit: Hard cap per worker process (e.g., 512MB for UI workers, 2048MB for Browser daemons).

---

## 2. FENCING EPOCHS & STALE WORKER MITIGATION

To prevent race conditions where a timed-out or cancelled worker wakes up and executes a destructive side effect, the system enforces a strict Fencing Epoch protocol.

### 2.1 Fencing Mechanism
1. Resource Registration: Every mutable resource (e.g., file path, database row, external API state) is identified by a canonical `ResourceKey`.
2. Epoch Tracking: The Execution Controller maintains a monotonically increasing 64-bit integer `epoch_id` for each `ResourceKey`.
3. Lease Issuance: When an action is dispatched, the worker receives an `OwnershipGrant` containing `(resource_key, epoch_id, grant_token, expires_at)`.
4. Pre-Commit Validation: Prior to executing physical I/O or state modification, the worker adapter performs a synchronous hardware/kernel-fenced check against the local Resource Lock Table or passes the `grant_token` to an authoritative transactional wrapper.
5. Epoch Invalidation: If an action times out or is cancelled, the Core Orchestrator increments the `epoch_id` in the authority store. Any subsequent write request presented by the stale worker with the obsolete `epoch_id` is rejected.

---

## 3. ABORTABILITY & TERMINATION TAXONOMY

JARVIS explicitly distinguishes between four tiers of action abortability:

| Abortability Class | Definition | Recovery / Enforcement Action |
| :--- | :--- | :--- |
| `ARCHITECTURALLY_VERIFIED` | Native rollback/cancellation supported (e.g., transactional DB write, staged file copy). | Immediate abort signal; discard staging directory; resource untouched. |
| `RUNTIME_CONFIRMED` | Execution process can be hard-killed before target confirmation (e.g., UI click pending in message queue). | Hard process termination via `TerminateJobObject`; inspect UI state via OCR to confirm cancel. |
| `EXTERNALLY_COMMITTED` | Side effect is dispatched over an external network or hardware interface (e.g., HTTP POST, email dispatch). | Operation CANNOT be undone. System marks state as `AMBIGUOUS` if connection drops mid-flight. |
| `NON_ABORTABLE_CRITICAL` | Firmware, OS boot, or raw disk block write. | Abort is strictly rejected while in-flight; must await natural return or terminal hardware fault. |
