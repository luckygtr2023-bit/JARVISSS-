# TASK PLANNING & REPLANNING SPECIFICATION
Document Identifier: JARVIS-ARCH-010
Status: DRAFT

---

## 1. THE PLANNING LIFECYCLE

The Task Planner translates unstructured natural language user goals into deterministic, validated Directed Acyclic Graphs (DAGs).
```text
Natural Language Intent: "Find the quarterly sales spreadsheet on my desktop,
calculate total expenses, and email the summary to finance."
|
v
+-------------------------------------------------------------------------+
| Structured Goal Extraction (SYS-AI) |
| Target Goal: Parse spreadsheet, compute aggregate, prepare email draft |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Candidate DAG Generation (SYS-PLAN) |
| Node 1: fs.locate("Desktop\sales.xlsx") |
| Node 2: excel.read_range(Node 1.output.path, "Expenses!A1:B50") |
| Node 3: math.sum(Node 2.output.values) |
| Node 4: email.draft(to="finance@company.com", body=Node 3.output.result)|
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Static DAG Validation: Cycle checks, parameter types, permission scopes |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Policy Engine Authorization Matrix Evaluation |
+-------------------------------------------------------------------------+
```


---

## 2. DAG SPECIFICATION & INVARIANTS

### 2.1 Formal DAG Invariants
1. Directed Acyclic Property: $\forall u, v \in V, \text{Path}(u, v) \implies \neg \text{Path}(v, u)$. Cyclic graphs are rejected at the compilation phase.
2. Resource Non-Interference: Two concurrent nodes $N_a, N_b$ possessing no mutual dependency path cannot claim overlapping write locks on the same `ResourceKey`:
$$\text{Concurrent}(N_a, N_b) \implies \text{WriteResources}(N_a) \cap \text{WriteResources}(N_b) = \emptyset$$
3. Maximum Graph Complexity: A single plan cannot exceed 32 nodes, a maximum dependency depth of 8, or a fan-out factor of 6.

---

## 3. DYNAMIC REPLANNING BOUNDARIES

When an execution node fails or an environmental observation diverges from expected postconditions, the system triggers the Dynamic Replanner.

### 3.1 Replan Invariants & Policies
* Delta Isolation: The replanner shall only modify the subgraph downstream of the failed node. Completed and verified nodes remain immutable and are never re-executed.
* Scope Preservation: The replanned sub-DAG cannot exceed the original authorized `RiskTier` or request capabilities outside the original human confirmation scope without issuing a fresh `ConfirmationChallenge`.
* Replan Ceiling: A task is permitted a maximum of three (3) replan cycles. Upon reaching the fourth failure, the system automatically transitions to `FAILED` and escalates to the user.
