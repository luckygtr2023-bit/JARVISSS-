# SECURITY ARCHITECTURE & TRUST FRAMEWORK
Document Identifier: JARVIS-ARCH-006
Status: DRAFT

---

## 1. RISK CLASSIFICATION FRAMEWORK

Every capability and operation within JARVIS is bound to a strict, immutable risk tier. AI-generated risk suggestions are non-authoritative; classification is strictly determined by the deterministic Policy Engine based on the canonical capability signature and parameter scope.

### 1.1 Risk Tier Hierarchy
```text
+--------------------------------------------------------------------------+
| TIER 4: CRITICAL SYSTEM OPERATIONS |
| OS format, registry deletion, firmware, credential export, user elevation |
| Policy: STRICT MULTI-FACTOR + OUT-OF-BAND (OOB) HARDWARE CONFIRMATION |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| TIER 3: HIGH-RISK SIDE EFFECTS |
| External email send, financial transactions, permanent file deletion |
| Policy: EXPLICIT SYNCHRONOUS HUMAN CONFIRMATION (Desktop/Android HUD) |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| TIER 2: MEDIUM-RISK SIDE EFFECTS |
| Reversible local file modifications, application launching, settings edit|
| Policy: SYNCHRONOUS CONFIRMATION OR SESSION PRE-APPROVAL LEASE |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| TIER 1: LOW-RISK SIDE EFFECTS |
| Clipboard write, temp file generation, window focus/minimize |
| Policy: AUTOMATIC EXECUTION UNDER POLICY AUDIT |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| TIER 0: READ-ONLY OBSERVATIONS |
| Screen OCR capture, file read, active window query, memory query |
| Policy: UNRESTRICTED CORE INVOCATION (Bounded by Privacy Filters) |
+--------------------------------------------------------------------------+
```


---

## 2. POLICY EVALUATION & ENFORCEMENT ENGINE

The Policy Engine operates as an authoritative, out-of-process Policy Decision Point (PDP). It evaluates incoming candidate actions against three criteria:
1. Static System Policies: Sealed declarative JSON policies defining absolute boundaries (e.g., "Deny modification of `C:\Windows\*` under all conditions").
2. Dynamic Environmental State: Presence of active interactive desktop, screen lock status, user physical idle time.
3. Historical Blast Radius: Rate of operations within the current session (e.g., maximum 10 file deletions per minute).

### 2.1 Confirmation Challenge Enforcement
For Tier 2, 3, and 4 actions, the Policy Engine generates a cryptographically unique `ConfirmationChallenge`:
* Challenge Payload: Canonical action description, target resource path, side-effect delta preview, expiration timestamp (default: 60s).
* Cryptographic Binding: Signed with Core ephemeral HMAC key.
* Verification: The user's approval response must mirror the challenge hash. Any modification of target parameters invalidates the challenge.

---

## 3. SECRET MANAGEMENT & ISOLATION

1. Storage: Secrets (API keys, OAuth tokens, browser cookies) are stored in the Windows Credential Manager or an encrypted SQLite database using Windows DPAPI (`CryptProtectData`) tied strictly to the local machine and running user.
2. Memory Defense: In-memory secrets are held within non-pageable memory blocks using `VirtualLock`. Cleartext secrets are overwritten with zero bytes (`SecureZeroMemory`) immediately after use.
3. Log & Prompt Redaction: Secret strings are automatically scrubbed from all outbound AI prompts, debug logs, and audit records via a high-performance Aho-Corasick matching filter loaded with all active credential hashes.
4. Process Isolation: Execution workers never receive long-lived master credentials; they receive ephemeral, single-use access tokens scoped strictly to their explicit operation.
