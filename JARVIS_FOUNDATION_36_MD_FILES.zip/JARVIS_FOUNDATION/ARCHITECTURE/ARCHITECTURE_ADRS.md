# ARCHITECTURAL DECISION RECORDS (ADRS)
Document Identifier: JARVIS-ARCH-033
Status: DRAFT

---

## ADR INDEX

* ADR-001: Central Core Authority Model
* ADR-002: Inter-Process Communication via Named Pipes with DACLs
* ADR-003: Multi-Process Isolated Worker Topology
* ADR-004: Fencing Epochs and Lease Tokens for Side-Effect Control
* ADR-005: Quad-Tier Action Abortability Classification
* ADR-006: Cryptographic Deduplication Identity for Idempotency
* ADR-007: Decoupled Policy Decision Point and Human Confirmation
* ADR-008: Zero-Knowledge Secret Storage with Memory Pinning
* ADR-009: Hybrid Relational-Vector Storage Architecture
* ADR-010: Cryptographic Hash-Chained Audit Ledger with Merkle Anchoring
* ADR-011: Multi-Profile Process-Isolated Browser Daemon via CDP
* ADR-012: Dual-Mode Windows Automation (UI Automation + Vision Fallback)
* ADR-013: Android Companion Zero-Trust Peripheral Architecture
* ADR-014: Three-Tier Simulation Subsystem for Blast-Radius Prediction
* ADR-015: Conservative Ambiguity Recovery Protocol
* ADR-016: Provider-Agnostic LLM Routing with Constrained Decoding
* ADR-017: Windows AppContainer Sandboxing for Third-Party Plugins
* ADR-018: Separation of Execution, Observation, and Verification

---

### ADR-001: Central Core Authority Model
* Status: ACCEPTED
* Context: Modern generative AI models exhibit hallucinations, probabilistic variance, and susceptibility to prompt injection. Allowing an AI model direct access to operating system APIs or execution authority introduces unacceptable catastrophic risk.
* Decision: Establish an absolute architectural authority hierarchy: AI Proposes, Policy Authorizes, Core Executes, Sensors Observe, Verification Proves. The Core Orchestrator is the sole entity capable of generating signed execution tokens.
* Alternatives Considered:
  1. Autonomous Agent Model (AI directly invokes tool binaries): Rejected due to complete lack of deterministic safety boundaries.
  2. Rule-Based System without AI: Rejected due to inability to understand flexible natural language intent.
* Consequences: Strict security boundary; requires formal serialization and IPC overhead between planner and executor.
* Security Impact: Completely eliminates direct prompt-injection-to-execution vulnerabilities.
* Reliability Impact: Centralized state machine enables predictable crash recovery and auditing.

### ADR-004: Fencing Epochs and Lease Tokens for Side-Effect Control
* Status: ACCEPTED
* Context: In distributed and multi-process systems, worker processes may experience latency spikes, garbage collection pauses, or network hangs. If a worker resumes execution after the Core has timed it out and reassigned the task, destructive write collisions occur.
* Decision: Require all state-modifying capabilities to validate a monotonic `OwnershipEpoch` and `grant_token` against the authoritative Resource Lock Table before committing physical I/O.
* Alternatives Considered: Universal Distributed Locking (Consul/ZooKeeper): Rejected as overly complex and heavy for a single-host desktop application.
* Consequences: Capability workers must implement epoch checks in their execution harnesses.
* Security & Reliability Impact: Eliminates split-brain execution and stale-worker file corruption.

### ADR-010: Cryptographic Hash-Chained Audit Ledger with Merkle Anchoring
* Status: ACCEPTED
* Context: Standard flat text logs can be easily modified, truncated, or deleted by compromised subprocesses or malicious actors attempting to hide unauthorized actions.
* Decision: Implement an append-only audit ledger where every event encapsulates the SHA-256 hash of its predecessor, anchored periodically by signed Merkle roots. Core boot enforces strict verification; any hash mismatch halts the system into `SAFE_LOCKDOWN`.
* Alternatives Considered: Windows Event Log exclusively: Insufficient structured querying and lack of native cryptographic hash-chaining across application-level entities.
* Consequences: Requires local signing key management; audit storage must be append-only.
* Security Impact: Provides immutable forensic proof of all actions, authorizations, and system states.
