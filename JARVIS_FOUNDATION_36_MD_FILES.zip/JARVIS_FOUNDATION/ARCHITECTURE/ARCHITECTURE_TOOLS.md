# CAPABILITY & TOOL SUBSYSTEM SPECIFICATION
Document Identifier: JARVIS-ARCH-011
Status: DRAFT

---

## 1. CAPABILITY MANIFEST SCHEMA

Every capability exposed to JARVIS must be defined by a strictly typed manifest. No dynamic or undeclared tool execution is permitted.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "CapabilityManifest",
  "type": "object",
  "properties": {
    "capability_id": { "type": "string", "pattern": "^[a-z0-9_]+\\.[a-z0-9_]+$" },
    "version": { "type": "string", "pattern": "^\\d+\\.\\d+\\.\\d+$" },
    "display_name": { "type": "string" },
    "description": { "type": "string" },
    "risk_tier": { "type": "string", "enum": ["TIER_0_READ", "TIER_1_LOW", "TIER_2_MEDIUM", "TIER_3_HIGH", "TIER_4_CRITICAL"] },
    "idempotency_class": { "type": "string", "enum": ["STRICTLY_IDEMPOTENT", "CONDITIONALLY_IDEMPOTENT", "NON_IDEMPOTENT"] },
    "side_effect_classification": { "type": "string", "enum": ["READ_ONLY", "LOCAL_FS_WRITE", "LOCAL_PROCESS_MUTATION", "NETWORK_EGRESS", "EXTERNAL_COMMUNICATION"] },
    "simulatable": { "type": "boolean" },
    "input_schema": { "type": "object" },
    "output_schema": { "type": "object" },
    "required_privilege_level": { "type": "string", "enum": ["SANDBOX_LOW", "STANDARD_MEDIUM", "ELEVATED_HIGH"] }
  },
  "required": [
    "capability_id", "version", "display_name", "risk_tier",
    "idempotency_class", "side_effect_classification",
    "simulatable", "input_schema", "output_schema"
  ]
}
```
2. IDEMPOTENCY & DEDUPLICATION
To avoid disastrous duplicate operations (such as double file deletion or duplicate payment submissions), every tool invocation requires an authoritative DeduplicationIdentity:

```text
DedupKey
=
SHA256
(
CapabilityID
∥
CanonicalJSON
(
Parameters
)
∥
ResourceKey
∥
TaskID
)
DedupKey=SHA256(CapabilityID∥CanonicalJSON(Parameters)∥ResourceKey∥TaskID)
```

Evaluation: Before dispatching a tool attempt, the Execution Controller evaluates the DedupKey against the active and historical execution store.
Handling Matches:
If an operation with identical DedupKey is currently EXECUTING, the caller awaits the existing attempt's result.
If an operation with identical DedupKey COMPLETED successfully within the current task context, the stored result is returned immediately without physical re-execution.
If the tool is classified as NON_IDEMPOTENT and an attempt failed in an ambiguous state, automatic reuse is strictly forbidden.
