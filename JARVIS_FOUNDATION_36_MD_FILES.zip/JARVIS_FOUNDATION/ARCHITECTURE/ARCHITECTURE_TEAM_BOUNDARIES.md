# ENGINEERING TEAM BOUNDARIES & CONTRACTS
Document Identifier: JARVIS-ARCH-029
Status: DRAFT

---

## 1. ORGANIZATIONAL MATRIX & CONTRACTS

To facilitate concurrent, conflict-free development across 19 independent engineering teams, every subsystem is bounded by clear ownership, contract deliverables, and interface obligations.

| Team ID | Owning Subsystem | Core Contract Provided | Consumed Interfaces | Integration Test Obligation |
| :--- | :--- | :--- | :--- | :--- |
| `TEAM-CORE` | Core Orchestrator | `CTR-001: RequestIntake` | `SYS-SEC`, `SYS-AUD`, `SYS-PLAN` | End-to-end task lifecycle tests |
| `TEAM-SEC` | Security Kernel | `CTR-003: PolicyEval` | `SYS-AUD`, OS Keystore | Policy pass/fail test harness |
| `TEAM-AI` | AI Router & Parsing | `CTR-004: InferenceReq` | Provider Endpoints | Schema conformance benchmarks |
| `TEAM-PLAN` | Task DAG Planner | `CTR-005: PlanCompile` | `SYS-AI` | Cycle-freedom & replanning tests |
| `TEAM-EXEC` | Execution Controller | `CTR-002: WorkerDispatch`| `SYS-TOOL`, Windows Jobs | Fencing epoch race conditions |
| `TEAM-WIN` | Windows Automation | `CTR-006: WinAction` | Win32 / UIA COM APIs | UI tree interaction harness |
| `TEAM-WEB` | Browser Daemon | `CTR-007: WebAction` | Chromium CDP WebSocket | DOM scraping & script isolation |
| `TEAM-VOX` | Audio & Voice | `CTR-008: AudioStream` | Local Audio Device | Wake-word & barge-in latency tests |
| `TEAM-VIS` | Vision & OCR | `CTR-009: VisionFrame` | Desktop Duplication API | Spatial coordinate accuracy |
| `TEAM-MEM` | Memory Subsystem | `CTR-010: MemoryStore` | SQLite-vec, DPAPI | Cryptographic shredding tests |
| `TEAM-AND` | Android Companion | `CTR-011: RemoteIntent` | Noise Protocol / E2EE | Out-of-band authorization flow |
| `TEAM-AUD` | Tamper-Evident Audit | `CTR-012: AuditAppend` | Filesystem Raw IO | Hash-chain integrity verifier |
| `TEAM-FE` | Presentation UI | UI Telemetry Views | `CTR-001` (Core Pipe) | Anti-clickjacking window tests |

---

## 2. INTEGRATION GATES & CONTRACT ENFORCEMENT

1. Breaking Changes: Any change to a canonical contract schema requires an RFC, a version bump (`v1.x` to `v2.x`), and backward compatibility adapters maintained for at least one minor release.
2. Independent CI Validation: Every team repository maintains an isolated CI test suite that validates their subsystem against mock implementations of consumed contracts before merging into the main branch.
