# OBSERVATION & VERIFICATION SUBSYSTEM
Document Identifier: JARVIS-ARCH-021
Status: DRAFT

---

## 1. THE VERIFICATION TRIAD

Execution, Observation, and Verification are decoupled into distinct lifecycle phases:
```text
+--------------------------------------------------------------------------+
| 1. EXECUTION PHASE (SYS-EXEC) |
| Worker issues command to application / operating system. |
| Receives return code / API ACK. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 2. OBSERVATION PHASE (SYS-PERCEPTION) |
| Passive environmental sensors independently poll resulting state. |
| - Filesystem: Query path existence, size, SHA-256 hash. |
| - UI: Query UIA accessibility tree, capture screen OCR. |
| - Process: Query Win32 process list, listening network sockets. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 3. VERIFICATION PHASE (SYS-VERIFY) |
| Evaluates observed state against node postcondition assertions. |
| Emits authoritative verdict: SATISFIED, UNSATISFIED, or INDETERMINATE. |
+--------------------------------------------------------------------------+
```


---

## 2. POSTCONDITION ASSERTION SCHEMAS

Every plan node embeds an explicit postcondition contract:
```json
{
  "postconditions": [
    {
      "sensor": "filesystem.exists",
      "target": "C:\\Data\\Output.csv",
      "expected": true
    },
    {
      "sensor": "filesystem.min_size",
      "target": "C:\\Data\\Output.csv",
      "expected_bytes": 1024
    }
  ]
}
```
Invariant: If verification yields INDETERMINATE (e.g., target file is locked, UI fails to render within timeout), the task cannot proceed to subsequent dependent nodes and must transition to AMBIGUOUS_HALTED.
