# EVENT ARCHITECTURE & CAUSALITY SPECIFICATION
Document Identifier: JARVIS-ARCH-004
Status: DRAFT

---

## 1. EVENT ORDERING & CAUSALITY

JARVIS enforces deterministic causality across distributed processes and asynchronous operations. Physical wall-clock time is insufficient for concurrency management due to clock drift and thread interleaving; therefore, the system employs hybrid logical clocks (HLC) and per-task vector clocks.

### 1.1 Causality Vector Representation
Every event encapsulates:
1. `wall_clock_utc`: ISO 8601 UTC timestamp (microsecond precision).
2. `monotonic_counter`: Hardware monotonic timer (`QueryPerformanceCounter`).
3. `task_sequence_number`: Monotonically increasing unsigned 64-bit integer scoped to the `task_id`.
4. `causal_parent_event_id`: UUID of the direct causal predecessor.
```text
Core Dispatch (Seq: 1)
|
+-----> Worker Spawn (Seq: 2, Parent: 1)
| |
| v
| Tool Invocation (Seq: 3, Parent: 2)
| |
+<-------------+
| (Result Returned)
v
Verification (Seq: 4, Parent: 3)
```


---

## 2. EVENT TAXONOMY & SCHEMAS

Events are partitioned into three distinct topological scopes:
* Global System Events: Core lifecycle, security lockdowns, worker process terminations.
* Task Events: DAG state mutations, user confirmation requests, task replanning triggers.
* Node/Execution Events: Tool dispatch, environmental observations, fencing revocations.

### 2.1 Canonical Event Envelope
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SystemEventEnvelope",
  "type": "object",
  "properties": {
    "event_id": { "type": "string", "format": "uuid" },
    "event_type": { "type": "string" },
    "task_id": { "type": ["string", "null"], "format": "uuid" },
    "node_id": { "type": ["string", "null"] },
    "execution_id": { "type": ["string", "null"], "format": "uuid" },
    "sequence": { "type": "integer", "minimum": 0 },
    "hlc_timestamp": {
      "type": "object",
      "properties": {
        "physical_utc": { "type": "string", "format": "date-time" },
        "logical_counter": { "type": "integer" }
      },
      "required": ["physical_utc", "logical_counter"]
    },
    "causal_parent_id": { "type": ["string", "null"], "format": "uuid" },
    "payload": { "type": "object" },
    "signature": { "type": "string" }
  },
  "required": ["event_id", "event_type", "sequence", "hlc_timestamp", "payload"]
}
```
3. PERSISTENCE & REPLAY PROTECTION
Append-Only Persistence: All events are flushed to an append-only SQLite WAL table prior to processing by downstream subscribers.
In-Memory Ring Buffer: The last 10,000 events are retained in non-pageable memory for real-time causality resolution and UI telemetry.
Replay Defense: The Core maintains an in-memory hash table of observed event nonces for the preceding 10-minute window. Incoming IPC messages with duplicate nonces or regressive sequence numbers are dropped and flagged as security anomalies.
