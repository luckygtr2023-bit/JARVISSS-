# BROWSER AUTOMATION SUBSYSTEM SPECIFICATION
Document Identifier: JARVIS-ARCH-013
Status: DRAFT

---

## 1. MULTI-PROFILE ISOLATION MODEL

The Browser Subsystem operates multi-process Chromium instances via the Chrome DevTools Protocol (CDP), maintaining strict physical isolation between user profiles:
```text
+--------------------------------------------------------------------------+
| Profile Type: EPHEMERAL AUTOMATION (Default) |
| - Storage: In-memory or temporary disk sandbox (purged on task end). |
| - Credentials: Zero access to host user cookies or saved passwords. |
| - Usage: Information retrieval, web scraping, public form processing. |
+--------------------------------------------------------------------------+

+--------------------------------------------------------------------------+
| Profile Type: AUTHENTICATED USER BRIDGE (Restricted) |
| - Storage: Bound to user-authorized persistent browser profile. |
| - Credentials: Live session cookies for trusted SaaS domains. |
| - Policy: ALL navigation to unlisted domains blocked. State-changing |
| POST/PUT requests require explicit Tier 3 synchronous confirmation. |
+--------------------------------------------------------------------------+
```


---

## 2. JAVASCRIPT EXECUTION MODES

To mitigate DOM-based prompt injection and malicious script execution, the browser enforces three operational tiers:

1. `READ_ONLY_HEADLESS`: JavaScript execution is disabled entirely; pages are rendered strictly as static HTML snapshots.
2. `CONTROLLED_DOM_INTERACTIVE`: JavaScript is active for page rendering, but CDP command interception blocks `eval()`, Web Workers, and direct network fetches outside the host domain.
3. `FULL_INTERACTIVE_SUPERVISED`: Unrestricted script execution permitted strictly under real-time human visual supervision via the desktop overlay.

---

## 3. UNTRUSTED DOM SANITIZATION

Data extracted from the DOM undergoes multi-stage sanitization before ingestion into the AI Planning context:
1. Stripping Executable Elements: All `<script>`, `<style>`, `<iframe>`, and `<object>` tags are stripped.
2. Hidden Element Pruning: Elements with CSS attributes `display: none`, `visibility: hidden`, or zero opacity are removed to defeat hidden-text prompt injections.
3. Structural Normalization: The DOM is collapsed into a clean, semantic Markdown representation of interactive elements, links, and text nodes.
