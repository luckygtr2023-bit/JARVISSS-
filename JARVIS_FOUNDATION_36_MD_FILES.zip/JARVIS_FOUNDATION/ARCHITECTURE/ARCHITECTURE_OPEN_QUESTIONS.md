# ARCHITECTURAL OPEN QUESTIONS & RESEARCH SPIKES
Document Identifier: JARVIS-ARCH-034
Status: DRAFT

---

## 1. ACTIVE RESEARCH SPIKES & OPEN TRADEOFFS

The following architectural questions are actively undergoing empirical evaluation and must be resolved prior to moving the architecture from DRAFT to LOCKED baseline:

### Q-01: Local Multimodal Vision Latency vs. Cloud Privacy Tradeoff
* Affected Subsystem: `SYS-VIS`, `SYS-AI`
* Context: Real-time visual screen grounding requires parsing high-resolution desktop frames. Cloud multimodal models (e.g., Claude 3.5 Sonnet, GPT-4o) offer superior grounding accuracy but introduce network egress latency (800ms - 2500ms) and privacy concerns. Local multimodal models (e.g., LLaVA, Phi-3-Vision) offer zero egress and lower latency (200ms - 600ms on RTX 4080+) but exhibit lower spatial precision on dense UI accessibility trees.
* Architectural Impact: Determining whether visual grounding should default to local models with cloud fallback or enforce strict local-only execution for all screen analysis.
* Recommended Initial Direction: Implement a hybrid approach: Local OCR + UIA semantic tree first; if element lookup fails, execute local CV redaction before dispatching visual frame to the user-authorized model tier.

### Q-02: AppContainer vs. Hyper-V/WSL2 Containers for Untrusted Code Execution
* Affected Subsystem: `SYS-PLUGINS`, `SYS-TOOL`
* Context: Running user-authored Python or Node.js automation scripts requires heavy sandboxing. Windows AppContainers provide lightweight, native OS process isolation but share the NT kernel. Micro-VM containers (Hyper-V / WSL2 lightweight utility VMs) provide hardware-assisted kernel isolation but incur memory overhead (~500MB RAM) and cold-boot delays (~1.5s).
* Architectural Impact: Affects plugin host initialization time and host memory footprint.
* Recommended Initial Direction: Use Windows AppContainers for native compiled C++/Win32 plugins; use ephemeral WSL2 micro-containers for dynamic Python/Bash script execution.

### Q-03: TPM 2.0 Hardware Attestation for Android Companion Pairing
* Affected Subsystem: `SYS-AND`, `SYS-SEC`
* Context: Should desktop-to-Android pairing secrets be physically bound to the host PC's TPM 2.0 chip using Windows Platform Crypto Provider, or is standard Windows DPAPI software encryption sufficient?
* Architectural Impact: Binding to TPM 2.0 prevents credential extraction even if the host hard drive is forensically cloned, but increases development complexity on custom Windows desktop hardware lacking TPM configuration.
* Recommended Initial Direction: Require TPM 2.0 by default, with automatic software fallback to DPAPI on systems where hardware TPM is unavailable, logging a security warning to the audit ledger.
