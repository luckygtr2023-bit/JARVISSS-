# SIMULATION & DRY-RUN ARCHITECTURE
Document Identifier: JARVIS-ARCH-020
Status: DRAFT

---

## 1. THREE-TIER SIMULATION CAPABILITY

Prior to requesting user confirmation for Tier 2 and Tier 3 actions, the Simulation Engine predicts side effects and estimates the plan's blast radius.

```text
                   +------------------------+
                   | Candidate Action Node  |
                   +------------------------+
                               |
                               v
                   +------------------------+
                   | Simulation Class Check |
                   +------------------------+
                               |
     +-------------------------+-------------------------+
     |                         |                         |
     v                         v                         v
+------------------+ +------------------+ +------------------+
| FULLY_SIMULATABLE| |PARTIALLY_SIMULATE| | NOT_SIMULATABLE |
| - Local FS Copy | | - Browser DOM | | - Send Email |
| - Temp File Ops | | Click | | - Financial Pay |
+------------------+ +------------------+ +------------------+
| | |
v v v
+------------------+ +------------------+ +------------------+
| Execute in Staged| | Emulate in Mock | | Generate Blast- |
| Virtual Sandbox | | Headless DOM | | Radius Estimate |
+------------------+ +------------------+ +------------------+
| | |
+-------------------------+-------------------------+
|
v
+--------------------------+
| Produce Simulation Report|
| Diff: Files, Reg, Net |
+--------------------------+
```


---

## 2. SIMULATION REPORT SCHEMAS

The output of the Simulation Engine is presented directly in the human confirmation dialog:
```json
{
  "simulation_status": "SIMULATED_SUCCESS",
  "fidelity": "HIGH",
  "predicted_side_effects": {
    "files_created": ["C:\\Users\\User\\Documents\\Summary.docx"],
    "files_modified": [],
    "files_deleted": [],
    "network_endpoints": ["api.anthropic.com"],
    "estimated_cost_usd": 0.015
  },
  "uncertainty_notes": null
}
```
Invariant: A successful simulation is an informational tool for the user; it never bypasses the requirement for human authorization on high-risk operations.
