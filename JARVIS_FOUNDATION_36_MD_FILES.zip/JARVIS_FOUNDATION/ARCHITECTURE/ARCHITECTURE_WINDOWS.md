# WINDOWS PLATFORM INTEGRATION ARCHITECTURE
Document Identifier: JARVIS-ARCH-012
Status: DRAFT

---

## 1. INTEGRITY LEVELS & PRIVILEGE BOUNDARIES

JARVIS adheres strictly to Windows Least Privilege and User Account Control (UAC) boundary models:
```text
+--------------------------------------------------------------------------+
| HIGH INTEGRITY (Elevated Admin) |
| Windows UAC Elevation Helper Service (Isolated, Out-of-Process COM) |
| Strictly invoked via OS UAC prompt; handles driver/system updates. |
+--------------------------------------------------------------------------+
^
| (IPC via Named Pipe with Strict DACL)
+--------------------------------------------------------------------------+
| MEDIUM INTEGRITY (Standard User) |
| Core Orchestrator, Task Planner, Policy Engine, Memory Store |
| Runs within standard interactive user desktop session. |
+--------------------------------------------------------------------------+
|
| (Job Object + Restricted Token)
v
+--------------------------------------------------------------------------+
| LOW INTEGRITY / APPCONTAINER (Untrusted Sandbox) |
| Browser Daemons, Third-Party Plugins, Untrusted File Parsers |
| Zero write access to user files outside designated AppData isolation box.|
+--------------------------------------------------------------------------+
```


---

## 2. DUAL-MODE WINDOWS CONTROL

Windows automation combines native semantic tree inspection with a computer vision fallback:

```text
                +---------------------------+
                |   UI Interaction Intent   |
                +---------------------------+
                              |
                              v
                +---------------------------+
                |    Query UIA COM Tree     |
                +---------------------------+
                              |
                 +------------+------------+
                 |                         |
          (Element Found)           (Element Missing)
                 v                         v
   +---------------------------+ +---------------------------+
   | Native UIA Action Dispatch| | Visual Fallback Activated |
   | - InvokeProvider          | | - High-Res Screen Capture |
   | - ValuePattern.SetValue   | | - OCR / Grounding Model   |
   | - SelectionItemPattern    | | - Template Match / BBox   |
   +---------------------------+ +---------------------------+
                 |                         |
                 +------------+------------+
                              |
                              v
                +---------------------------+
                | Post-Action Verification  |
                | Verify element/screen state|
                +---------------------------+
```


---

## 3. FILESYSTEM SAFETY & CANONICALIZATION

Filesystem access violations are prevented through mandatory kernel-level path canonicalization prior to policy evaluation:
1. Canonical Path Resolution: Paths are converted to their volume-guid canonical form using Win32 `GetFinalPathNameByHandleW` to eliminate bypasses via symlinks, junction points, 8.3 short names (`PROGRA~1`), or relative traversal (`..`).
2. Protected Directory Deny-List: Core policies strictly deny modification of `C:\Windows\*`, `C:\Program Files\*`, and boot partitions unless explicitly unlocked via a Tier 4 administrative confirmation.
