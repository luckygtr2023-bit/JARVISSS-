# INTER-PROCESS COMMUNICATION (IPC) SPECIFICATION
Document Identifier: JARVIS-ARCH-018
Status: DRAFT

---

## 1. TRANSPORT & SESSION BOOTSTRAP

All inter-process communication on the Windows host relies on Windows Named Pipes with Discretionary Access Control Lists (DACLs) restricted strictly to the current user SID and Local System.
```text
Core Orchestrator Worker Process
| |
| 1. Create Named Pipe with DACL |
| \.\pipe\jarvis-worker-pool-{UUID} |
| |
| 2. Spawn Worker with Handshake Token via Env Handle |
+---------------------------------------------------------->|
| |
| 3. Worker Connects to Named Pipe |
|<==========================================================+
| |
| 4. Mutual Handshake: Exchange Nonces & Derive Session Key |
|<=========================================================>|
| |
| 5. Core Transmits Fenced Execution Grants |
+---------------------------------------------------------->|
```


---

## 2. PEER VERIFICATION & PROTOCOL DEFENSES

1. Process ID & Integrity Validation: Upon receiving a pipe connection, the Core uses Win32 `GetNamedPipeClientProcessId` to inspect the connecting process. It validates the binary path, digital signature, and Windows Integrity Level of the client PID before completing the handshake.
2. Replay Protection: Every IPC frame encapsulates a strictly increasing 64-bit sequence number and a 12-byte cryptographic nonce. Messages received with stale sequence numbers are dropped immediately.
3. Malformed Message Defense: Payload schemas are validated using zero-allocation stream validators. Any malformed or oversized frame (> 16MB) triggers immediate pipe termination and worker restart.
