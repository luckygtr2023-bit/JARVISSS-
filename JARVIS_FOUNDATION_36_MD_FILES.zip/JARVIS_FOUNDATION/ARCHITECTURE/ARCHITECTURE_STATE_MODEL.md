# FORMAL STATE MACHINE SPECIFICATIONS
Document Identifier: JARVIS-ARCH-005
Status: DRAFT

---

## 1. CORE SYSTEM STATE MACHINES

JARVIS state transitions are strictly governed by deterministic finite state automata. No component may transition an entity's state without explicit authorization and logging.

### 1.1 Task Lifecycle State Machine
* States: `RECEIVED`, `PARSING`, `PLANNED`, `POLICY_EVALUATION`, `AWAITING_CONFIRMATION`, `DISPATCHED`, `EXECUTING`, `OBSERVED`, `VERIFYING`, `COMPLETED`, `FAILED`, `AMBIGUOUS_HALTED`, `CANCELLED`.

```text
              +------------+
              |  RECEIVED  |
              +------------+
                    | (Syntactic Validation)
                    v
              +------------+
              |  PARSING   |
              +------------+
                    | (Goal Extracted)
                    v
              +------------+
              |  PLANNED   | <-------------------------+
              +------------+                           | (Replan)
                    | (Policy Evaluation)              |
                    v                                  |
        +-----------------------+                      |
        |   POLICY_EVALUATION   |                      |
        +-----------------------+                      |
         /                     \                       |
(Tier 0-1) / \ (Tier 2-4) |
v v |
+--------------+ +-----------------------+ |
| DISPATCHED | | AWAITING_CONFIRMATION | |
+--------------+ +-----------------------+ |
| | (User Confirmed) |
| v |
+-------------------> +--------------+ |
| DISPATCHED | |
+--------------+ |
| |
v |
+--------------+ |
| EXECUTING | |
+--------------+ |
| |
v |
+--------------+ |
| OBSERVED | |
+--------------+ |
| |
v |
+--------------+ |
| VERIFYING | |
+--------------+ |
/ | \ |
(Success) / | \ (Fail) |
v | v |
+-----------+ | +-----------+ |
| COMPLETED | | | FAILED |--+
+-----------+ | +-----------+
| (Indeterminate)
v
+--------------------+
| AMBIGUOUS_HALTED |
+--------------------+
```


#### Task State Transition Table
| Current State | Event / Trigger | Guard Condition | Target State | Action / Output |
| :--- | :--- | :--- | :--- | :--- |
| `RECEIVED` | `PARSE_INTENT` | Schema valid | `PARSING` | Spawn parser context |
| `PARSING` | `GOAL_COMPILED` | Valid PlanDAG generated | `PLANNED` | Emit `PlanCompiledEvent` |
| `PLANNED` | `EVALUATE_POLICY` | System unconstrained | `POLICY_EVALUATION` | Query Policy Engine |
| `POLICY_EVALUATION` | `POLICY_ALLOWED` | Risk Tier <= Tier 1 | `DISPATCHED` | Issue Execution Grants |
| `POLICY_EVALUATION` | `POLICY_CHALLENGE`| Risk Tier >= Tier 2 | `AWAITING_CONFIRMATION` | Render UI/Android Prompt |
| `AWAITING_CONFIRMATION`| `USER_APPROVE` | Valid cryptographic signature | `DISPATCHED` | Issue Execution Grants |
| `AWAITING_CONFIRMATION`| `USER_DENY` | - | `CANCELLED` | Revoke Plan DAG |
| `DISPATCHED` | `WORKER_ACQUIRED`| Resource keys locked | `EXECUTING` | Send IPC execution frame |
| `EXECUTING` | `WORKER_COMPLETED`| Result received within timeout | `OBSERVED` | Intake observation struct |
| `EXECUTING` | `TIMEOUT_EXPIRED`| No ACK from worker | `AMBIGUOUS_HALTED` | Terminate Job, Revoke Epoch |
| `OBSERVED` | `RUN_VERIFICATION`| Sensor operational | `VERIFYING` | Dispatch to Verification Plane|
| `VERIFYING` | `VERIFY_SUCCESS`| Postconditions satisfied | `COMPLETED` | Flush final status to audit |
| `VERIFYING` | `VERIFY_FAIL` | Retry budget remaining | `PLANNED` | Trigger Delta Replanner |
| `VERIFYING` | `VERIFY_FAIL` | Retry budget exhausted | `FAILED` | Terminate task with error |
| `VERIFYING` | `VERIFY_INDETERMINATE` | Sensor drift / unreachable | `AMBIGUOUS_HALTED` | Alert user; freeze tasks |

---

### 1.2 Plan Node Lifecycle State Machine
* States: `PENDING`, `READY`, `BLOCKED`, `ALLOCATING_RESOURCES`, `ACTIVE`, `POST_PROCESSING`, `SATISFIED`, `FAILED`, `SKIPPED`.

### 1.3 Resource Ownership State Machine
* States: `FREE`, `RESERVED`, `LEASED_ACTIVE`, `LEASE_EXPIRED`, `FROZEN_CONFLICT`.
* Invariant: Transition from `LEASED_ACTIVE` to any other state increments the resource's monotonic `OwnershipEpoch` counter, invalidating all outstanding worker tokens for that key.

### 1.4 Browser Session State Machine
* States: `UNINITIALIZED`, `PROVISIONING_PROFILE`, `HEADLESS_SCRAPING`, `INTERACTIVE_DOM`, `AWAITING_AUTH_SUBMISSION`, `QUARANTINED`, `TERMINATED`.

### 1.5 Android Companion Session State Machine
* States: `DISCONNECTED`, `PAIRING_HANDSHAKE`, `ESTABLISHED_MUTUAL_AUTH`, `ACTIVE_HEARTBEAT`, `CHALLENGE_IN_FLIGHT`, `SESSION_REVOKED`.
