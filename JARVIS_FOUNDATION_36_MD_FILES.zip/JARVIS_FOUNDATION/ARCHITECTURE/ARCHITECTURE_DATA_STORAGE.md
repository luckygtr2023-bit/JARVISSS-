# DATA STORAGE & PERSISTENCE ARCHITECTURE
Document Identifier: JARVIS-ARCH-025
Status: DRAFT

---

## 1. STORAGE REPOSITORY MAP

System persistence is partitioned across dedicated, purpose-built engines:

| Data Category | Target Engine | Encryption | Access Policy |
| :--- | :--- | :--- | :--- |
| Core Task State & DAGs | SQLite (WAL Mode) | DPAPI / AES-256 | Core Orchestrator exclusively |
| Audit Ledger | Append-Only Flat File | SHA-256 Chained | Append: All; Read: Root/Admin |
| Semantic Memory Vectors| SQLite-vec / Chroma | AES-256 (User Key) | Memory Subsystem exclusively |
| Secrets & Tokens | Windows Credential Manager | OS-Level DPAPI | Security Kernel exclusively |
| Workspaces & Artifacts | Local NTFS Filesystem | Windows EFS / NTFS ACLs | Execution Controller & Workers |

---

## 2. CONCURRENCY & WRITE-AHEAD LOGGING (WAL)

All SQLite databases are configured in Write-Ahead Logging (`PRAGMA journal_mode=WAL;`) with synchronous commit flags (`PRAGMA synchronous=NORMAL;`).
* Single Writer, Multiple Readers: Writes are serialized through the owning subsystem's single-threaded event loop, avoiding database lock contention.
* Zero Corruption Assurance: Automated database integrity checks (`PRAGMA integrity_check;`) execute on every cold startup.
