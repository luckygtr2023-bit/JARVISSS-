# RELIABILITY & FAULT TOLERANCE SPECIFICATION
Document Identifier: JARVIS-ARCH-024
Status: DRAFT

---

## 1. WATCHDOGS & SUPERVISION TOPOLOGY

JARVIS uses hierarchical supervision to prevent hangs, resource leaks, and unhandled crashes:
```text
+--------------------------------------------------------------------------+
| System Watchdog Daemon (Lightweight, Independent Process) |
| - Monitors Core Orchestrator heartbeat via local pipe. |
| - If Core hangs for > 30s: Capture memory dump, restart Core. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| Core Supervisor (SYS-CORE) |
| - Monitors Worker processes via Windows Job Object event notifications. |
| - Tracks per-node execution timeout budgets. |
| - If Worker hangs: Issues TerminateJobObject, revokes fencing epoch. |
+--------------------------------------------------------------------------+
```


---

## 2. CIRCUIT BREAKERS & RETRY POLICIES

To prevent cascading failures and API quota exhaustion, circuit breakers protect all external integrations:

1. Thresholds: Three consecutive failures trip the circuit breaker into `OPEN` state for 60 seconds.
2. Half-Open Probing: After the backoff window, a single canary request tests provider health.
3. Safe Retry Invariants:
   * Retries are permitted ONLY for capabilities classified as `STRICTLY_IDEMPOTENT`.
   * Retries must use truncated exponential backoff with full randomized jitter:
$$t_{\text{wait}} = \min(t_{\text{max}}, t_{\text{base}} \times 2^{\text{attempt}}) \pm \text{random\_jitter}$$
   * Retries are prohibited for actions with `NON_IDEMPOTENT` side effects or `AMBIGUOUS` verification outcomes.
