# CANONICAL DATA ARCHITECTURE SPECIFICATION
Document Identifier: JARVIS-ARCH-003
Status: DRAFT

---

## 1. CANONICAL ENTITY RELATIONSHIP MODEL
```text
+---------------+ 1:N +---------------+
| User |-------------------| Session |
+---------------+ +---------------+
| 1:N
v
+---------------+ 1:N +---------------+
| Goal |-------------------| Request |
+---------------+ +---------------+
| |
| 1:1 | 1:1
v v
+---------------+ 1:N +---------------+
| Plan |-------------------| Task |
+---------------+ +---------------+
| 1:N | 1:N
v v
+---------------+ 1:N +---------------+
| Plan Node |-------------------| Execution |
+---------------+ +---------------+
| | 1:N
| 1:N v
+---------------+ +---------------+
| OwnershipGrant| | Attempt |
+---------------+ +---------------+
| 1:1
v
+---------------+
| Observation |
+---------------+
| 1:1
v
+---------------+
| Verification |
+---------------+
```


---

## 2. CANONICAL DATA DICTIONARY

### 2.1 Identity & Authority Entities
* `User`: Represents the authenticated human owner. Identity is verified via OS Security Identifier (SID) or Android biometric key.
  * Mutability: Immutable core attributes.
  * Security Implication: Highest authority boundary.
* `Session`: Bounded operational window for user interaction. Contains security credentials, active window state, and context flags.
  * Lifecycle: Created on user presence/login; terminated on logout or timeout.
* `Authorization`: Cryptographically signed approval for an action, issued by `SYS-SEC`. Contains permitted action hashes, expiration timestamp, and risk tier.
* `Confirmation`: User-affirmed assertion answering an `AuthorizationChallenge`. Contains signature, timestamp, and challenge ID.
* `OwnershipGrant`: Authoritative lease linking an `Execution` to a specific `ResourceKey` with a strictly increasing `OwnershipEpoch`.
  * Invariant: No write side-effect may commit without an active, non-expired `OwnershipGrant`.

### 2.2 Planning & Execution Entities
* `Goal`: High-level validated intent extracted from natural language input.
* `Plan`: Directed Acyclic Graph (DAG) consisting of discrete `PlanNodes` with explicit causal dependencies and resource declarations.
* `PlanNode`: Atomic execution unit containing:
  * `node_id`: Stable alphanumeric identifier.
  * `dependencies`: List of parent `node_id`s that must complete successfully.
  * `capability`: FQCN of requested tool (e.g., `sys.win.process.start`).
  * `parameters`: Fully canonicalized parameter dictionary.
  * `resource_declarations`: Set of `ResourceKeys` read or mutated.
  * `side_effect_budget`: Maximum permitted external modifications.
* `Execution`: Runtime instance of a `PlanNode` assigned to a worker process.
* `Attempt`: Concrete invocation turn of an `Execution`. Tracks transient retry counters and worker assignments.
* `Observation`: Raw state output collected from the environment following an `Attempt`.
* `VerificationResult`: Output of the Verification Engine assessing whether an `Observation` satisfies the node's required postconditions. Values: `SATISFIED`, `UNSATISFIED`, `INDETERMINATE`.

### 2.3 Memory & Storage Entities
* `MemoryRecord`: Discrete semantic or episodic record.
  * Schema:
    * `memory_id`: UUIDv4.
    * `provenance`: Originating `task_id`, `node_id`, and user ID.
    * `confidence_score`: Float [0.0 - 1.0].
    * `classification`: `PREFERENCE`, `FACT`, `EPISODE`, `PROCEDURAL`.
    * `payload`: Structured JSON text.
    * `embedding_vector`: High-dimensional float vector.
    * `encryption_key_id`: Pointer to DPAPI-wrapped tenant key.
    * `ttl_utc`: Expiration timestamp (or NULL for permanent).
* `AuditEvent`: Cryptographically chained record of a system event.
  * Attributes: `event_id`, `sequence_number`, `prev_hash_sha256`, `timestamp_utc`, `event_type`, `actor`, `task_id`, `payload_hash`, `signature`.
* `Artifact`: Persistent file or binary blob created or modified during execution. Tracked with SHA-256 hash, creation epoch, and workspace path.
