# SYSTEM DEPENDENCY ARCHITECTURE
Document Identifier: JARVIS-ARCH-028
Status: DRAFT

---

## 1. DIRECTED SUBSYSTEM DEPENDENCY GRAPH

Subsystem dependencies flow strictly downward toward foundational, stable layers. Upward or circular dependencies are prohibited.
```text
Level 4: Presentation & Outer Peripherals
[SYS-FE: Desktop HUD] [SYS-AND: Android Gateway]
| |
+--------------+--------------+
v
Level 3: Core Control & Planning
+-----------------------------+
| [SYS-CORE] |
+-----------------------------+
| | |
v v v
[SYS-PLAN] [SYS-SEC] [SYS-EXEC]
| | |
v v v
[SYS-AI] [SYS-MEM] [SYS-TOOL]
|
v
Level 2: Platform Adapters & Workers
[SYS-WIN] [SYS-BROWSER] [SYS-PLUGINS]
| | |
+-----------+----------------+
|
v
Level 1: System Foundations
[SYS-AUD] [SYS-IPC] [SYS-DATA]
```


---

## 2. CIRCULAR DEPENDENCY PREVENTION RULES

1. Rule 1: No capability adapter (`SYS-WIN`, `SYS-BROWSER`) may reference or call the Core Orchestrator (`SYS-CORE`) directly; adapters communicate strictly via IPC response frames to the Execution Controller (`SYS-EXEC`).
2. Rule 2: The Security Kernel (`SYS-SEC`) cannot depend on the AI Gateway (`SYS-AI`). Policies must be evaluated deterministically without reliance on generative model completions.
3. Rule 3: The Audit Logger (`SYS-AUD`) has zero downward dependencies on other application layers; it depends solely on low-level filesystem and cryptographic primitives.
