# COMPUTER VISION & SCREEN UNDERSTANDING
Document Identifier: JARVIS-ARCH-015
Status: DRAFT

---

## 1. SCREEN CAPTURE & SPATIAL UNDERSTANDING

The Vision Subsystem provides spatial and semantic perception of the visual desktop environment.
```text
+-------------------------------------------------------------------------+
| Screen Capture Layer: Desktop Duplication API (DirectX / DXGI) |
| - High-performance screen capture with dirty rect tracking. |
| - Captures only bounding boxes that have actively changed. |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Local PII Redaction & Sensitive Content Blurring Engine |
| - Local CV model identifies password inputs, banking numbers, PII. |
| - Applies Gaussian blur over sensitive regions prior to model routing. |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Optical Character Recognition (OCR) & Semantic Grounding |
| - Local OCR (Windows.Media.Ocr / Tesseract) extracts spatial text. |
| - Maps visual coordinates (x, y, w, h) to UI accessibility nodes. |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Multimodal Spatial Reasoning |
| - Formats normalized coordinates for multimodal AI guidance. |
+-------------------------------------------------------------------------+
```


---

## 2. SPATIAL COORDINATE REPRESENTATION

All visual coordinates are normalized to a fixed resolution-independent scale:
$$x_{\text{norm}} = \frac{x_{\text{pixel}}}{\text{Screen Width}} \times 1000, \quad y_{\text{norm}} = \frac{y_{\text{pixel}}}{\text{Screen Height}} \times 1000$$

Every detected visual target produces a normalized bounding box entity:
```json
{
  "target_id": "btn_submit_01",
  "bounding_box": [120, 450, 240, 480],
  "ocr_text": "Confirm & Send",
  "confidence": 0.985,
  "redacted": false
}
```
