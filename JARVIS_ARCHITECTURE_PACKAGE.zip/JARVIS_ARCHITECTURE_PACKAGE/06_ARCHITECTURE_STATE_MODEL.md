# FORMAL STATE MACHINE SPECIFICATIONS
Document Identifier: JARVIS-ARCH-005
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CORE SYSTEM STATE MACHINES

JARVIS state transitions are strictly governed by deterministic finite state automata. No component may transition an entity's state without explicit authorization and logging.

### 1.1 Task Lifecycle State Machine
* States: `RECEIVED`, `PARSING`, `PLANNED`, `POLICY_EVALUATION`, `AWAITING_CONFIRMATION`, `DISPATCHED`, `EXECUTING`, `SUSPENDED`, `OBSERVED`, `VERIFYING`, `COMPLETED`, `FAILED`, `AMBIGUOUS_HALTED`, `CANCELLED`.

```text
              +------------+
              |  RECEIVED  |
              +------------+
                    | (Syntactic Validation)
                    v
              +------------+
              |  PARSING   |
              +------------+
                    | (Goal Extracted)
                    v
              +------------+
              |  PLANNED   | <-------------------------+
              +------------+                           | (Replan)
                    | (Policy Evaluation)              |
                    v                                  |
        +-----------------------+                      |
        |   POLICY_EVALUATION   |                      |
        +-----------------------+                      |
         /                     \                       |
(RISK_TIER_0-1) / \ (RISK_TIER_2-4) |
v v |
+--------------+ +-----------------------+ |
| DISPATCHED | | AWAITING_CONFIRMATION | |
+--------------+ +-----------------------+ |
| | (User Confirmed) |
| v |
+---> +--------------+ <---+ |
      | DISPATCHED | | |
      +--------------+ | |
      |               | |
      v (VOICE_CANCEL) |
   +----------+ |
   |SUSPENDED | |
   +----------+ |
   | | (USER_REAUTHENTICATE |
   +--------+  or TIMEOUT/ABANDON) |
      | (USER_REAUTHENTICATE → re-auth → policy) |
      | (SUSPENSION_TIMEOUT → CANCELLED) |
      | (USER_ABANDON → CANCELLED) |
      v |
+--------------+ |
| EXECUTING | |
+--------------+ |
| |
v |
+--------------+ |
| OBSERVED | |
+--------------+ |
| |
v |
+--------------+ |
| VERIFYING | |
+--------------+ |
/ | \ |
(Success) / | \ (Fail) |
v | v |
+-----------+ | +-----------+ |
| COMPLETED | | | FAILED |--+
+-----------+ | +-----------+
| (Indeterminate)
v
+--------------------+
| AMBIGUOUS_HALTED |
+--------------------+
```


#### Task State Transition Table
| Current State | Event / Trigger | Guard Condition | Target State | Action / Output |
| :--- | :--- | :--- | :--- | :--- |
| `RECEIVED` | `PARSE_INTENT` | Schema valid | `PARSING` | Spawn parser context |
| `PARSING` | `GOAL_COMPILED` | Valid PlanDAG generated | `PLANNED` | Emit `PlanCompiledEvent` |
| `PLANNED` | `EVALUATE_POLICY` | System unconstrained | `POLICY_EVALUATION` | Query Policy Engine |
| `POLICY_EVALUATION` | `POLICY_ALLOWED` | `risk_tier <= RISK_TIER_1` | `DISPATCHED` | Issue Execution Grants |
| `POLICY_EVALUATION` | `POLICY_PREAPPROVED` | `risk_tier == RISK_TIER_2` **and** a valid, unexpired `PreApprovalLease` covers `(capability_set, resource_keys, tier)` | `DISPATCHED` | Consume a lease use; record `PREAPPROVAL_LEASE_USED` |
| `POLICY_EVALUATION` | `POLICY_CHALLENGE`| `risk_tier >= RISK_TIER_2` and no covering `PreApprovalLease` | `AWAITING_CONFIRMATION` | Render UI/Android Prompt bound to `challenge_binding` |
| `AWAITING_CONFIRMATION`| `USER_APPROVE` | Valid cryptographic signature | `DISPATCHED` | Issue Execution Grants |
| `AWAITING_CONFIRMATION`| `USER_DENY` | - | `CANCELLED` | Revoke Plan DAG |
| `DISPATCHED` | `WORKER_ACQUIRED`| Resource keys locked | `EXECUTING` | Send IPC execution frame |
| `EXECUTING` | `WORKER_COMPLETED`| Result received within timeout | `OBSERVED` | Intake observation struct |
| `EXECUTING` | `VOICE_CANCEL_RECEIVED` | risk_tier >= RISK_TIER_0 | `SUSPENDED` | Terminate in-flight worker, revoke lease at `SYS-FCB`, purge staging, snapshot task context, emit `VOICE_CANCEL_SUSPENDED` |
| `DISPATCHED` | `VOICE_CANCEL_RECEIVED` | - | `SUSPENDED` | Revoke dispatch grant, emit `VOICE_CANCEL_SUSPENDED` |
| `EXECUTING` | `TIMEOUT_EXPIRED`| No ACK from worker, `SYS-FCB` confirms **no** `CommitRecord` and **no** delivery-boundary crossing | `FAILED` | Terminate Job, request epoch increment at `SYS-FCB`, purge staging |
| `EXECUTING` | `TIMEOUT_AMBIGUOUS` | No ACK from worker **and** (`CommitRecord` present, or `FENCEABLE_GATED` delivery crossed, or `NON_FENCEABLE_EXTERNAL` dispatch sent) | `AMBIGUOUS_HALTED` | Terminate Job, request epoch increment at `SYS-FCB`, purge staging, open `AmbiguityRecord` |
| `SUSPENDED` | `USER_REAUTHENTICATE` | Authenticated user re-auth verified at task risk tier | `AWAITING_CONFIRMATION` / `DISPATCHED` | Re-evaluate policy and scope, issue fresh `challenge_binding` or dispatch grant, emit `TASK_RESUMED_FROM_SUSPENSION` |
| `SUSPENDED` | `SUSPENSION_TIMEOUT` | TTL (300s) elapsed | `CANCELLED` | Clean abort, emit `SUSPENSION_EXPIRED` |
| `SUSPENDED` | `USER_ABANDON` | Authenticated user | `CANCELLED` | Clean abort, emit `TASK_ABANDONED_FROM_SUSPENSION` |
| `AWAITING_CONFIRMATION` | `CHALLENGE_EXPIRED` | Challenge TTL elapsed with no response | `AWAITING_CONFIRMATION` | Issue a fresh challenge to any available authenticated channel; increment `challenge_attempt`; **never** treat expiry as approval |
| `AWAITING_CONFIRMATION` | `CHALLENGE_WITHDRAWN` | No authenticated channel remains (device unpaired, session revoked, no local user present) | `CANCELLED` | Revoke grants and leases; emit `CHALLENGE_WITHDRAWN`; nothing is dispatched |
| `OBSERVED` | `RUN_VERIFICATION`| Sensor operational | `VERIFYING` | Dispatch to Verification Plane|
| `VERIFYING` | `VERIFY_SUCCESS`| Postconditions satisfied | `COMPLETED` | Flush final status to audit |
| `VERIFYING` | `VERIFY_FAIL` | Retry budget remaining | `PLANNED` | Trigger Delta Replanner |
| `VERIFYING` | `VERIFY_FAIL` | Retry budget exhausted | `FAILED` | Terminate task with error |
| `VERIFYING` | `VERIFY_INDETERMINATE` | Sensor drift / unreachable | `AMBIGUOUS_HALTED` | Alert user; freeze tasks |

---

### 1.2 Plan Node Lifecycle State Machine
* States: `PENDING`, `READY`, `BLOCKED`, `ALLOCATING_RESOURCES`, `ACTIVE`, `POST_PROCESSING`, `SATISFIED`, `FAILED`, `SKIPPED`.

### 1.3 Resource Ownership State Machine
* States: `FREE`, `RESERVED`, `LEASED_ACTIVE`, `LEASE_EXPIRED`, `FROZEN_CONFLICT`.
* Invariant: Transition from `LEASED_ACTIVE` to any other state causes an increment of the resource's monotonic `OwnershipEpoch`, invalidating every outstanding worker token for that key. The increment is performed by `SYS-FCB` (the sole epoch authority) on request from `SYS-CORE` or `SYS-EXEC`; no other component may change the counter, and a request that is not honoured leaves the lease in force.

### 1.4 Browser Session State Machine
* States: `UNINITIALIZED`, `PROVISIONING_PROFILE`, `HEADLESS_SCRAPING`, `INTERACTIVE_DOM`, `AWAITING_AUTH_SUBMISSION`, `QUARANTINED`, `TERMINATED`.

### 1.5 Android Companion Session State Machine
* States: `DISCONNECTED`, `PAIRING_HANDSHAKE`, `ESTABLISHED_MUTUAL_AUTH`, `ACTIVE_HEARTBEAT`, `CHALLENGE_IN_FLIGHT`, `SESSION_REVOKED`.

### 1.6 Ambiguous State Resolution Machine (F-A-11)

`AMBIGUOUS_HALTED` is a **decision point, not a sink**. Every task entering it carries an `AmbiguityRecord` (task, node, attempt, `fence_class`, `commit_receipt` if any, last known resource hash, external reference if any) and waits for exactly one resolution action.

| Action | Authorization required | Required preconditions | State transition | Downstream effect | Audit event |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `INSPECT` | None (read-only) | Task in `AMBIGUOUS_HALTED` | unchanged | Runs the Verification Plane against the node's postconditions; may *recommend* an action; never resolves alone | `AMBIGUITY_INSPECTED` |
| `CONFIRM_COMPLETED` | Authenticated user (`RISK_TIER_2` modal or Android biometric) | Observation evidence exists that the postcondition holds | `COMPLETED` | Downstream nodes unblock; the attempt is sealed; no retry is ever attempted for this attempt | `AMBIGUITY_RESOLVED_COMPLETED` |
| `CONFIRM_FAILED` | Authenticated user | No evidence of completion, or evidence of failure | `FAILED` (if retry budget exhausted) or `PLANNED` (via `SAFE_REPLAN`) | Replan proceeds under the original `AuthorizedScope`; scope expansion requires a new challenge | `AMBIGUITY_RESOLVED_FAILED` |
| `SAFE_REPLAN` | Authenticated user **and** Policy Engine scope check | Replanned sub-DAG is within the original `AuthorizedScope`; `replan_cycle < 3`; capability is retry-eligible at its assurance level | `PLANNED` | Delta replan of the downstream subgraph only; completed nodes untouched | `AMBIGUITY_SAFE_REPLAN` |
| `ABANDON` | Authenticated user | none | `CANCELLED` | All leases revoked; staging purged; dependent tasks cancelled; external effects (if any) are left and reported | `AMBIGUITY_ABANDONED` |

Guard conditions (apply to every action):
1. **No automatic resolution.** No timer, retry policy, watchdog, or model may transition a task out of `AMBIGUOUS_HALTED`.
2. **No resolution while a lease is live.** `SYS-FCB` must confirm epochs for the affected resources were incremented and staging purged before a resolution is accepted.
3. **`CONFIRM_COMPLETED` on a `NON_FENCEABLE_EXTERNAL` node additionally requires** an external reference (provider idempotency key, transaction id, receipt) or an explicit user attestation recorded with the resolution.
4. **Resolution actions are terminal for that attempt.** After resolution the attempt is immutable; a repeat requires a new `intent_token` (ARCHITECTURE_TOOLS.md §2.4).
5. **Timeout policy:** a task may remain in `AMBIGUOUS_HALTED` indefinitely, but the system raises a persistent UI affordance and a daily reminder; it never self-resolves and never garbage-collects the record.
