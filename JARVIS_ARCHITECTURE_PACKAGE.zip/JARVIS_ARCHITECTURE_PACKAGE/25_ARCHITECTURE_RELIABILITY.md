# RELIABILITY & FAULT TOLERANCE SPECIFICATION
Document Identifier: JARVIS-ARCH-024
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. WATCHDOGS & SUPERVISION TOPOLOGY

JARVIS uses hierarchical supervision to prevent hangs, resource leaks, and unhandled crashes:
```text
+--------------------------------------------------------------------------+
| System Watchdog Daemon (Lightweight, Independent Process) |
| - Monitors Core Orchestrator heartbeat via local pipe. |
| - If Core hangs for > 30s: Capture memory dump, restart Core. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| Core Supervisor (SYS-CORE) |
| - Monitors Worker processes via Windows Job Object event notifications. |
| - Tracks per-node execution timeout budgets. |
| - If Worker hangs: Issues TerminateJobObject, requests epoch revoke at SYS-FCB. |
+--------------------------------------------------------------------------+
```


---

## 2. CIRCUIT BREAKERS & RETRY POLICIES

To prevent cascading failures and API quota exhaustion, circuit breakers protect all external integrations:

1. Thresholds: Three consecutive failures trip the circuit breaker into `OPEN` state for 60 seconds.
2. Half-Open Probing: After the backoff window, a single canary request tests provider health.
3. Safe Retry Invariants:
   * **Retry eligibility is granted by `SYS-SEC`, never by the manifest** (F-A-02, XD-06). A retry is permitted only when CTR-015 reports `retry_eligible: true`, which requires `ASSURANCE_RUNTIME_CONFIRMED` — structural verification plus empirical evidence for this capability version in this environment.
   * `STRICTLY_IDEMPOTENT` requires no precondition. `CONDITIONALLY_IDEMPOTENT` — previously referenced but never defined — is now defined as: *idempotent only while a declared precondition predicate holds over observed resource state* (for example, "target file hash unchanged since attempt 1"). The predicate is evaluated by the Verification Plane immediately before the retry; a false, unknown, or unobservable predicate forbids the retry.
   * Retries must use truncated exponential backoff with full randomized jitter:
$$t_{\text{wait}} = \min(t_{\text{max}}, t_{\text{base}} \times 2^{\text{attempt}}) \pm \text{random\_jitter}$$
   * Retries are prohibited for actions with `NON_IDEMPOTENT` side effects, for `AMBIGUOUS` verification outcomes, for `NON_FENCEABLE_EXTERNAL`/`NON_FENCEABLE_KERNEL` classes, and for any operation whose `OperationLedger` state is `AMBIGUOUS` (ARCHITECTURE_TOOLS.md §2.3).
   * An automatic retry reuses the attempt's original `intent_token` and increments `attempt_id`, so deduplication still sees one logical operation; only a new human intent mints a new token.
   * Retry attempts are capped per node (default 3) and recorded as `RETRY_ISSUED` with the reason, the assurance level, and the verification predicate result.
