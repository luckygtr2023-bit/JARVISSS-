# CANONICAL DATA ARCHITECTURE SPECIFICATION
Document Identifier: JARVIS-ARCH-003
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CANONICAL ENTITY RELATIONSHIP MODEL
```text
+---------------+ 1:N +---------------+
| User |-------------------| Session |
+---------------+ +---------------+
| 1:N
v
+---------------+ 1:N +---------------+
| Goal |-------------------| Request |
+---------------+ +---------------+
| |
| 1:1 | 1:1
v v
+---------------+ 1:N +---------------+
| Plan |-------------------| Task |
+---------------+ +---------------+
| 1:N | 1:N
v v
+---------------+ 1:N +---------------+
| Plan Node |-------------------| Execution |
+---------------+ +---------------+
| | 1:N
| 1:N v
+---------------+ +---------------+
| OwnershipGrant| | Attempt |
+---------------+ +---------------+
| 1:1
v
+---------------+
| Observation |
+---------------+
| 1:1
v
+---------------+
| Verification |
+---------------+
```


---

## 2. CANONICAL DATA DICTIONARY

### 2.1 Identity & Authority Entities
* `User`: Represents the authenticated human owner. Identity is verified via OS Security Identifier (SID) or Android biometric key.
  * Mutability: Immutable core attributes.
  * Security Implication: Highest authority boundary.
* `Session`: Bounded operational window for user interaction. Contains security credentials, active window state, and context flags.
  * Lifecycle: Created on user presence/login; terminated on logout or timeout.
* `Authorization`: Cryptographically signed approval for an action, issued by `SYS-SEC`. Contains permitted action hashes, expiration timestamp, and risk tier.
* `Confirmation`: User-affirmed assertion answering an `AuthorizationChallenge`. Contains signature, timestamp, and challenge ID.
* `OwnershipGrant`: Authoritative lease linking an `Execution` to a specific `ResourceKey` with a strictly increasing `OwnershipEpoch`.
  * Issued by: `SYS-FCB` only (the `EpochLedger` is its owned state). `SYS-CORE` requests leases; it cannot mint epochs.
  * Invariant: No write side-effect may commit without an active, non-expired `OwnershipGrant` presented to `SYS-FCB`.
* `CommitRecord`: Durable proof that a fenced mutation was applied. Fields: `commit_id`, `resource_key`, `epoch_id`, `lease_id`, `intent_token`, `worker_id`, `state` (`OPEN`|`COMMITTED`|`ABORTED`), `resource_hash_after`, `committed_at_utc`.
  * Invariant: a `CommitRecord` with `state = COMMITTED` is authoritative proof of mutation even if the producing worker died before reporting it.
* `OperationLedgerEntry`: Cross-task, task-independent identity of a semantic operation (see ARCHITECTURE_TOOLS.md §2).
  * Key: `op_id = SHA256(capability_id ∥ version ∥ canonical_parameters ∥ resource_identity_set ∥ side_effect_class ∥ scope_discriminator)`.
  * Fields: `op_id`, `state` (`EXECUTING`|`COMMITTED`|`FAILED_CLEAN`|`AMBIGUOUS`|`ABORTED`), `intent_token`, `intent_instance`, `outcome_digest`, `attribution{task_id,node_id,attempt_id,worker_id,session_id}`, `assurance`, `external_reference`.
  * Invariant: `TaskID` is attribution only and is never part of `op_id`.
* `commit_receipt`: The signed, serialized projection of a `CommitRecord` returned to the caller when a `COMMIT` transaction settles. Fields: `receipt_id`, `commit_id`, `op_id`, `resource_key`, `epoch_id`, `outcome` (`APPLIED`|`ABORTED`|`REJECTED`), `resource_hash_after`, `broker_signature`, `settled_at_utc`.
  * Invariant: a receipt with `outcome = APPLIED` is *evidence of mutation*, never evidence that the goal was achieved — success is established only by the Verification Plane (`ARCHITECTURE_VERIFICATION.md` §3). A receipt is the only artefact a worker may present as proof that its commit landed.
* `ConfirmationChallenge`: A single-use, time-bounded request for human authorization. Fields: `challenge_id`, `challenge_binding` (the SHA-256 digest — echoed by the user's approval — over the canonical binding material: the exact canonical operation, its parameters, resource keys, risk tier, `body_sha256` where applicable, `authorized_scope_hash`, and expiry), `display_payload_hash`, `issuing_channel`, `issued_at`, `expires_at`, `attempt`, `consumed_at`.
  * Invariant: approval is bound to `challenge_binding`; if any bound value changes after approval, the challenge is invalid and a fresh one is required (XD-02). A challenge is never satisfied by the absence of a response, and expired challenges are re-issued rather than re-used.
* `PreApprovalLease`: Time-bounded, revocable, audited user grant that authorizes a named capability set within a named resource scope without a per-action challenge.
  * Fields: `lease_id`, `capability_set[]`, `resource_scope[]`, `max_risk_tier` (never above `RISK_TIER_2`), `issued_at`, `expires_at` (<= 8 h), `max_uses`, `uses_consumed`, `revoked`.
  * Invariant: required for any `RISK_TIER_2` action that proceeds without a synchronous challenge (XD-02). It can never authorize `RISK_TIER_3` or `RISK_TIER_4`.
* `AuthorizedScope`: The immutable tuple a dispatch is bound to: `{capability_set, risk_tier_ceiling, resource_keys[], write_scope[], side_effect_budget, tool_identity, privacy_constraints[], relevant_parameters_hash}`.
  * Invariant: `authorized_scope_hash` is carried on every dispatch and checked by `SYS-FCB`; any material expansion requires a fresh `ConfirmationChallenge` (F-A-10).
* `CredentialSessionLease` / `CredentialActionLease`: Capability tokens held by `SYS-CRED`; see ARCHITECTURE_SECURITY.md §6 and CTR-014. Never contain credential material.
* `TrustClassification`: `SYS-TCR` record: `(capability_id, version, environment_fingerprint) -> assurance_level, evidence_refs[], granted_by, granted_at, expires_at, revocation_reason`. Writable by `SYS-SEC` only.
* `TaintLabel`: see §2.4.

### 2.2 Planning & Execution Entities
* `Goal`: High-level validated intent extracted from natural language input.
* `Plan`: Directed Acyclic Graph (DAG) consisting of discrete `PlanNodes` with explicit causal dependencies and resource declarations.
* `PlanNode`: Atomic execution unit containing:
  * `node_id`: Stable alphanumeric identifier.
  * `dependencies`: List of parent `node_id`s that must complete successfully.
  * `capability`: FQCN of requested tool (e.g., `sys.win.process.start`).
  * `parameters`: Fully canonicalized parameter dictionary.
  * `resource_declarations`: Set of `ResourceKeys` read or mutated.
  * `side_effect_budget`: Maximum permitted external modifications.
* `Execution`: Runtime instance of a `PlanNode` assigned to a worker process.
* `Attempt`: Concrete invocation turn of an `Execution`. Tracks transient retry counters and worker assignments.
* `Observation`: Raw state output collected from the environment following an `Attempt`.
* `VerificationResult`: Output of the Verification Engine assessing whether an `Observation` satisfies the node's required postconditions. Values: `SATISFIED`, `UNSATISFIED`, `INDETERMINATE`.

### 2.3 Memory & Storage Entities
* `MemoryRecord`: Discrete semantic or episodic record.
  * Schema:
    * `memory_id`: UUIDv4.
    * `provenance`: Originating `task_id`, `node_id`, and user ID.
    * `confidence_score`: Float [0.0 - 1.0].
    * `classification`: `PREFERENCE`, `FACT`, `EPISODE`, `PROCEDURAL`.
    * `payload`: Structured JSON text.
    * `embedding_vector`: High-dimensional float vector.
    * `encryption_key_id`: Pointer to DPAPI-wrapped tenant key.
    * `ttl_utc`: Expiration timestamp (or NULL for permanent).
* `AuditEvent`: Cryptographically chained record of a system event.
  * Attributes: `event_id`, `sequence_number`, `prev_hash_sha256`, `timestamp_utc`, `event_type`, `actor`, `task_id`, `payload_hash`, `signature`.
* `Artifact`: Persistent file or binary blob created or modified during execution. Tracked with SHA-256 hash, creation epoch, and workspace path.

---

## 3. PROVENANCE & TAINT ENTITIES

### 3.1 `ProvenanceTaintLabel`

Every value that crosses a trust boundary carries a taint label; the label is **data**, and downstream validation is the control (ARCHITECTURE_AI.md §3).

| Field | Type | Meaning |
| :--- | :--- | :--- |
| `taint_class` | enum | `PROVENANCE_USER_INPUT`, `PROVENANCE_UNTRUSTED_CONTENT`, `PROVENANCE_MODEL_OUTPUT`, `PROVENANCE_TOOL_OUTPUT`, `PROVENANCE_MEMORY_RECORD`, `PROVENANCE_TRUSTED_INTERNAL` |
| `source_ref` | string | URL, file path hash, OCR frame id, capability id, or `memory_id` |
| `acquisition_time_utc` | date-time | when it entered the system |
| `integrity` | enum | `UNVERIFIED`, `INTEGRITY_CHECKED` (hash/signature verified — says nothing about *content* trust) |

Rules:
1. Taint is **contagious and monotone**: any value derived from a tainted value by a model, summarizer, calculator, or memory write inherits at least the strongest taint of its inputs. Taint is never cleared by transformation.
2. It is cleared only by an explicit, auditable `DECLASSIFY` performed by `SYS-SEC` under a rule (e.g. "value matches `^[0-9]{1,4}$` and is inside an integer parameter with a bounded domain").
3. `PROVENANCE_UNTRUSTED_CONTENT` and `PROVENANCE_MODEL_OUTPUT` may never populate an authorization decision, a resource scope, a confirmation-rendered string, or a canonical path/URL/command without full canonicalization plus policy evaluation (ARCHITECTURE_AI.md §3.2).

### 3.2 `AmbiguityResolution`

| Field | Type | Meaning |
| :--- | :--- | :--- |
| `resolution_id` | uuid | |
| `task_id` | uuid | subject task |
| `action` | enum | `INSPECT`, `CONFIRM_COMPLETED`, `CONFIRM_FAILED`, `SAFE_REPLAN`, `ABANDON` |
| `decided_by` | enum | `USER_DESKTOP`, `USER_ANDROID_BIOMETRIC`, `USER_VOICE_AUTHENTICATED` |
| `evidence_ref` | string | observation/verification artefact that motivated the decision (mandatory for `CONFIRM_COMPLETED`) |
| `resulting_state` | enum | `COMPLETED`, `FAILED`, `PLANNED`, `CANCELLED` |
| `decided_at_utc` | date-time | |
| `audit_event_id` | uuid | |

Invariant: no task leaves `AMBIGUOUS_HALTED` without an `AmbiguityResolution` record; the state is a decision point, never a sink (F-A-11).
