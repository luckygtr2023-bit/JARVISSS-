# SECURITY ARCHITECTURE & TRUST FRAMEWORK
Document Identifier: JARVIS-ARCH-006
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. RISK CLASSIFICATION FRAMEWORK

Every capability and operation within JARVIS is bound to a strict, immutable risk tier. AI-generated risk suggestions are non-authoritative; classification is strictly determined by the deterministic Policy Engine based on the canonical capability signature and parameter scope.

### 1.1 Canonical Execution-Risk Tier Hierarchy (`RISK_TIER_0` … `RISK_TIER_4`)

This is the **only** namespace for execution risk in the architecture. Privacy/egress classification uses `PRIVACY_CLASS_*`; abortability, assurance, JavaScript modes, configuration levels, simulation fidelity, and memory tiers each have their own namespace (§5.6).
```text
+--------------------------------------------------------------------------+
| RISK_TIER_4: CRITICAL SYSTEM OPERATIONS |
| OS format, registry deletion, firmware, credential export, user elevation |
| Policy: STRICT MULTI-FACTOR + OUT-OF-BAND (OOB) HARDWARE CONFIRMATION |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| RISK_TIER_3: HIGH-RISK SIDE EFFECTS |
| External email send, financial transactions, permanent file deletion |
| Policy: EXPLICIT SYNCHRONOUS HUMAN CONFIRMATION (Desktop/Android HUD) |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| RISK_TIER_2: MEDIUM-RISK SIDE EFFECTS |
| Reversible local file modifications, application launching, settings edit|
| Policy: SYNCHRONOUS CONFIRMATION, or a valid PreApprovalLease (§2.2) |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| RISK_TIER_1: LOW-RISK SIDE EFFECTS |
| Clipboard write, temp file generation, window focus/minimize |
| Policy: AUTOMATIC EXECUTION UNDER POLICY AUDIT |
+--------------------------------------------------------------------------+
^
|
+--------------------------------------------------------------------------+
| RISK_TIER_0: READ-ONLY OBSERVATIONS |
| Screen OCR capture, file read, active window query, memory query |
| Policy: UNRESTRICTED CORE INVOCATION (Bounded by Privacy Filters) |
+--------------------------------------------------------------------------+
```


---

## 2. POLICY EVALUATION & ENFORCEMENT ENGINE

The Policy Engine operates as an authoritative, out-of-process Policy Decision Point (PDP). It evaluates incoming candidate actions against three criteria:
1. Static System Policies: Sealed declarative JSON policies defining absolute boundaries (e.g., "Deny modification of `C:\Windows\*` under all conditions").
2. Dynamic Environmental State: Presence of active interactive desktop, screen lock status, user physical idle time.
3. Historical Blast Radius: Rate of operations within the current session (e.g., maximum 10 file deletions per minute).

### 2.1 Confirmation Challenge Enforcement
For `RISK_TIER_2`, `RISK_TIER_3`, and `RISK_TIER_4` actions, the Policy Engine generates a cryptographically unique `ConfirmationChallenge`:
* Challenge Payload: Canonical action description, target resource path, side-effect delta preview, expiration timestamp (default: 60s).
* Cryptographic Binding: Signed with Core ephemeral HMAC key.
* Verification: The user's approval response must echo the challenge's `challenge_binding` — a hash over the exact canonical operation, its parameters, resource keys, risk tier, and `authorized_scope_hash` (ARCHITECTURE_DATA_MODEL.md §2.2). Any modification of target parameters changes the binding and invalidates the challenge.
* Decision vocabulary: `ALLOW` | `DENY` | `CONFIRM_REQUIRED` (canonical; see CTR-003).

### 2.2 PreApprovalLease — the only path to silent `RISK_TIER_2` (resolves XD-02)

The architecture previously said `RISK_TIER_2` was governed by "synchronous confirmation **OR** session pre-approval lease", while the task state machine required a confirmation challenge for every tier >= 2. Both statements could not be true. The resolution is explicit:

1. **Default:** every `RISK_TIER_2` action requires synchronous confirmation. The state machine transition `POLICY_CHALLENGE -> AWAITING_CONFIRMATION` applies.
2. **Exception:** a `RISK_TIER_2` action proceeds without a per-action challenge **if and only if** a valid `PreApprovalLease` (ARCHITECTURE_DATA_MODEL.md §2.1) covers it, i.e. all of:
   * the lease names the capability (id + version) and the action's `ResourceKey`s fall inside its `resource_scope`;
   * the lease's `max_risk_tier >= RISK_TIER_2` (a lease can never be issued above `RISK_TIER_2`);
   * the lease is unexpired (absolute TTL <= 8 h), `uses_consumed < max_uses`, and not revoked;
   * the action's parameters fall within the enumerated domain recorded when the lease was issued.
3. **Lease issuance is itself a confirmed act.** The user mints a lease through a `RISK_TIER_3`-equivalent confirmation that displays the capability set, the resource scope, the TTL, and the use count. Leases are visible in a persistent UI list and revocable at any time.
4. **No silent widening.** A lease is never extended, widened, or renewed automatically. Reaching `max_uses` or TTL returns the system to per-action confirmation.
5. **`RISK_TIER_3` and `RISK_TIER_4` are never eligible.** No lease, session flag, "trusted mode", or repeated-use heuristic can bypass their confirmation.
6. **Audit:** `PREAPPROVAL_LEASE_ISSUED`, `PREAPPROVAL_LEASE_USED`, `PREAPPROVAL_LEASE_EXPIRED`, `PREAPPROVAL_LEASE_REVOKED` with the action's `op_id` recorded on each use.

---

## 3. SECRET MANAGEMENT & ISOLATION

1. Storage: Secrets (API keys, OAuth tokens, browser cookies) are stored in the Windows Credential Manager or an encrypted SQLite database using Windows DPAPI (`CryptProtectData`) tied strictly to the local machine and running user.
2. Memory Defense: In-memory secrets are held within non-pageable memory blocks using `VirtualLock`. Cleartext secrets are overwritten with zero bytes (`SecureZeroMemory`) immediately after use.
3. Log & Prompt Redaction: Secret strings are automatically scrubbed from all outbound AI prompts, debug logs, and audit records via a high-performance Aho-Corasick matching filter loaded with all active credential hashes.
4. Process Isolation: Execution workers never receive long-lived master credentials; they receive ephemeral, single-use access tokens scoped strictly to their explicit operation.

---

## 4. LOCAL WINDOWS THREAT MODEL & TRUST BOUNDARY LIMITATIONS

This section exists because the architecture previously implied *"same user = trusted"*. That assumption is **false** and is not relied upon anywhere.

### 4.1 Adversary classes on a single-user Windows host

| Adversary | Capability | In scope? |
| :--- | :--- | :--- |
| `ADV-REMOTE-CONTENT` | Untrusted web pages, documents, OCR text, model output | Yes — primary adversary |
| `ADV-LOW-INTEGRITY` | Code running in a JARVIS sandbox that achieves RCE (renderer, plugin, parser) | Yes |
| `ADV-SAME-USER` | Any process running as the same user at Medium Integrity | Yes |
| `ADV-SAME-USER-DEBUG` | Same user with `SeDebugPrivilege` or an equivalent debugger | Yes, with **explicit limitations** (§4.3) |
| `ADV-ADMIN` | Local administrator / kernel | **Out of scope** — no user-mode architecture can defend against it |
| `ADV-PHYSICAL` | Physical access, DMA, cold boot | **Out of scope** |

### 4.2 Threats addressed

1. **Same-user IPC impersonation** — addressed by: per-session pipe names with `FILE_FLAG_FIRST_PIPE_INSTANCE`, explicit DACLs (no `Everyone`), client PID verification via `GetNamedPipeClientProcessId`, binary path + Authenticode verification of the client, Windows Integrity Level check, and a per-call capability token minted at spawn (§4.4). A rogue same-user client that fails any check is disconnected and a `SECURITY_ANOMALY_IPC_PEER` audit event is emitted.
2. **Process injection into Core/FCB/CRED** — addressed by process mitigation policies: `MicrosoftSignedOnly` binary signature policy, Arbitrary Code Guard (no dynamic code), CFG, no W+X, `DisableExtensionPoints`, and no `LOAD_LIBRARY` of user-writable paths (DLL search hardened via `SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_SYSTEM32)`). Residual: a debug-privileged same-user process can still inject.
3. **Credential theft from Core memory** — addressed structurally: **long-lived secrets are not held in the Core process at all**. They live in the Credential Broker (`SYS-CRED`, §6). Core holds only short-lived, single-use handles.
4. **Debugging / memory scraping of Core** — **not preventable** by a user-mode process of the same user (see §4.3).
5. **Worker authentication** — each worker receives a per-spawn Ed25519 keypair generated inside the worker process after spawn; the public half is delivered to `SYS-FCB`/Core over the inherited handle channel (§4.4). IPC frames are signed by that key. A worker cannot impersonate another worker, and a replayed frame from a prior worker incarnation fails signature or sequence checks.

### 4.3 Explicit security boundary limitations (documented, not hidden)

1. **Same-user + debug privilege is a trust boundary break for process memory.** A same-user attacker with `SeDebugPrivilege`, an attached debugger, or kernel-adjacent tooling can read or modify JARVIS process memory, including Core. The architecture mitigates the *consequence* rather than the *capability*:
   * Core memory contains no long-lived secrets and no signing keys.
   * All authority-bearing keys live in `SYS-CRED` (DPAPI/TPM-bound) and `SYS-AUD` (anchor key, TPM-resident, §ARCHITECTURE_AUDIT.md).
   * Authorization is bound to cryptographic tokens minted by `SYS-SEC` and verified by `SYS-FCB`, so patching Core's decision logic yields a token that still fails signature verification at the enforcement point.
   * **Residual risk is accepted and recorded.** An attacker at this level can deny service, alter in-flight decisions, and observe local data. The architecture does not claim to stop them; it claims that such an attacker cannot forge an authorization token, cannot make a stale commit land, and cannot silently rewrite the audit ledger.
2. **JARVIS runs at Medium Integrity and cannot use Protected Process Light** (PPL requires Microsoft signing). This is a deliberate, stated limitation rather than an implied guarantee.
3. **Core is not a secret store and must never become one.** Any future change that places a long-lived secret in the Core process invalidates this section.

### 4.4 Worker spawn credential channel (resolves the bootstrap-channel ambiguity)

* The handshake token is delivered over an **inherited anonymous pipe handle** using `STARTUPINFOEXW` + `PROC_THREAD_ATTRIBUTE_HANDLE_LIST`, *never* via command line, environment variables, or a command-line-visible handle value.
* The token is single-use, 30-second TTL, bound to `(child_pid, child_creation_time, worker_keypair_pubkey)`.
* On first use the channel is destroyed; subsequent authorization uses the worker's Ed25519 signature.

---

## 5. SAFETY ASSURANCE & TRUST CLASSIFICATION

### 5.1 Why this exists

A capability manifest is authored by a third party. Previously the manifest's `idempotency_class`, `simulatable`, and abortability declarations were consumed directly by the Execution Controller — i.e. **an untrusted author could grant itself safety authority**. That is now prohibited.

### 5.2 The rule

> **No retry, no simulation-based shortcut, and no abortability shortcut may be granted on the basis of a `DECLARED` value.**

### 5.3 Assurance levels

The level is stored as the `assurance_level` field of the `TrustClassification` record (ARCHITECTURE_DATA_MODEL.md §2.2) and is readable through `CTR-015`. It is *never* a manifest field: a manifest can only ever produce the lowest level.

| Level | Assigned by | Evidence required | Permits |
| :--- | :--- | :--- | :--- |
| `ASSURANCE_DECLARED` | Capability author (manifest field) | None. Signature proves *authorship*, not *truth* | Display, planning hints, `RISK_TIER_0` reads only. **Never** permits retry, simulation-based authorization relaxation, or abortability claims |
| `ASSURANCE_REVIEWED` | Human security reviewer (`TEAM-SEC`), recorded in the Trust Classification Registry | Source review, parameter surface review, adversarial test plan | Simulation eligibility; read-only capability admission to production |
| `ASSURANCE_ARCHITECTURALLY_VERIFIED` | `SYS-SEC` only, from a structural proof | The operation's commit path is provably `FENCEABLE_BROKERED`, or provably `FENCEABLE_GATED`, verified by the fencing conformance suite | Retry eligibility for idempotent classes; abortability claims; admission to any `RISK_TIER >= 2` capability set |
| `ASSURANCE_RUNTIME_CONFIRMED` | `SYS-SEC` only, from empirical evidence | `ASSURANCE_ARCHITECTURALLY_VERIFIED` **plus** per-version, per-environment runtime evidence: fault-injection results, observed idempotency over N executions in the staging environment | Automatic retry; circuit-breaker half-open probing |

### 5.4 Trust Classification Registry (`SYS-TCR`)

`SYS-TCR` is a record set owned by `SYS-SEC` (not a separate process; it is state inside the Security Kernel) holding, per `(capability_id, capability_version, environment_fingerprint)`: assurance level, evidence references, granting authority, grant timestamp, expiry, and revocation history.

* **Manifest authenticity:** the manifest signature chain is verified against the developer certificate; the manifest is treated as a *claim*, and its claims enter `SYS-TCR` only at `ASSURANCE_DECLARED` until evidence promotes them.
* **Downgrade / revocation:** assurance drops to `ASSURANCE_DECLARED` automatically on: capability version change, manifest signature change, environment fingerprint change (OS build, sandbox policy), any fencing-rejection event attributable to the capability, or expiry. A drop to `ASSURANCE_DECLARED` immediately disables retry and simulation shortcuts and re-evaluates in-flight permission.
* **Authority:** only `SYS-SEC` writes `SYS-TCR`. `SYS-EXEC`, `SYS-PLAN`, `SYS-AI`, `SYS-TOOL`, plugins, the UI, and memory have **no** write path. This is a hard authority rule.

### 5.5 How the levels gate behaviour

| Decision | Minimum assurance |
| :--- | :--- |
| Automatic retry (`ARCHITECTURE_RELIABILITY.md` §2) | `ASSURANCE_RUNTIME_CONFIRMED` |
| Half-open canary probe | `ASSURANCE_RUNTIME_CONFIRMED` |
| Treat simulation result as an authorization relaxation input | `ASSURANCE_REVIEWED` (never for `RISK_TIER >= 3`) |
| Abortability claim (`ABORTABILITY_CLASS_ARCHITECTURALLY_VERIFIED`) | `ASSURANCE_ARCHITECTURALLY_VERIFIED` |
| Admission to `RISK_TIER_3`/`RISK_TIER_4` capability sets | `ASSURANCE_ARCHITECTURALLY_VERIFIED` |
| Deduplication reuse of a stored result | `ASSURANCE_ARCHITECTURALLY_VERIFIED` |

### 5.6 Canonical namespace separation (no identifier reuse)

| Concept | Namespace | Values |
| :--- | :--- | :--- |
| Execution risk | `RISK_TIER_*` | `RISK_TIER_0` … `RISK_TIER_4` |
| Egress / privacy class of data sent to a model | `PRIVACY_CLASS_*` | `PRIVACY_CLASS_0_NO_EGRESS`, `PRIVACY_CLASS_1_REDACTED_EGRESS`, `PRIVACY_CLASS_2_ENCRYPTED_EGRESS` |
| Abortability of an operation | `ABORTABILITY_CLASS_*` | see ARCHITECTURE_EXECUTION.md §3 |
| Safety evidence level | `ASSURANCE_*` | see §5.3 |
| Browser script execution | `JS_MODE_*` | see ARCHITECTURE_BROWSER.md §2 |
| Simulation fidelity | `SIMULATION_FIDELITY_*` | `LOW`, `MEDIUM`, `HIGH` |
| Configuration precedence | `CONFIG_LEVEL_*` | `CONFIG_LEVEL_1` … `CONFIG_LEVEL_5` |
| Memory tier | `MEMORY_TIER_*` | `WORKING`, `EPISODIC`, `SEMANTIC`, `PROCEDURAL` |

**Invariant:** no identifier from one namespace may be used to mean a concept from another. In particular `RISK_TIER_*` is the **only** namespace for execution risk, and privacy/egress classification is expressed exclusively with `PRIVACY_CLASS_*`.

---

## 6. CREDENTIAL BROKER (`SYS-CRED`) & AUTHENTICATED AUTOMATION

### 6.1 The problem being fixed

The architecture previously allowed a **Low-Integrity browser daemon** to hold **live authenticated session cookies**. A renderer RCE would then be a direct credential-theft primitive, and "human visual supervision" was implicitly treated as the control. That model is withdrawn.

### 6.2 The model

> **Trusted credentials are never exposed to an untrusted process.** The browser daemon never receives, reads, or transmits raw cookie material, and never originates an authenticated state-changing request.

| Property | Specification |
| :--- | :--- |
| Component | `SYS-CRED` — Credential Broker, own Medium-Integrity process, `MicrosoftSignedOnly` mitigation, TPM/DPAPI-bound store |
| Credential access | Only `SYS-CRED` and `SYS-SEC` may read the secret store. `SYS-BROWSER`, workers, plugins, the UI, and the AI plane have **no** access path |
| Cookie handling | Cookies live inside the broker-owned profile store and are applied by `SYS-CRED` at request time. `Network.getCookies`, `Network.getAllCookies`, and `Storage.getCookies` CDP methods are **denied** on the broker's own CDP policy layer; the browser daemon runs with a CDP command allowlist that excludes them |
| Session lease | The daemon receives `SessionLease(lease_id, domain_scope[], methods[], expiry, cdp_session_id)` — a capability, not a credential. Idle timeout 15 minutes; absolute lifetime 8 hours; single-domain scoping by default |
| Authenticated automation boundary | Read-only authenticated navigation/extraction is performed by the daemon *inside* the leased session (cookies are never in its address space because the browser process itself applies them). Any state-changing request (`POST`/`PUT`/`PATCH`/`DELETE`, form submission, purchase, message send) is executed by `SYS-CRED`'s **Authenticated Request Proxy**, not by the renderer |
| State-changing request rule | Requires `RISK_TIER_3` (external commit), a fresh `ConfirmationChallenge` bound to `(method, canonical_url, body_sha256, session_lease_id)`, and an `ActionLease` minted by `SYS-SEC`. Classified `NON_FENCEABLE_EXTERNAL` |
| Browser RCE assumption | The daemon is assumed compromisable. A compromised daemon can read the current page, drive the leased session within `domain_scope`, and attempt requests — but cannot mint an `ActionLease`, cannot read cookies, cannot reach another profile, and cannot reach the network outside the egress allowlist |
| Human visual supervision | Retained as a **detection aid and a user-visible control**, explicitly **not** an enforcement mechanism. No security property depends on a human watching the screen |
| Revocation | User action, policy verdict, lease expiry, or anomaly detection revokes the lease immediately; `SYS-CRED` rotates the affected session material and emits `CREDENTIAL_SESSION_REVOKED` |
| Audit events | `CREDENTIAL_LEASE_ISSUED`, `CREDENTIAL_LEASE_USED`, `CREDENTIAL_ACTION_LEASE_MINTED`, `CREDENTIAL_SESSION_REVOKED`, `CREDENTIAL_ACCESS_DENIED` |

### 6.3 Credential lifetime summary

| Item | Lifetime | Scope |
| :--- | :--- | :--- |
| `SessionLease` | <= 8 h absolute, 15 min idle | One or more explicitly listed domains |
| `ActionLease` | Single request, <= 60 s | One exact request (method + URL + body hash) |
| Ephemeral worker token | Single operation | One capability invocation |
| Long-lived OAuth/API secret | Until revoked | Broker-only; never leaves `SYS-CRED` |

---

## 7. TIER TERMINOLOGY MIGRATION (F-A-04, XD-04)

The word "tier" previously carried at least eight unrelated meanings. This section records the migration so that no stale usage survives anywhere in the 36-document set.

| Old (ambiguous) usage | Canonical replacement | Defining document |
| :--- | :--- | :--- |
| "Tier 0 … Tier 4" / `TIER_2_MEDIUM_REVERSIBLE` (execution risk) | `RISK_TIER_0` … `RISK_TIER_4` | this document, §1.1 |
| "privacy tier", "Privacy 0" (model routing / egress) | `PRIVACY_CLASS_0_NO_EGRESS`, `PRIVACY_CLASS_1_REDACTED_EGRESS`, `PRIVACY_CLASS_2_ENCRYPTED_EGRESS` | ARCHITECTURE_AI.md §1.1 |
| "four tiers of action abortability" | `ABORTABILITY_CLASS_*` | ARCHITECTURE_EXECUTION.md §3 |
| "three operational tiers" (browser script modes) | `JS_MODE_READ_ONLY`, `JS_MODE_CONTROLLED_DOM`, `JS_MODE_FULL_INTERACTIVE` | ARCHITECTURE_BROWSER.md §2 |
| "five-tier precedence hierarchy" (configuration) | `CONFIG_LEVEL_1` … `CONFIG_LEVEL_5` | ARCHITECTURE_CONFIGURATION.md §4 |
| "four distinct operational tiers" (memory) | `MEMORY_TIER_WORKING`, `MEMORY_TIER_EPISODIC`, `MEMORY_TIER_SEMANTIC`, `MEMORY_TIER_PROCEDURAL` | ARCHITECTURE_MEMORY.md §1 |
| "three-tier simulation capability" | `SIMULATION_FIDELITY_LOW/MEDIUM/HIGH` plus the simulation classes `FULLY_SIMULATABLE`, `PARTIALLY_SIMULATABLE`, `NOT_SIMULATABLE` | ARCHITECTURE_SIMULATION.md §1 |
| "Tier 1/2/3" in assurance contexts | `ASSURANCE_DECLARED`, `ASSURANCE_REVIEWED`, `ASSURANCE_ARCHITECTURALLY_VERIFIED`, `ASSURANCE_RUNTIME_CONFIRMED` | this document, §5.3 |

**Invariant:** where a sentence refers to execution risk it uses `RISK_TIER_*`; where it refers to anything else it uses that concept's own namespace. `RISK_TIER_*` is the only namespace that may appear in an authorization decision, a confirmation prompt, a policy rule, or a capability admission check.

### 7.1 Cross-document contradiction resolutions (XD series)

| ID | Contradiction | Resolution |
| :--- | :--- | :--- |
| `XD-01` | The policy decision enum was `AuthorizationDecision = ALLOW / DENY / CONFIRM_REQUIRED` in the Components document but `CONFIRMATION_REQUIRED` in the Contracts document | Canonical vocabulary fixed to `ALLOW` / `DENY` / `CONFIRM_REQUIRED`; the CTR-003 payload updated |
| `XD-02` | The Security document allowed "synchronous confirmation **or** session pre-approval lease" for `RISK_TIER_2`, while the state machine required a challenge for every risk tier >= 2 | `PreApprovalLease` defined explicitly (eligibility, TTL, use count, revocation) and the `POLICY_PREAPPROVED` transition added (§2.2; ARCHITECTURE_STATE_MODEL.md §1.1) |
| `XD-03` | Audit ledger read access was "all components (append-only)" in Components §2.11 but "Root/Admin" in Data Storage §1 | Append-only endpoint for all components; read restricted to `SYS-SEC` and the User Console through a separate DACL'd read endpoint (CTR-016 invariant 3) |
| `XD-04` | "Tier" used for unrelated concepts across at least six documents | Namespace migration table, §7 |
| `XD-05` | IPC frame ceiling: 4 GB implied by the 4-byte length field, ">16 MB terminates" in the IPC document, 32 KB in the request schema | `MAX_FRAME_SIZE = 4 MiB` defined once (ARCHITECTURE_CONTRACTS.md §1.2); bulk streams moved to a separate chunked channel |
| `XD-06` | The reliability policy retried `STRICTLY_IDEMPOTENT` capabilities on the strength of a manifest declaration, and `CONDITIONALLY_IDEMPOTENT` was referenced but never defined | Retry gated on `SYS-TCR` `retry_eligible` (`ASSURANCE_RUNTIME_CONFIRMED`); `CONDITIONALLY_IDEMPOTENT` defined by an observable precondition predicate evaluated immediately before retry |
| `XD-07` | "Privacy tier" (model routing) was not separated from execution risk tiers, so a routing decision could be read as an authorization tier | `PRIVACY_CLASS_*` created; the AI routing matrix and diagram updated; §5.6 forbids reuse |

### 7.2 Authority consolidation

| Question | Single authoritative answer |
| :--- | :--- |
| Who may commit a fenced side effect? | `SYS-FCB` (ARCHITECTURE_EXECUTION.md §2.0) |
| Who owns `OwnershipEpoch`? | `SYS-FCB`, durable in `fencing.db` |
| Who classifies execution risk? | `SYS-SEC`, deterministically, from capability signature + canonical parameters |
| Who grants safety assurance? | `SYS-SEC` writing `SYS-TCR` |
| Who holds credentials? | `SYS-CRED`, with no credential-returning API |
| Who may read the audit ledger? | `SYS-SEC` and the User Console only |
| Who may resolve an ambiguous task? | An authenticated human, through one of the five defined actions |
| Who may expand an authorization scope? | `SYS-SEC`, only after a fresh confirmed challenge |
| Who may retry automatically? | `SYS-EXEC`, only for operations `SYS-TCR` marks `retry_eligible` |
| Who may declare a worker dead? | `SYS-CORE` (watchdog + job-object events), never the worker itself |
