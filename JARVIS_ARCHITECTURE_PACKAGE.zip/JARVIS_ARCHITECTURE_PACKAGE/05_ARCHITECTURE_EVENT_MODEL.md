# EVENT ARCHITECTURE & CAUSALITY SPECIFICATION
Document Identifier: JARVIS-ARCH-004
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. EVENT ORDERING & CAUSALITY

JARVIS enforces deterministic causality across distributed processes and asynchronous operations. Physical wall-clock time is insufficient for concurrency management due to clock drift and thread interleaving; therefore, the system employs hybrid logical clocks (HLC) and per-task vector clocks.

### 1.1 Causality Vector Representation
Every event encapsulates:
1. `wall_clock_utc`: ISO 8601 UTC timestamp (microsecond precision).
2. `monotonic_counter`: Hardware monotonic timer (`QueryPerformanceCounter`).
3. `task_sequence_number`: Monotonically increasing unsigned 64-bit integer scoped to the `task_id`.
4. `causal_parent_event_id`: UUID of the direct causal predecessor.
```text
Core Dispatch (Seq: 1)
|
+-----> Worker Spawn (Seq: 2, Parent: 1)
| |
| v
| Tool Invocation (Seq: 3, Parent: 2)
| |
+<-------------+
| (Result Returned)
v
Verification (Seq: 4, Parent: 3)
```


---

## 2. EVENT TAXONOMY & SCHEMAS

Events are partitioned into three distinct topological scopes:
* Global System Events: Core lifecycle, security lockdowns, worker process terminations.
* Task Events: DAG state mutations, user confirmation requests, task replanning triggers.
* Node/Execution Events: Tool dispatch, environmental observations, fencing revocations.

### 2.1 Canonical Event Envelope
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SystemEventEnvelope",
  "type": "object",
  "properties": {
    "event_id": { "type": "string", "format": "uuid" },
    "event_type": { "type": "string" },
    "task_id": { "type": ["string", "null"], "format": "uuid" },
    "node_id": { "type": ["string", "null"] },
    "execution_id": { "type": ["string", "null"], "format": "uuid" },
    "sequence": { "type": "integer", "minimum": 0 },
    "hlc_timestamp": {
      "type": "object",
      "properties": {
        "physical_utc": { "type": "string", "format": "date-time" },
        "logical_counter": { "type": "integer" }
      },
      "required": ["physical_utc", "logical_counter"]
    },
    "causal_parent_id": { "type": ["string", "null"], "format": "uuid" },
    "payload": { "type": "object" },
    "signature": { "type": "string" }
  },
  "required": ["event_id", "event_type", "sequence", "hlc_timestamp", "payload"]
}
```
### 2.2 Canonical Event Type Registry (additions, version 1.0.0-LOCK-CANDIDATE)

| Category | Event types |
| :--- | :--- |
| Fencing / commit (`SYS-FCB`) | `LEASE_ISSUED`, `LEASE_REVOKED`, `EPOCH_INCREMENTED`, `FENCED_COMMIT_APPLIED`, `FENCE_REJECTION`, `COMMIT_ABORTED`, `SCOPE_MISMATCH`, `STAGING_PURGED`, `SCHEDULED_COMMIT_CANCELLED`, `INDETERMINATE_COMMIT_REPORTED` |
| Credentials (`SYS-CRED`) | `CREDENTIAL_LEASE_ISSUED`, `CREDENTIAL_LEASE_USED`, `CREDENTIAL_ACTION_LEASE_MINTED`, `CREDENTIAL_ACCESS_DENIED`, `CREDENTIAL_SESSION_REVOKED` |
| Authorization / confirmation | `POLICY_DECISION`, `CHALLENGE_ISSUED`, `CHALLENGE_ECHOED`, `CHALLENGE_CONSUMED`, `CHALLENGE_EXPIRED`, `CHALLENGE_WITHDRAWN`, `CHALLENGE_REPLAY_REJECTED`, `PREAPPROVAL_LEASE_ISSUED`, `PREAPPROVAL_LEASE_USED`, `PREAPPROVAL_LEASE_EXPIRED`, `PREAPPROVAL_LEASE_REVOKED` |
| Assurance (`SYS-TCR`) | `ASSURANCE_ASSIGNED`, `ASSURANCE_PROMOTED`, `ASSURANCE_DOWNGRADED`, `ASSURANCE_EXPIRED`, `ASSURANCE_REVOCATION_REJECTED` |
| Operations / deduplication | `INTENT_REPEAT`, `MANUAL_REISSUE`, `EXTERNAL_COMMIT_ATTEMPTED`, `RETRY_ISSUED`, `OP_ID_REUSED`, `OP_ID_AMBIGUOUS_BLOCKED` |
| Ambiguity resolution | `AMBIGUITY_ENTERED`, `AMBIGUITY_INSPECTED`, `AMBIGUITY_RESOLVED_COMPLETED`, `AMBIGUITY_RESOLVED_FAILED`, `AMBIGUITY_SAFE_REPLAN`, `AMBIGUITY_ABANDONED`, `RECOVERY_SUMMARY` |
| Replanning | `REPLAN_APPLIED`, `REPLAN_REAUTHORIZED`, `REPLAN_PARAMETER_DRIFT`, `SCOPE_EXPANSION_REQUESTED` |
| Security anomalies | `SECURITY_ANOMALY_IPC_PEER`, `SECURITY_ANOMALY_OVERSIZE_FRAME`, `SECURITY_ANOMALY_BOOTSTRAP_REPLAY`, `SECURITY_ANOMALY_INJECTION_ATTEMPT`, `SECURITY_ANOMALY_INAUDIBLE_CARRIER`, `SECURITY_ANOMALY_ANDROID_BINDING_MISMATCH`, `SECURITY_ANOMALY_CLOCK_DRIFT`, `SECURITY_ANOMALY_TAINT_IN_AUTHORITY_FIELD` |
| Audit / integrity | `SAFE_LOCKDOWN_ENTERED`, `SAFE_LOCKDOWN_CLEARED`, `AUDIT_ANCHOR_SIGNED`, `AUDIT_ANCHOR_VERIFIED`, `AUDIT_ROLLBACK_DETECTED`, `AUDIT_KEY_ROTATED`, `AUDIT_DEGRADED_ENTERED`, `CONFIG_SIGNATURE_REJECTED`, `POLICY_DOWNGRADE_REJECTED` |
| Voice | `VOICE_CANCEL_REQUESTED`, `VOICE_CANCEL_SUSPENDED`, `CANCELLATION_AFTER_COMMIT`, `ANALYSIS_AUDIO_MUTED` |
| Lifecycle | `WORKER_RECLAIMED`, `WORKER_RECLAIM_FAILED`, `WORKER_TERMINATION_FORCED`, `SIMULATION_OVERLAY_DESTROYED`, `BROWSER_NAVIGATION_BLOCKED`, `BROWSER_STATE_CHANGE_CONFIRMED`, `CLIPBOARD_READ`, `CLIPBOARD_CLEARED` |

Every event in this registry is emitted with `durability: SYNCHRONOUS` when it bears on a `RISK_TIER >= 2` decision, a commit, an authorization, a revocation, or an ambiguity transition (CTR-016 invariant 2).

#### Clock Trust

Wall-clock time is not trusted. `hlc_timestamp.physical_utc` derives from the OS clock but is **never** used alone for ordering or expiry:

* ordering uses `monotonic_counter` within a process and `(sequence, hlc.logical_counter)` across processes;
* lease, challenge, and token expiry use monotonic elapsed time; the absolute deadline is cross-checked against the HLC only for user display;
* if the OS clock moves backwards by more than 120 s, or disagrees with the HLC physical component by more than 120 s, the system emits `SECURITY_ANOMALY_CLOCK_DRIFT`, refuses to shorten any expiry, and requires re-issuance of challenges rather than accepting a time-based argument.

3. PERSISTENCE & REPLAY PROTECTION

Append-Only Persistence: All events are flushed to an append-only SQLite WAL table prior to processing by downstream subscribers.
In-Memory Ring Buffer: The last 10,000 events are retained in non-pageable memory for real-time causality resolution and UI telemetry.
Replay Defense: The Core maintains an in-memory hash table of observed event nonces for the preceding 10-minute window. Incoming IPC messages with duplicate nonces or regressive sequence numbers are dropped and flagged as security anomalies.
