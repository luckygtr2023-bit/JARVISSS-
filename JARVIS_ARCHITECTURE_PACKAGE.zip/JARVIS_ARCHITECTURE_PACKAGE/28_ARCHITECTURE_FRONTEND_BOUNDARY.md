# PRESENTATION LAYER & FRONTEND BOUNDARY
Document Identifier: JARVIS-ARCH-027
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. DECOUPLING PRINCIPLE & UNTRUSTED UI

The Presentation Layer (Desktop WinUI overlay, HUD, System Tray, Web View) is classified as an untrusted client. The frontend has zero execution authority and cannot perform actions directly.
```text
+--------------------------------------------------------------------------+
| Presentation Layer (Untrusted Frontend) |
| - Captures user text/voice input. |
| - Displays state telemetry, DAG visualizations, and chat messages. |
| - Renders confirmation request modals. |
+--------------------------------------------------------------------------+
|
| IPC via Local Named Pipe
v
+--------------------------------------------------------------------------+
| Core Authority Boundary (Trusted Core) |
| - Validates authenticity of all incoming UI events. |
| - Independently enforces authorization and confirmation logic. |
+--------------------------------------------------------------------------+
```


---

## 2. ANTI-CLICKJACKING & SECURE CONFIRMATION MODALS

To prevent malicious software from spoofing user confirmations via UI redress or clickjacking:
1. High-Risk Modals: Confirmation dialogs for `RISK_TIER_3` and `RISK_TIER_4` operations are drawn directly by a privileged Core helper window using topmost, hardware-accelerated Win32 overlays with secure window styles (`WS_EX_TOPMOST | WS_EX_LAYERED`).
2. Interaction Randomization: High-risk confirmation buttons randomize their screen coordinate placement slightly or require an explicit slider drag/hold interaction to prevent automated mouse event injection (`mouse_event` spoofing).
3. Foreground Verification: The Core verifies via Win32 `GetForegroundWindow` that the confirmation dialog has active user focus at the exact millisecond of click input. The modal additionally uses `SetForegroundWindow` and a scoped `SetCapture`/`BlockInput` for its lifetime.
4. Canonical-Action Rendering (F-A-06): the modal renders the **canonical action object** — resolved absolute path, canonical URL, exact request body digest, exact parameters — never model-generated prose. The user approves the bound `challenge_binding` hash, not a sentence.
5. Untrusted ACK handling (F-A-21): the frontend verifies `core_signature` and `response_nonce` on every `SubmitResponse` and refuses to display a task as accepted when verification fails (`UNTRUSTED_ACK`).
6. The frontend remains an untrusted client: it may not assert a risk tier, an assurance level, a scope, or an identity that `SYS-CORE` cannot verify against the IPC peer.
