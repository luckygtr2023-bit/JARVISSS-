# OBSERVATION & VERIFICATION SUBSYSTEM
Document Identifier: JARVIS-ARCH-021
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. THE VERIFICATION TRIAD

Execution, Observation, and Verification are decoupled into distinct lifecycle phases:
```text
+--------------------------------------------------------------------------+
| 1. EXECUTION PHASE (SYS-EXEC) |
| Worker issues command to application / operating system. |
| Receives return code / API ACK. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 2. OBSERVATION PHASE (SYS-PERCEPTION) |
| Passive environmental sensors independently poll resulting state. |
| - Filesystem: Query path existence, size, SHA-256 hash. |
| - UI: Query UIA accessibility tree, capture screen OCR. |
| - Process: Query Win32 process list, listening network sockets. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 3. VERIFICATION PHASE (SYS-VERIFY) |
| Evaluates observed state against node postcondition assertions. |
| Emits authoritative verdict: SATISFIED, UNSATISFIED, or INDETERMINATE. |
+--------------------------------------------------------------------------+
```


---

## 2. POSTCONDITION ASSERTION SCHEMAS

Every plan node embeds an explicit postcondition contract:
```json
{
  "postconditions": [
    {
      "sensor": "filesystem.exists",
      "target": "C:\\Data\\Output.csv",
      "expected": true
    },
    {
      "sensor": "filesystem.min_size",
      "target": "C:\\Data\\Output.csv",
      "expected_bytes": 1024
    }
  ]
}
```
Invariant: If verification yields `INDETERMINATE` (e.g. target file is locked, UI fails to render within timeout, remote provider unreachable), the task cannot proceed to subsequent dependent nodes and must transition to `AMBIGUOUS_HALTED`, where it waits for one of the five human resolution actions (`ARCHITECTURE_STATE_MODEL.md` §1.6). Verification never resolves ambiguity by assumption, and never permits a retry of a `NON_IDEMPOTENT` or `NON_FENCEABLE_EXTERNAL` operation.

---

## 3. VERIFICATION OF FENCED COMMITS (F-A-01)

For `FENCEABLE_BROKERED` operations the verification input set is strengthened, because a stale-commit claim is now provable rather than inferred:

1. **Ledger evidence.** For every brokered commit, `SYS-FCB` returns a signed `commit_receipt` (the durable projection of the `CommitRecord`: commit id, epoch, resource key, post-commit hash, outcome) — see `ARCHITECTURE_DATA_MODEL.md` §2.2. The Verification Plane consumes the receipt as *evidence of mutation*, never as *evidence of success*: a commit can land and still leave the postcondition unsatisfied. Receipts are durable, so a worker that dies after committing still leaves provable evidence.
2. **Physical observation.** The resource is re-read independently (file hash, row contents, process list, UI tree, screenshot OCR) through a sensor path that does not trust the worker's report.
3. **Cross-check matrix.**

| `CommitRecord` | Observed state matches postcondition | Verdict |
| :--- | :--- | :--- |
| present | yes | `SATISFIED` |
| present | no | `UNSATISFIED` — mutation landed but the goal is unmet; replan or escalate |
| absent, `FENCE_REJECTED` | unchanged | `UNSATISFIED` (clean failure) — safe to replan only if retry-eligible |
| absent | changed (external interference) | `INDETERMINATE` → `AMBIGUOUS_HALTED` |
| present, `FENCEABLE_GATED` | ambiguous | `INDETERMINATE` → `AMBIGUOUS_HALTED` |

4. **Sensor independence.** For `RISK_TIER >= 2` outcomes, observation may not be collected by the worker that performed the action; sensors are hosted by `SYS-PERCEPTION` and, where possible, read state through a different OS API than the one used to mutate it.
