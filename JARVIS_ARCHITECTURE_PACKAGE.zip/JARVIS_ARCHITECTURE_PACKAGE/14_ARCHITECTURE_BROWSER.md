# BROWSER AUTOMATION SUBSYSTEM SPECIFICATION
Document Identifier: JARVIS-ARCH-013
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. MULTI-PROFILE ISOLATION MODEL

The Browser Subsystem operates multi-process Chromium instances via the Chrome DevTools Protocol (CDP), maintaining strict physical isolation between user profiles:
```text
+--------------------------------------------------------------------------+
| Profile Type: EPHEMERAL AUTOMATION (Default) |
| - Storage: In-memory or temporary disk sandbox (purged on task end). |
| - Credentials: Zero access to host user cookies or saved passwords. |
| - Usage: Information retrieval, web scraping, public form processing. |
+--------------------------------------------------------------------------+

+--------------------------------------------------------------------------+
| Profile Type: BROKER-MEDIATED AUTHENTICATED SESSION (Restricted) |
| - Storage: Broker-owned profile store (SYS-CRED); daemon has no read |
| path to cookie material. |
| - Credentials: NOT held by this process. The daemon receives a |
| domain-scoped SessionLease only (see SECURITY 6.2). |
| - Policy: ALL navigation to unlisted domains blocked. State-changing |
| POST/PUT/PATCH/DELETE are executed by SYS-CRED, never by the |
| renderer, and require RISK_TIER_3 + confirmation. |
+--------------------------------------------------------------------------+
```


---

## 2. JAVASCRIPT EXECUTION MODES

To mitigate DOM-based prompt injection and malicious script execution, the browser enforces three operational tiers:

Canonical namespace: `JS_MODE_*` (never `TIER_*` — see ARCHITECTURE_SECURITY.md §5.6).

1. `JS_MODE_READ_ONLY`: JavaScript execution is disabled entirely; pages are rendered strictly as static HTML snapshots.
2. `JS_MODE_CONTROLLED_DOM`: JavaScript is active for page rendering, but a CDP command allowlist blocks `eval()`, Web Workers, and direct network fetches outside the host domain.
3. `JS_MODE_FULL_INTERACTIVE`: Unrestricted script execution inside the sandbox. **Human visual supervision is a detection aid and a usability control, not a security enforcement mechanism.** In this mode the renderer is assumed potentially compromised: it can read the page it renders, and nothing else. No security property in this document depends on a human watching the screen.

---

## 3. UNTRUSTED DOM SANITIZATION

Data extracted from the DOM undergoes multi-stage sanitization before ingestion into the AI Planning context:
1. Stripping Executable Elements: All `<script>`, `<style>`, `<iframe>`, and `<object>` tags are stripped, using a real HTML parser (never regular expressions).
2. Hidden Element Pruning: Elements with CSS attributes `display: none`, `visibility: hidden`, or zero opacity are removed to reduce hidden-text injection surface.
3. Structural Normalization: The DOM is collapsed into a clean, semantic Markdown representation of interactive elements, links, and text nodes.

**Sanitization is not a security boundary (F-A-15).** Steps 1-3 are a *de-noising* measure that reduces token count and removes obvious carriers. They are defeated by CSS/animation tricks, shadow DOM, canvas-rendered text, SVG, and same-page scripted mutation. Therefore:
* Every DOM-derived string is tagged `PROVENANCE_UNTRUSTED_CONTENT` **regardless of whether sanitization ran**, and keeps that tag through summarization, memory write, and every later model call.
* Sanitized output is never treated as validated data, and never populates a parameter that is not already declared in the capability's schema.
* Injection containment is provided by the downstream pipeline in ARCHITECTURE_AI.md §3, not by this section.

---

## 4. AUTHENTICATED AUTOMATION BOUNDARY

The browser daemon is a **Low-Integrity renderer driver**, never a credential holder.

```text
+-----------------------------------------------------------------+
| SYS-CRED (Credential Broker, Medium Integrity) |
| - Owns the persistent profile store and all session material |
| - Applies cookies to requests itself (renderer never sees them) |
| - Mints SessionLease / executes the Authenticated Request Proxy |
+-----------------------------------------------------------------+
| SessionLease(lease_id, domain_scope[], methods[], expiry) |
v
+-----------------------------------------------------------------+
| SYS-BROWSER daemon (Low Integrity, AppContainer) |
| - CDP command ALLOWLIST; getCookies/getAllCookies DENIED |
| - May drive the leased session for READ-ONLY navigation |
| - CANNOT originate an authenticated state-changing request |
+-----------------------------------------------------------------+
```

1. **Cookie confinement.** Cookie material is applied by `SYS-CRED` inside the broker-owned request path. CDP methods that enumerate or export credential material (`Network.getCookies`, `Network.getAllCookies`, `Storage.getCookies`, `Network.setCookie` for out-of-lease domains) are denied by the daemon's command allowlist, and the denial is audited as `CREDENTIAL_ACCESS_DENIED`.
2. **Session lease.** Idle timeout 15 minutes, absolute 8 hours, explicit domain scope, explicit method scope. Leases are per-profile and single-domain by default.
3. **State-changing requests.** `POST`, `PUT`, `PATCH`, `DELETE`, form submission, purchase, upload, or message send are executed by `SYS-CRED`'s Authenticated Request Proxy under an `ActionLease` bound to `(method, canonical_url, body_sha256, session_lease_id)`. The proxy refuses any ActionLease whose body hash does not match the confirmed body — this binds the human confirmation to the exact bytes sent (F-A-13).
4. **Script-rendered actions.** Where a site can only be driven by in-page JavaScript (a button whose handler issues the request), the action is executed inside the leased session under `JS_MODE_FULL_INTERACTIVE`, classified `NON_FENCEABLE_EXTERNAL`, requires `RISK_TIER_3` confirmation, and is followed by mandatory post-action verification. The architecture does not claim the renderer can be prevented from *issuing* a request in this mode; it claims the request carries no credential the renderer could steal and that the outcome is verified and audited.
5. **Browser RCE behavior.** A compromised renderer/daemon must be assumed possible. Its blast radius is bounded to: reading the currently rendered page, driving the leased session within `domain_scope`, and consuming its own CPU/memory quota. It has no cookie read, no other profile, no `ActionLease` minting authority, no `SYS-FCB` write handle, no egress outside the allowlist, and no path to the secret store.
6. **Credential revocation.** Triggered by user action, policy verdict, lease expiry, repeated `CREDENTIAL_ACCESS_DENIED`, or renderer-termination anomaly. Revocation drops the lease, rotates the session material, terminates the profile's browser processes, and emits `CREDENTIAL_SESSION_REVOKED`.
7. **Audit events.** `CREDENTIAL_LEASE_ISSUED`, `CREDENTIAL_LEASE_USED`, `CREDENTIAL_ACTION_LEASE_MINTED`, `CREDENTIAL_ACCESS_DENIED`, `CREDENTIAL_SESSION_REVOKED`, `BROWSER_NAVIGATION_BLOCKED`, `BROWSER_STATE_CHANGE_CONFIRMED`.
