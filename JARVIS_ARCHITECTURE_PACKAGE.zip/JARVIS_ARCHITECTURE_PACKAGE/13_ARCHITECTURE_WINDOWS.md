# WINDOWS PLATFORM INTEGRATION ARCHITECTURE
Document Identifier: JARVIS-ARCH-012
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. INTEGRITY LEVELS & PRIVILEGE BOUNDARIES

JARVIS adheres strictly to Windows Least Privilege and User Account Control (UAC) boundary models:
```text
+--------------------------------------------------------------------------+
| HIGH INTEGRITY (Elevated Admin) |
| Windows UAC Elevation Helper Service (Isolated, Out-of-Process COM) |
| Strictly invoked via OS UAC prompt; handles driver/system updates. |
+--------------------------------------------------------------------------+
^
| (IPC via Named Pipe with Strict DACL)
+--------------------------------------------------------------------------+
| MEDIUM INTEGRITY (Standard User) |
| Core Orchestrator, Task Planner, Policy Engine, Memory Store |
| Runs within standard interactive user desktop session. |
+--------------------------------------------------------------------------+
|
| (Job Object + Restricted Token)
v
+--------------------------------------------------------------------------+
| LOW INTEGRITY / APPCONTAINER (Untrusted Sandbox) |
| Browser Daemons, Third-Party Plugins, Untrusted File Parsers |
| Zero write access to user files outside designated AppData isolation box.|
+--------------------------------------------------------------------------+
```


---

## 2. DUAL-MODE WINDOWS CONTROL

Windows automation combines native semantic tree inspection with a computer vision fallback:

```text
                +---------------------------+
                |   UI Interaction Intent   |
                +---------------------------+
                              |
                              v
                +---------------------------+
                |    Query UIA COM Tree     |
                +---------------------------+
                              |
                 +------------+------------+
                 |                         |
          (Element Found)           (Element Missing)
                 v                         v
   +---------------------------+ +---------------------------+
   | Native UIA Action Dispatch| | Visual Fallback Activated |
   | - InvokeProvider          | | - High-Res Screen Capture |
   | - ValuePattern.SetValue   | | - OCR / Grounding Model   |
   | - SelectionItemPattern    | | - Template Match / BBox   |
   +---------------------------+ +---------------------------+
                 |                         |
                 +------------+------------+
                              |
                              v
                +---------------------------+
                | Post-Action Verification  |
                | Verify element/screen state|
                +---------------------------+
```


---

## 3. FILESYSTEM SAFETY & CANONICALIZATION

Filesystem access violations are prevented through mandatory kernel-level path canonicalization prior to policy evaluation:
1. Canonical Path Resolution: Paths are converted to their volume-guid canonical form using Win32 `GetFinalPathNameByHandleW` to eliminate bypasses via symlinks, junction points, 8.3 short names (`PROGRA~1`), or relative traversal (`..`).
2. Protected Directory Deny-List: Core policies strictly deny modification of `C:\Windows\*`, `C:\Program Files\*`, and boot partitions unless explicitly unlocked via a `RISK_TIER_4` administrative confirmation.

3. **All fenced writes are brokered (F-A-01).** The Windows Platform Controller holds **no** write handle to a protected or user resource. Every file write, delete, and rename, and every registry write, is expressed as a `FencedCommitCall` (`CTR-013`) to `SYS-FCB`, which owns the handle, re-validates the `OwnershipEpoch`, and applies the mutation atomically. A worker whose ownership was revoked cannot write regardless of what its own code does.
4. **Registry writes** follow the same path: the value is staged and applied through a broker-held `HKEY`; multi-value updates are swapped via `RegReplaceKey`.
5. **UI input injection** (`SendInput`, UIA `InvokePattern`) is `FENCEABLE_GATED`: frames are serialized through the Input Gate and refused when the lease is stale. Input already queued in a window message queue cannot be recalled, so every UI action is followed by mandatory post-action observation (`ARCHITECTURE_VERIFICATION.md` §1).
