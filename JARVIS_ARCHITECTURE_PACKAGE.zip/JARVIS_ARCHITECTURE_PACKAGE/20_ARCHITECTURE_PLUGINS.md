# PLUGIN & EXTENSIBILITY ARCHITECTURE
Document Identifier: JARVIS-ARCH-019
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. PLUGIN MANIFEST & SIGNATURE VALIDATION

Third-party extensions are strictly constrained by digital signatures and explicit permission manifests.

**Manifest authenticity (F-A-02):** the `developer_signature` proves *authorship*, not *truth*. Every manifest field enters the Trust Classification Registry at `ASSURANCE_DECLARED`; `risk_tier`, `idempotency_class`, `simulatable`, and any abortability field are treated as **claims** and grant the plugin no safety authority (ARCHITECTURE_SECURITY.md §5.2).

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "PluginManifest",
  "type": "object",
  "properties": {
    "plugin_id": { "type": "string", "pattern": "^[a-z0-9_\\-]+$" },
    "version": { "type": "string" },
    "developer_signature": { "type": "string" },
    "requested_permissions": {
      "type": "array",
      "items": { "type": "string", "enum": ["NETWORK_ACCESS_HOST_ALLOWLISTED", "FILESYSTEM_READ_SCOPED", "CLIPBOARD_READ_ON_CONFIRMATION", "CLIPBOARD_WRITE_OWNED"] }
    },
    "entry_point": { "type": "string" },
    "declared_capabilities": { "type": "array", "items": { "type": "string" } }
  },
  "required": ["plugin_id", "version", "developer_signature", "requested_permissions", "entry_point"]
}
```
2. APPCONTAINER SANDBOXING
Plugins run within an isolated Windows AppContainer sandbox:

Filesystem Boundary: Read/write access is restricted to the plugin's private sandboxed directory (C:\ProgramData\JARVIS\Plugins\Data\{plugin_id}\). All access to the user's home directory or system folders is blocked at the NT kernel boundary.
Network Isolation: Inbound connections are prohibited. Outbound network traffic is blocked by default unless explicitly granted in the manifest and authorized by the user.
Broker Architecture: Plugins interact with JARVIS capabilities strictly via the Core IPC broker, subjecting every request to the central Policy Engine.

### 3. DIRECTORY ACL SPECIFICATION (F-A-20)

`C:\ProgramData\JARVIS\Plugins\Data\{plugin_id}\` is created **by the Core at install time**, never by the plugin, with:

| Property | Setting |
| :--- | :--- |
| Owner | Administrators (never the plugin) |
| DACL | `PLUGIN_APPCONTAINER_SID_{plugin_id}:(OI)(CI)RW` + `SYSTEM:(OI)(CI)F` + `Administrators:(OI)(CI)F`. **No** inheritance from `C:\ProgramData`, no `Users`, no `Everyone`, no access for another plugin's AppContainer SID |
| Inheritance | Upward inheritance blocked by a protected DACL, so a change to `C:\ProgramData` cannot widen plugin access |
| Reparse points | Symlink, junction, and mount-point creation inside the directory is denied at the AppContainer policy layer, so a plugin cannot redirect its sandbox at a user directory |
| Verification | ACL re-verified at plugin load; mismatch rejects the plugin with `PLUGIN_SANDBOX_ACL_MISMATCH` and emits an audit event |
| Cleanup | Uninstall removes the container SID and the directory; a failed removal is reported, never ignored |

### 4. CLIPBOARD PERMISSION SCOPE (F-A-19)

`CLIPBOARD_READ_ON_CONFIRMATION` is deliberately **not** an ambient grant. The clipboard routinely carries passwords, one-time codes, and recovery phrases, so reads are treated as secret-bearing even though ordinary writes remain `RISK_TIER_1`:

1. A read requires a live, single-use `ClipboardReadGrant` bound to `(plugin_id, purpose_string, expiry <= 30 s)`.
2. The purpose string is shown to the user on first use per session; the grant is revocable at any time from the permissions UI.
3. Read content is delivered **directly into the plugin's declared target parameter** and is never persisted to memory, logs, telemetry, or audit payloads. The audit records `CLIPBOARD_READ` with the purpose and a content digest only.
4. Clipboard content transiting a model call is tagged `PROVENANCE_UNTRUSTED_CONTENT` **and** `SECRET_BEARING`, forcing `PRIVACY_CLASS_0_NO_EGRESS` unless the user explicitly overrides for that single call.
5. `CLIPBOARD_WRITE_OWNED` permits writes only while the plugin holds the clipboard lease; sensitive writes are auto-cleared after a user-configurable timer with a `CLIPBOARD_CLEARED` event.
