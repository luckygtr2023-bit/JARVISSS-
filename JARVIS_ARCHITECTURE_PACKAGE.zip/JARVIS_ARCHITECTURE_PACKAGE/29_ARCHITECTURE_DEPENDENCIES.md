# SYSTEM DEPENDENCY ARCHITECTURE
Document Identifier: JARVIS-ARCH-028
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. DIRECTED SUBSYSTEM DEPENDENCY GRAPH

Subsystem dependencies flow strictly downward toward foundational, stable layers. Upward or circular dependencies are prohibited.
```text
Level 4: Presentation & Outer Peripherals
[SYS-FE: Desktop HUD] [SYS-AND: Android Gateway]
| |
+--------------+--------------+
v
Level 3: Core Control & Planning
+-----------------------------------------------------------------------+
| [SYS-CORE]                                                            |
+-----------------------------------------------------------------------+
  |        |        |          |            |
  v        v        v          v            v
[SYS-PLAN] [SYS-SEC] [SYS-EXEC] [SYS-FCB] [SYS-CRED]
     |         |        |
     v         v        v
   [SYS-AI] [SYS-MEM] [SYS-TOOL]

|
v
Level 2: Platform Adapters & Workers
[SYS-WIN] [SYS-BROWSER] [SYS-PLUGINS]
| | |
+-----------+----------------+
|
v
Level 1: System Foundations
[SYS-AUD] [SYS-IPC] [SYS-DATA]
```


---

## 2. CIRCULAR DEPENDENCY PREVENTION RULES

1. Rule 1: No capability adapter (`SYS-WIN`, `SYS-BROWSER`) may reference or call the Core Orchestrator (`SYS-CORE`) directly; adapters communicate strictly via IPC response frames to the Execution Controller (`SYS-EXEC`).
2. Rule 2: The Security Kernel (`SYS-SEC`) cannot depend on the AI Gateway (`SYS-AI`). Policies must be evaluated deterministically without reliance on generative model completions.
3. Rule 3: The Audit Logger (`SYS-AUD`) has zero downward dependencies on other application layers; it depends solely on low-level filesystem and cryptographic primitives.
4. Rule 4: The Fencing & Commit Broker (`SYS-FCB`) depends only on the filesystem, `SYS-AUD`, and `SYS-SEC` (scope verification). It must **not** depend on `SYS-PLAN`, `SYS-AI`, `SYS-BROWSER`, `SYS-MEM`, or the frontend; doing so would place model-influenced or renderer-influenced code on the commit path.
5. Rule 5: The Credential Broker (`SYS-CRED`) depends on the OS keystore/TPM and `SYS-SEC`. It must not depend on `SYS-AI`, `SYS-PLAN`, or plugin code, and it exposes no credential-returning API.
6. Rule 6: The Trust Classification Registry (`SYS-TCR`) is readable by `SYS-EXEC`, `SYS-PLAN`, `SYS-TOOL`, and `SYS-SIM`, and writable by `SYS-SEC` alone. No capability author, plugin, model, or UI component has a write path.
7. Rule 7: Notifications originate from `SYS-CORE`/`SYS-PERCEPTION` and are delivered over a distinct, minimal-allowlist notification IPC to headless workers, so a worker termination — expected or unexpected — cannot block or deadlock the Core.
8. Rule 8: The Replanning Engine may request a scope expansion; only `SYS-SEC` may grant one, and only after a new challenge is confirmed. A replan can never widen its own authority.
