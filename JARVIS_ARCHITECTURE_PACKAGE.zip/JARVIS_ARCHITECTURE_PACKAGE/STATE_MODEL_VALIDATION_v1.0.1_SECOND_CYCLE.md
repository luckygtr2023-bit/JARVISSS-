# STATE-MODEL & CONFIRMATION VALIDATION — v1.0.1-LOCK-CANDIDATE (SECOND CYCLE)

**Document Identifier:** JARVIS-REPAIR-VAL-003-B
**Repair Cycle:** v1.0.1-LOCK-CANDIDATE (Second Repair)
**Status:** COMPLETE & VERIFIED
**Date:** 2026-09-12

---

## 1. REPAIR VERIFICATION: R-AUDIT-003

**Finding:** `06_ARCHITECTURE_STATE_MODEL.md` §1.1 ASCII diagram failed to reflect the `SUSPENDED` state and its transitions.

### 1.1 Repair Actions
- **Visual Update:** Updated the ASCII state machine diagram to include the `SUSPENDED` node.
- **Transition Mapping:** Added directed edges for:
    - `EXECUTING` $\rightarrow$ `SUSPENDED` (Voice Cancel)
    - `DISPATCHED` $\rightarrow$ `SUSPENDED` (Voice Cancel)
    - `SUSPENDED` $\rightarrow$ `AWAITING_CONFIRMATION` / `DISPATCHED` (Re-auth)
    - `SUSPENDED` $\rightarrow$ `CANCELLED` (Timeout/Abandon)

### 1.2 Verification
- [✓] Diagram visually matches the Task State Transition Table.
- [✓] All 5 suspension-related transitions are represented.

---

## 2. REPAIR VERIFICATION: R-AUDIT-009 (Failure Injection)

**Finding:** `32_ARCHITECTURE_FAILURE_INJECTION.md` FIT-01 expected a universal `AMBIGUOUS_HALTED` result regardless of fenceability.

### 2.1 Repair Actions
Updated FIT-01 to split expectations:
- **FENCEABLE_BROKERED** (No CommitRecord) $\rightarrow$ **FAILED** (Safe to replan)
- **FENCEABLE_GATED / NON_FENCEABLE_*** $\rightarrow$ **AMBIGUOUS_HALTED** (Indeterminate)

### 2.2 Verification
- [✓] `32_ARCHITECTURE_FAILURE_INJECTION.md` now reflects per-class outcomes for FIT-01.

---

## 3. SIGN-OFF
**R-AUDIT-003 & R-AUDIT-009 Status:** ✓ **RESOLVED**
The state model is now visually and logically complete; failure expectations are now precisely aligned with fenceability classes.
