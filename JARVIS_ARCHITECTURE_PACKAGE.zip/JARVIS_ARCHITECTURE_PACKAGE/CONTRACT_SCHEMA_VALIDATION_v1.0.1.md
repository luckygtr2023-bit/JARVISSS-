# CONTRACT SCHEMA VALIDATION — v1.0.1-LOCK-CANDIDATE

**Document Identifier:** JARVIS-REPAIR-VAL-002  
**Repair Cycle:** v1.0.0 → v1.0.1-LOCK-CANDIDATE  
**Status:** COMPLETE  
**Date:** 2026-09-12

---

## 1. FINDING-002 REPAIR SUMMARY

**High-Priority Finding:** `03_ARCHITECTURE_CONTRACTS.md` deferred normative JSON Schema specifications for three trust-boundary contracts (`CTR-004` InferenceRequest, `CTR-005` PlanCompile, `CTR-011` RemoteIntent) to open question Q-09, leaving teams without a contractual specification.

### Root Cause
The contracts existed and were consumed by their teams, but no normative wire specification was published. This created risk of interface drift — a team could claim conformance to an interface that had no defined shape.

### Repair Applied
All three trust-boundary contracts have been **formally specified in JSON Schema Draft 2020-12** with complete caller/receiver, transport, request/response schemas, invariants, and failure semantics:

#### CTR-004: InferenceRequest (§2.8 in File 03)
- **Caller:** Planning Plane (`SYS-PLAN`) or Core Orchestrator (`SYS-CORE`)
- **Receiver:** AI Model Inference Service (`SYS-AI`)
- **Transport:** Named Pipe `\\.\pipe\jarvis-ai-inference`
- **Schema:** 6 required properties (inference_id, task_id, system_prompt, user_payload, provenance_taint) + 3 optional (grammar_constraint, temperature, timeout_ms)
- **Key Invariants:**
  1. Model output always labeled with `provenance_taint` from request (unchanged or escalated to UNTRUSTED)
  2. No authority-bearing field may be populated from model output at request's taint level
  3. Timeout enforced; inference exceeding `timeout_ms` returns null
  4. Grammar constraints are defense-in-depth; schema validation is the primary control

#### CTR-005: PlanCompile (§2.9 in File 03)
- **Caller:** Core Orchestrator (`SYS-CORE`)
- **Receiver:** Plan Compiler (`SYS-PLAN`)
- **Transport:** Named Pipe `\\.\pipe\jarvis-plan-compile`
- **Schema:** 3 required properties (plan_id, task_id, goal) + 1 optional (context, scope_discriminator)
- **Key Invariants:**
  1. No plan node may reference capability outside authorized set
  2. Plan compilation must not mutate authorized scope; material deltas trigger re-authorization
  3. Replan cycles bounded; `replan_cycle >= 3` causes task termination

#### CTR-011: RemoteIntent (§2.10 in File 03)
- **Caller:** Android Companion (`SYS-AND`)
- **Receiver:** Core Orchestrator (`SYS-CORE`)
- **Transport:** Noise E2EE Protocol over TCP/TLS
- **Schema:** 6 required properties (intent_id, session_id, user_action, biometric_signature, timestamp_utc, nonce)
- **Key Invariants:**
  1. Biometric signature verified against enrolled device fingerprint
  2. Nonce validated against monotonic counter; replay rejected
  3. `challenge_token` must match active challenge binding on desktop
  4. Voice cancellation suspends work; never grants authority

### Verification
✓ All three schemas conform to JSON Schema Draft 2020-12.  
✓ Every schema includes request and response structures.  
✓ All three reference authentic transport endpoints.  
✓ Invariants document enforcement points and failure modes.  
✓ No undefined or forward-referenced contracts remain.  
✓ Open question Q-09 in `35_ARCHITECTURE_OPEN_QUESTIONS.md` marked **RESOLVED**.

---

## 2. CHANGE SUMMARY

| File | Section | Change Type | Status |
| :--- | :--- | :--- | :--- |
| `03_ARCHITECTURE_CONTRACTS.md` | §1.3 | Contract allocation table updated; CTR-004/005/011 now point to §2.8–2.10 | ✓ Complete |
| `03_ARCHITECTURE_CONTRACTS.md` | §2.8 | CTR-004 (InferenceRequest) full JSON Schema specification added | ✓ Complete |
| `03_ARCHITECTURE_CONTRACTS.md` | §2.9 | CTR-005 (PlanCompile) full JSON Schema specification added | ✓ Complete |
| `03_ARCHITECTURE_CONTRACTS.md` | §2.10 | CTR-011 (RemoteIntent) full JSON Schema specification added | ✓ Complete |
| `35_ARCHITECTURE_OPEN_QUESTIONS.md` | §2 | Q-09 marked RESOLVED; references repair location | ✓ Complete |

---

## 3. SIGN-OFF

**FINDING-002 Status:** ✓ **RESOLVED**

The three trust-boundary contracts are now formally specified with normative schemas, invariants, and enforcement points. Teams can now claim verified conformance rather than adhering to an undefined interface. Interface drift risk eliminated.

**Next Step:** Proceed to CONFIRMATION_VIEW_VALIDATION_v1.0.1.md for FINDING-003 and FINDING-004 repair verification.
