# FORMAL INTERFACE CONTRACTS SPECIFICATION
Document Identifier: JARVIS-ARCH-002
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. PROTOCOL FRAMING & TRANSPORT

All internal communication between the Core Orchestrator and out-of-process workers, daemons, and frontends operates over Windows Named Pipes utilizing a length-prefixed, binary-encoded framing protocol (Protocol Buffers v3 / Canonical JSON).

### 1.1 Wire Frame Structure
```text
+-------------------------------------------------------------------------+
| Magic (4B) | Version (2B) | Flags (2B) | Payload Length (4B) | Msg ID (16B) |
+-------------------------------------------------------------------------+
| Nonce (12B) | Epoch Token (8B) | Target Service ID (4B) |
+-------------------------------------------------------------------------+
| Payload Data (Encrypted / Authenticated via AEAD or Signed Struct) |
+-------------------------------------------------------------------------+
| HMAC / Poly1305 Authentication Tag (16B) |
+-------------------------------------------------------------------------+
```


---

### 1.2 Frame Size Limits & Length-Field Semantics (F-A-26)

The `Payload Length (4B)` field is a **32-bit little-endian length of the payload section only**; it is not an entitlement to 4 GiB frames.

| Limit | Value | Enforced by |
| :--- | :--- | :--- |
| `MAX_FRAME_SIZE` (header + payload + tag) | **4 MiB** (4,194,304 bytes) | Receiver, before allocation. Any frame exceeding it is rejected with `FRAME_TOO_LARGE`, the pipe is terminated, and `SECURITY_ANOMALY_OVERSIZE_FRAME` is audited |
| `MAX_PAYLOAD_SIZE` | 4 MiB − 56 bytes | Same |
| Default per-request payload budget | 256 KiB | Sender-side chunking |
| Bulk transfer | Never in-band. Streams (screen frames, audio, file bodies) use a separate chunked bulk channel with per-chunk framing and a bounded window | `SYS-IPC` |
| `SubmitRequest.raw_payload` | 32 KiB (`maxLength: 32768`) | Schema validation |

This resolves the previous inconsistency in which the frame format implied a 4 GB ceiling while the IPC specification terminated over 16 MB and the request schema allowed 32 KB.

---

### 1.3 Contract Numbering Space

The `CTR-0NN` identifier space is allocated in full. Three classes of entry exist, and a reviewer must be able to tell them apart without inference (raised by the repair cycle's own cross-document audit, Audit B — `CF-02`).

| Contract | Name | Owning team | Class | Schema in this document |
| :--- | :--- | :--- | :--- | :--- |
| `CTR-001` | RequestIntake / Frontend Request Submission | `TEAM-CORE` (with `TEAM-FE`) | Trust-boundary contract | §2.1 |
| `CTR-002` | WorkerDispatch / Plan Node Execution Dispatch | `TEAM-EXEC` | Trust-boundary contract | §2.2 |
| `CTR-003` | PolicyEval / Policy Authorization Challenge | `TEAM-SEC` | Trust-boundary contract | §2.3 |
| `CTR-004` | InferenceReq | `TEAM-AI` | Trust-boundary contract (internal) | §2.8 |
| `CTR-005` | PlanCompile | `TEAM-PLAN` | Trust-boundary contract (internal) | §2.9 |
| `CTR-006` | WinAction | `TEAM-WIN` | Internal subsystem interface | Owned by team; schema published internally |
| `CTR-007` | WebAction | `TEAM-WEB` | Internal subsystem interface | Owned by team; schema published internally |
| `CTR-008` | AudioStream | `TEAM-VOX` | Internal subsystem interface | Owned by team; schema published internally |
| `CTR-009` | VisionFrame | `TEAM-VIS` | Internal subsystem interface | Owned by team; schema published internally |
| `CTR-010` | MemoryStore | `TEAM-MEM` | Internal subsystem interface | Owned by team; schema published internally |
| `CTR-011` | RemoteIntent | `TEAM-AND` | Trust-boundary contract (device) | §2.10 |
| `CTR-012` | AuditAppend | `TEAM-AUD` | Trust-boundary contract | Superseded in this version by `CTR-016` (§2.7), which is the specified boundary; `CTR-012` remains the historical identifier used by existing tooling |
| `CTR-013` | FencedCommit | `TEAM-FCB` | Trust-boundary contract (new in 1.0.0-LOCK-CANDIDATE) | §2.4 |
| `CTR-014` | CredentialLease | `TEAM-CRED` | Trust-boundary contract (new in 1.0.0-LOCK-CANDIDATE) | §2.5 |
| `CTR-015` | TrustQuery | `TEAM-TCR` | Trust-boundary contract (new in 1.0.0-LOCK-CANDIDATE) | §2.6 |
| `CTR-016` | AuditAppend (hardened) | `TEAM-AUD` | Trust-boundary contract (new in 1.0.0-LOCK-CANDIDATE) | §2.7 |

**Invariant:** an identifier in this space is never reused for a different interface, and a contract that crosses a trust boundary must have a schema in this document before a team may claim conformance to it. The three trust-boundary contracts (`CTR-004`, `CTR-005`, `CTR-011`) are now specified in §2.8–2.10. The historical `CTR-012` is superseded by `CTR-016`.

---

## 2. CRITICAL INTERFACE CONTRACTS

---


### 2.1 Contract CTR-001: Frontend Request Submission
* Caller: Presentation Layer (`SYS-FE`)
* Receiver: Core Orchestrator (`SYS-CORE`)
* Transport: Named Pipe `\\.\pipe\jarvis-core-frontend`
* Request Schema (`SubmitRequest`):
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SubmitRequest",
  "type": "object",
  "properties": {
    "request_id": { "type": "string", "format": "uuid" },
    "session_id": { "type": "string", "format": "uuid" },
    "timestamp_utc": { "type": "string", "format": "date-time" },
    "actor": {
      "type": "object",
      "description": "Identity is established by the authenticated IPC session, not by a bearer credential. There is deliberately NO auth_token field (F-A-09).",
      "properties": {
        "user_id": { "type": "string" },
        "frontend_instance_id": { "type": "string", "format": "uuid" },
        "session_assertion": {
          "type": "object",
          "description": "Asserted by the frontend, VERIFIED INDEPENDENTLY by SYS-CORE against the IPC peer identity. An unverifiable assertion is rejected with PEER_VERIFICATION_FAILED.",
          "properties": {
            "ipc_session_id": { "type": "string", "format": "uuid" },
            "peer_pid": { "type": "integer" },
            "peer_binary_sha256": { "type": "string" }
          },
          "required": ["ipc_session_id", "peer_pid", "peer_binary_sha256"]
        }
      },
      "required": ["user_id", "frontend_instance_id", "session_assertion"]
    },
    "input_modality": { "type": "string", "enum": ["TEXT", "VOICE", "EVENT"] },
    "raw_payload": { "type": "string", "maxLength": 32768 },
    "client_context": {
      "type": "object",
      "properties": {
        "active_window_hwnd": { "type": "integer" },
        "cursor_position": { "type": "array", "items": { "type": "integer" }, "minItems": 2, "maxItems": 2 }
      }
    }
  },
  "required": ["request_id", "session_id", "timestamp_utc", "actor", "input_modality", "raw_payload"]
}
```
Response Schema (SubmitResponse):

```json
{
  "request_id": "c4b1b369-0e42-4f05-8839-bc55b4b7a2d1",
  "session_id": "1b6f0d54-2c9a-4e0e-9d3e-8f2f7a5c4b11",
  "status": "ACCEPTED",
  "assigned_task_id": "7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77",
  "response_nonce": "9d1c3f7a5b2e4c6081a2b3c4d5e6f708",
  "core_signature": "ed25519:5f2b...c1",
  "error": null
}
```
Invariants & Constraints:
Replay Protection: Nonce cache checked against a 300-second sliding window.
Idempotency: Duplicate request_id within active session returns identical assigned_task_id.
Timeout: 2500ms synchronous ACK deadline.
Response Integrity (F-A-21): every `SubmitResponse` echoes `request_id` **and** the request's `client_nonce`, carries a fresh `response_nonce`, and is signed with the Core's per-session Ed25519 key (`core_signature`). The frontend MUST reject an unsigned, mis-signed, stale-nonce, or request_id-mismatched response. A response that fails verification is surfaced to the user as `UNTRUSTED_ACK` and never causes the UI to display an accepted task.
Session Binding (F-A-09): `session_id` returned here is the IPC session the request was authenticated under; a frontend may not address another session.
### 2.2 Contract CTR-002: Plan Node Execution Dispatch

* Caller: Execution Controller (`SYS-EXEC`)
* Receiver: Capability Worker Host (`SYS-WORKER`)
* Transport: Named Pipe `\\.\pipe\jarvis-worker-{worker_id}`
* Request Schema (`DispatchExecution`):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "DispatchExecution",
  "type": "object",
  "properties": {
    "execution_id": { "type": "string", "format": "uuid" },
    "task_id": { "type": "string", "format": "uuid" },
    "node_id": { "type": "string" },
    "attempt_id": { "type": "integer", "minimum": 1 },
    "capability_name": { "type": "string" },
    "tool_action": { "type": "string" },
    "parameters": { "type": "object" },
    "intent_token": { "type": "string", "description": "Single-use, expires in 120s if unused; distinguishes intentional repetition from duplicate delivery (TOOLS 2.4)." },
    "fence_class": { "type": "string", "enum": ["FENCEABLE_BROKERED", "FENCEABLE_GATED", "NON_FENCEABLE_EXTERNAL", "NON_FENCEABLE_KERNEL"] },
    "assurance_level": { "type": "string", "enum": ["ASSURANCE_DECLARED", "ASSURANCE_REVIEWED", "ASSURANCE_ARCHITECTURALLY_VERIFIED", "ASSURANCE_RUNTIME_CONFIRMED"] },
    "authorized_scope_hash": { "type": "string", "description": "SHA-256 of the AuthorizedScope this dispatch is bound to; SYS-FCB refuses to issue a lease for a dispatch whose scope hash does not match the granted scope." },
    "ownership_grant": {
      "type": "object",
      "properties": {
        "resource_key": { "type": "string" },
        "epoch_id": { "type": "integer" },
        "grant_token": { "type": "string" },
        "expires_at_utc": { "type": "string", "format": "date-time" }
      },
      "required": ["resource_key", "epoch_id", "grant_token", "expires_at_utc"]
    },
    "timeout_ms": { "type": "integer", "maximum": 60000 }
  },
  "required": ["execution_id", "task_id", "node_id", "attempt_id", "capability_name", "tool_action", "parameters", "ownership_grant", "timeout_ms"]
}
```
* Response Schema (`ExecutionResult`):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "ExecutionResult",
  "type": "object",
  "properties": {
    "execution_id": { "type": "string", "format": "uuid" },
    "node_id": { "type": "string" },
    "attempt_id": { "type": "integer" },
    "status": { "type": "string", "enum": ["COMPLETED", "FAILED", "TIMED_OUT", "REVOKED", "FENCE_REJECTED", "INDETERMINATE"] },
    "observed_output": { "type": "object" },
    "error": {
      "type": "object",
      "properties": {
        "code": { "type": "string" },
        "message": { "type": "string" },
        "retryable": { "type": "boolean" }
      }
    },
    "fence_validation": { "type": "string", "enum": ["VALID", "STALE_EPOCH_REJECTED", "COMMIT_NOT_ATTEMPTED"] },
    "commit_receipt": {
      "type": ["object", "null"],
      "description": "Present only when fence_validation == VALID and the operation was FENCEABLE_BROKERED. Issued by SYS-FCB.",
      "properties": {
        "commit_id": { "type": "string", "format": "uuid" },
        "epoch_id": { "type": "integer" },
        "resource_key": { "type": "string" },
        "resource_hash_after": { "type": "string" },
        "committed_at_utc": { "type": "string", "format": "date-time" }
      },
      "required": ["commit_id", "epoch_id", "resource_key", "committed_at_utc"]
    },
    "execution_duration_ms": { "type": "integer" }
  },
  "required": ["execution_id", "node_id", "attempt_id", "status", "fence_validation", "execution_duration_ms"]
}
```
### 2.3 Contract CTR-003: Policy Authorization Challenge

* Caller: Core Orchestrator (`SYS-CORE`)
* Receiver: Security Kernel (`SYS-SEC`)
* Request Schema (`EvaluatePolicy`):

```json
{
  "task_id": "7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77",
  "node_id": "node_04_delete_file",
  "capability": "filesystem.delete",
  "parameters": {
    "canonical_path": "C:\\Users\\Default\\AppData\\Local\\Temp\\test.tmp"
  },
  "risk_tier": "RISK_TIER_2",
  "context": {
    "user_confirmed": false,
    "interactive_session": true,
    "pre_approval_lease_id": null
  }
}
```
* Note: `risk_tier` is supplied by the caller **as data**. `SYS-SEC` recomputes it deterministically from the capability signature and canonical parameters and ignores the supplied value if they disagree (ADR-001 consequence).
* Response Schema (`PolicyDecision`):

```json
{
  "decision": "CONFIRM_REQUIRED",
  "required_risk_tier": "RISK_TIER_2",
  "risk_tier_source": "SYS_SEC_RECOMPUTED",
  "challenge_token": "f3a2c1b0-9e8d-4c7b-6a5f-4e3d2c1b0a9f",
  "challenge_binding": {
    "op_id": "b7c1...4d",
    "resource_keys": ["file:C:\\Users\\Default\\AppData\\Local\\Temp\\test.tmp"],
    "body_sha256": null,
    "authorized_scope_hash": "...",
    "expires_at_utc": "2025-05-18T10:15:02.124Z"
  },
  "confirmation_prompt": "Delete file: C:\\Users\\Default\\AppData\\Local\\Temp\\test.tmp",
  "authorization_grant": null
}
```
**Confirmation View Dual-Layer Schema (R-AUDIT-008 repair):**

The Confirmation View separates user-displayable content from cryptographic binding material:

**SAFE TO DISPLAY Layer** (rendered in user-facing modal):
- Operation name (e.g., "Delete file")
- Resource identity (canonical path, URL, contact name — enough for user to recognize the object)
- Risk tier (`RISK_TIER_0` … `RISK_TIER_4`)
- User-friendly description of the action
- Never includes: secrets, tokens, credentials, hashes, or internal identifiers

Example displayable text:
```
Delete file: C:\Users\Default\AppData\Local\Temp\test.tmp
Risk: RISK_TIER_2 (Reversible File Modification)
```

**NEVER DISPLAY RAW Layer** (contained in `challenge_binding`, cryptographically signed):
- Exact operation bytes and parameter canonicalization
- `body_sha256` for authenticated requests (binds request body)
- `authorized_scope_hash` (binds authorized resource set)
- All other precise operational details
- User does not see this; the digest is signed

User's approval flow:
1. User sees: operation name, resource, risk tier (SAFE TO DISPLAY)
2. User cryptographically signs: SHA256(canonical_json(challenge_binding)) — the digest
3. Core verifies: recomputes digest from actual operation; must match signed digest
4. Core executes: only if digest verification succeeds
5. Mismatch rejection: if canonical parameters changed post-approval (scope widened, resource rewritten, tier elevated), digest mismatch triggers `CHALLENGE_REPLAY_REJECTED`

Anti-clickjacking guarantee: The user's signature is over the digest (binding material), not over the display text. Modal rendering cannot be manipulated to change the underlying operation without invalidating the signature.

---

### 2.4 Contract CTR-013: Fenced Commit (`SYS-FCB`)

* Caller: Capability Worker Host (`SYS-WORKER`) on the data-plane endpoint; `SYS-CORE` on the admin endpoint
* Receiver: Fencing & Commit Broker (`SYS-FCB`)
* Transport: Named Pipe `\\.\pipe\jarvis-fcb-commit-{session_uuid}` / `\\.\pipe\jarvis-fcb-admin-{session_uuid}`
* Authoritative answer to "who prevents a stale worker from committing": **`SYS-FCB`, and nothing else** (ARCHITECTURE_EXECUTION.md §2.0)

Request (data plane, one method per frame):

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "FencedCommitCall",
  "type": "object",
  "properties": {
    "method": { "type": "string", "enum": ["BEGIN_TXN", "STAGE_DATA", "COMMIT", "ABORT"] },
    "commit_id": { "type": "string", "format": "uuid" },
    "lease_id": { "type": "string", "format": "uuid" },
    "epoch_id": { "type": "integer" },
    "grant_token": { "type": "string" },
    "resource_key": { "type": "string" },
    "intent_token": { "type": "string" },
    "worker_id": { "type": "string" },
    "worker_signature": { "type": "string", "description": "Ed25519 over (method, commit_id, epoch_id, payload_sha256, frame_nonce)." },
    "payload_sha256": { "type": ["string", "null"] },
    "frame_nonce": { "type": "string" }
  },
  "required": ["method", "worker_id", "worker_signature", "frame_nonce"]
}
```

Response:

```json
{
  "status": "COMMIT_APPLIED",
  "commit_id": "5e17c2a4-90f1-4b7c-8a11-2d6e3f4a5b60",
  "epoch_id": 4821,
  "resource_key": "file:C:\\Users\\User\\Documents\\Summary.docx",
  "resource_hash_after": "9f1a3b...",
  "reject_reason": null
}
```
`status` ∈ `LEASE_OK | TXN_OPEN | STAGED | COMMIT_APPLIED | ABORTED | FENCE_REJECTED | SCOPE_MISMATCH | LEDGER_UNAVAILABLE`.
Invariants:
1. `COMMIT` succeeds only if the presented `epoch_id` equals the current ledger value at the instant of the ledger lock, and `commit_id` is unconsumed.
2. `FENCE_REJECTED` guarantees **no** target mutation occurred and staging is purged.
3. Every terminal outcome emits an `AuditEvent` (`FENCED_COMMIT_APPLIED`, `FENCE_REJECTION`, `COMMIT_ABORTED`).
4. `SCOPE_MISMATCH` is returned when `authorized_scope_hash` does not match the scope granted for the lease (F-A-10).

### 2.5 Contract CTR-014: Credential Session & Action Lease (`SYS-CRED`)

* Caller: `SYS-BROWSER` (lease acquisition, read-only use), `SYS-CORE` (action execution on behalf of a confirmed intent)
* Receiver: Credential Broker (`SYS-CRED`)

```json
{
  "method": "REQUEST_SESSION_LEASE",
  "profile_id": "saas-bridge-01",
  "domain_scope": ["app.example.com"],
  "method_scope": ["GET"],
  "requested_ttl_seconds": 900
}
```
```json
{
  "method": "EXECUTE_AUTHENTICATED_REQUEST",
  "session_lease_id": "c31b...9f",
  "action_lease_id": "88a7...02",
  "http_method": "POST",
  "canonical_url": "https://app.example.com/api/reports",
  "body_sha256": "4b8c1e...77",
  "confirmation_challenge_hash": "d41d8c...4f"
}
```
Invariants:
1. No response ever contains cookie values, header values bearing credentials, or password material.
2. `EXECUTE_AUTHENTICATED_REQUEST` refuses unless `body_sha256` matches the body actually sent and the `ActionLease` was minted against the same hash (binds human confirmation to exact bytes — F-A-13).
3. Every call emits `CREDENTIAL_LEASE_ISSUED` / `CREDENTIAL_LEASE_USED` / `CREDENTIAL_ACTION_LEASE_MINTED` / `CREDENTIAL_ACCESS_DENIED`.
4. `method_scope` expansion requires a new lease; leases are never widened in place.

### 2.6 Contract CTR-015: Trust Classification Query (`SYS-TCR`)

* Caller: `SYS-EXEC`, `SYS-PLAN`, `SYS-TOOL`, `SYS-SIM`
* Receiver: Security Kernel (`SYS-SEC`) — the only writer of the registry

```json
{
  "capability_id": "email.send",
  "capability_version": "1.4.0",
  "environment_fingerprint": "win11-26100-appcontainer-v3",
  "requested_property": "retry_eligibility"
}
```
```json
{
  "assurance_level": "ASSURANCE_ARCHITECTURALLY_VERIFIED",
  "retry_eligible": false,
  "simulation_eligible": true,
  "abortability_claim_admissible": false,
  "evidence_refs": ["EVID-2211", "FIT-02"],
  "expires_at_utc": "2026-01-01T00:00:00Z",
  "revocation_reason": null
}
```
Invariant: a `DECLARED`-only capability returns `retry_eligible: false`, `abortability_claim_admissible: false`. **An untrusted author can never obtain safety authority by editing a manifest.**

### 2.7 Contract CTR-016: Audit Append (`SYS-AUD`) — boundary (F-A-23)

* Caller: every component (append only); `SYS-FCB` on the commit path
* Receiver: Tamper-Evident Audit Logger (`SYS-AUD`) on a dedicated pipe endpoint `\\.\pipe\jarvis-audit-append`

```json
{
  "method": "APPEND",
  "event_type": "FENCED_COMMIT_APPLIED",
  "actor": "SYS_FCB",
  "task_id": "7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77",
  "payload": { "commit_id": "5e17c2a4-...", "epoch_id": 4821 },
  "payload_sha256": "e7d2b1...",
  "caller_sequence": 104218,
  "caller_signature": "ed25519:...",
  "durability": "SYNCHRONOUS"
}
```
Invariants:
1. Append-only API: there is no `UPDATE`, `DELETE`, `COMPACT`, or `REBUILD` method. The endpoint does not exist.
2. `durability: SYNCHRONOUS` is mandatory for `RISK_TIER >= 2` commit, authorization, confirmation, lease, revocation, and ambiguity events; the caller blocks until the record is fsynced.
3. Read access is **not** granted by this endpoint. Reading the ledger is restricted to `SYS-SEC` and the user console through a separate, separately-DACL'd read endpoint (resolves the contradiction XD-05 with ARCHITECTURE_COMPONENTS.md §2.11).
4. Failure to append returns `LEDGER_UNAVAILABLE`; the caller MUST then treat the intended action as impossible and the system enters `SAFE_LOCKDOWN` (no silent bypass).
5. A caller that cannot be identified, or whose signature fails, is rejected with `AUDIT_CALLER_UNVERIFIED` and the attempt is itself recorded via the OS Event Log path.

---

### 2.8 Contract CTR-004: Inference Request (`SYS-AI`) — trust-boundary specification (FINDING-002 repair)

* Caller: Planning Plane (`SYS-PLAN`) or Core Orchestrator (`SYS-CORE`)
* Receiver: AI Model Inference Service (`SYS-AI`)
* Transport: Named Pipe `\\.\pipe\jarvis-ai-inference` or HTTP-over-IPC

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "InferenceRequest",
  "description": "Request for model inference. Model output is an unprivileged proposal; authority decisions are never derived from model output.",
  "type": "object",
  "properties": {
    "inference_id": { "type": "string", "format": "uuid", "description": "Unique inference request identifier for deduplication" },
    "task_id": { "type": "string", "format": "uuid", "description": "Parent task context" },
    "system_prompt": { "type": "string", "description": "System role definition; never includes authority delegations" },
    "user_payload": { "type": "string", "maxLength": 65536, "description": "User intent or context; may be truncated from user input" },
    "provenance_taint": { "type": "string", "enum": ["PROVENANCE_TRUSTED_USER", "PROVENANCE_UNTRUSTED_CONTENT"], "description": "Taint label propagates through model output; untrusted-derived content cannot populate authority fields" },
    "grammar_constraint": { "type": ["string", "null"], "description": "GBNF grammar to constrain output structure; null if unconstrained" },
    "temperature": { "type": "number", "minimum": 0.0, "maximum": 1.0, "default": 0.7 },
    "timeout_ms": { "type": "integer", "maximum": 30000, "description": "Hard timeout; inference aborts and returns null on expiry" },
    "provider_hint": { "type": ["string", "null"], "description": "Preferred model provider (Claude, local fallback, etc.); router may override" }
  },
  "required": ["inference_id", "task_id", "system_prompt", "user_payload", "provenance_taint"],
  "additionalProperties": false
}
```

**Response Schema (`InferenceResponse`):**
```json
{
  "inference_id": "c4b1b369-0e42-4f05-8839-bc55b4b7a2d1",
  "status": "COMPLETED",
  "output": "...model response text...",
  "provenance_taint": "PROVENANCE_UNTRUSTED_CONTENT",
  "stop_reason": "end_turn",
  "tokens_used": 487,
  "latency_ms": 1200,
  "error": null
}
```

**Invariants:**
1. Model output is **always** labeled with `provenance_taint` from the request (either unchanged, or escalated to `UNTRUSTED` if tainted input was processed).
2. No authority-bearing field (risk tier, scope, policy, capability grant) may be populated from model output at the request's taint level.
3. Timeout enforced; inference exceeding `timeout_ms` is terminated and returns `status: TIMEOUT` with `output: null`.
4. Grammar constraints are defense-in-depth; schema validation is the primary control.

---

### 2.9 Contract CTR-005: Plan Compilation Request (`SYS-PLAN`) — trust-boundary specification (FINDING-002 repair)

* Caller: Core Orchestrator (`SYS-CORE`)
* Receiver: Plan Compiler (`SYS-PLAN`)
* Transport: Named Pipe `\\.\pipe\jarvis-plan-compile`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "PlanCompileRequest",
  "description": "Request to compile a goal into a DAG of capabilities. The compiled plan is subject to policy and verification before execution.",
  "type": "object",
  "properties": {
    "plan_id": { "type": "string", "format": "uuid" },
    "task_id": { "type": "string", "format": "uuid" },
    "goal": { "type": "string", "maxLength": 8192, "description": "User intent or extracted goal" },
    "context": {
      "type": "object",
      "properties": {
        "prior_attempts": { "type": "integer", "description": "Replan cycle count (0-indexed); max 3" },
        "constraints": { "type": "array", "description": "Excluded resources, timeout budgets, capability restrictions" },
        "environment": { "type": "object", "description": "Current system state snapshot" }
      }
    },
    "scope_discriminator": { "type": "string", "description": "Scope signature to detect scope creep on replan" }
  },
  "required": ["plan_id", "task_id", "goal"],
  "additionalProperties": false
}
```

**Response Schema (`PlanCompileResponse`):**
```json
{
  "plan_id": "c4b1b369-0e42-4f05-8839-bc55b4b7a2d1",
  "status": "SUCCESS",
  "plan_dag": {
    "nodes": [
      {
        "node_id": "node_01",
        "capability": "web.navigate",
        "parameters": { "url": "https://example.com" },
        "dependencies": [],
        "fenceability": "FENCEABLE_BROKERED"
      }
    ],
    "edges": []
  },
  "scope_delta": { "new_resources": [], "removed_resources": [], "material_change": false },
  "error": null
}
```

**Invariants:**
1. No plan node may reference a capability outside the authorized set (verified by `SYS-SEC` post-compilation).
2. Plan compilation must not mutate the authorized scope; material deltas trigger re-authorization.
3. Replan cycles are bounded; `replan_cycle >= 3` causes task termination regardless of success.

---

### 2.10 Contract CTR-011: Remote Intent (`SYS-AND`) — trust-boundary specification (FINDING-002 repair)

* Caller: Android Companion (`SYS-AND`)
* Receiver: Core Orchestrator (`SYS-CORE`)
* Transport: Noise E2EE Protocol over TCP/TLS

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "RemoteIntentRequest",
  "description": "Intent from a paired Android companion device. All fields are verified against biometric signatures and challenge bindings.",
  "type": "object",
  "properties": {
    "intent_id": { "type": "string", "format": "uuid" },
    "session_id": { "type": "string", "description": "Android session binding; verified in `SYS-AND` session state machine" },
    "user_action": { "type": "string", "enum": ["CANCEL_TASK", "CONFIRM_CHALLENGE", "ABANDON_TASK"], "description": "Authenticated user action from companion" },
    "challenge_token": { "type": "string", "description": "Cryptographic binding to the desktop challenge (for CONFIRM_CHALLENGE)" },
    "biometric_signature": { "type": "string", "description": "Fingerprint / face biometric enrolled on Android device" },
    "timestamp_utc": { "type": "string", "format": "date-time" },
    "nonce": { "type": "string", "description": "Anti-replay monotonic counter" }
  },
  "required": ["intent_id", "session_id", "user_action", "biometric_signature", "timestamp_utc", "nonce"],
  "additionalProperties": false
}
```

**Response Schema (`RemoteIntentResponse`):**
```json
{
  "intent_id": "c4b1b369-0e42-4f05-8839-bc55b4b7a2d1",
  "status": "ACCEPTED",
  "acknowledgement_sig": "ed25519:...",
  "error": null
}
```

**Invariants:**
1. Biometric signature is verified against the enrolled device fingerprint in `SYS-AND` mutual auth state.
2. Nonce is validated against a monotonic counter; any reuse is rejected with `REPLAY_DETECTED`.
3. `challenge_token` must match the binding of the active challenge on the desktop; mismatch is `CHALLENGE_BINDING_MISMATCH`.
4. Voice cancellation (via `CANCEL_TASK`) suspends in-flight work; it never grants authority or resumes tasks.
