# REQUIREMENTS TRACEABILITY MATRIX
Document Identifier: JARVIS-ARCH-032
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. END-TO-END REQUIREMENT TRACEABILITY (REQ -> TEAM)

| Req ID | Requirement Summary | Architectural Subsystem | Enforcement Mechanism | Trust Boundary | Verification Test | Owning Team |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `REQ-INT-01` | Autonomous Task Decomposition | `SYS-PLAN`, `SYS-AI` | DAG Compiler & Validator | UNTRUSTED -> TRUSTED | `FIT-06`, Planning Unit Tests | `TEAM-PLAN` |
| `REQ-INT-02` | Constrained Model Outputs | `SYS-AI` | GBNF Grammar / Schema Enforcement| PROPOSAL ENGINE | Schema Conformance Test Suite | `TEAM-AI` |
| `REQ-SEC-01` | Central Authority Model | `SYS-CORE`, `SYS-SEC`, `SYS-FCB` | Signed execution grants; sole commit authority at `SYS-FCB` (`CTR-013`) | KERNEL HOST -> FCB | Core Authority Isolation Tests; `SC-01` | `TEAM-CORE` |
| `REQ-SEC-02` | Risk-Tiered Authorization (`RISK_TIER_*`) | `SYS-SEC` | Policy Decision Point (PDP); deterministic tier recomputation; challenge binding | KERNEL HOST | Policy Matrix Test Harness; `SC-11`, `SC-12` | `TEAM-SEC` |
| `REQ-SEC-03` | Tamper-Evident Audit Logging | `SYS-AUD` | SHA-256 hash chaining, signed Merkle anchors, TPM NV rollback counter (`CTR-016`) | AUDIT KERNEL -> DISK | `FIT-03`, `SC-19`, Ledger Verification | `TEAM-AUD` |
| `REQ-EXEC-01`| Stale Worker Mitigation | `SYS-FCB` (requested by `SYS-EXEC`) | Broker-owned `OwnershipEpoch` ledger + broker-only commit path (`CTR-013`) | HOST -> FCB | `FIT-02`, `SC-01`, Race Condition Suite | `TEAM-FCB` |
| `REQ-EXEC-02`| Bounded Sandboxed Execution | `SYS-EXEC`, `SYS-TOOL` | Windows Job Objects & AppContainers | SANDBOX WORKER | Job Limit Assertion Tests | `TEAM-EXEC` |
| `REQ-WIN-01` | Semantic Desktop Automation | `SYS-WIN` | Win32 / UIA COM Tree Traversal | TRUSTED WORKER | Desktop UI Automation Harness | `TEAM-WIN` |
| `REQ-WIN-02` | Filesystem Traversal Defense | `SYS-WIN` | Canonical Path Resolvers (`GetFinalPath`)| TRUSTED WORKER | Symlink Traversal Fuzzing | `TEAM-WIN` |
| `REQ-WEB-01` | Multi-Profile Browser Isolation and Credential Confinement | `SYS-BROWSER`, `SYS-CRED` | Isolated CDP profiles, `JS_MODE_*` allowlists, broker-executed authenticated requests (`CTR-014`) | LOW INTEGRITY -> BROKER | Browser sandbox egress tests; `SC-08`, `SC-09` | `TEAM-WEB`, `TEAM-CRED` |
| `REQ-VOX-01` | Zero-Egress Wake Word | `SYS-VOX` | Local ONNX Neural Keyword Spotter | LOCAL AUDIO | Acoustic Model Fuzzing | `TEAM-VOX` |
| `REQ-VIS-01` | Screen Redaction & Understanding| `SYS-VIS` | Local PII Blurring & Spatial OCR | LOCAL VISION | PII Masking Accuracy Test | `TEAM-VIS` |
| `REQ-MEM-01` | Cryptographic Forgetting | `SYS-MEM` | SQLite Zero-Overwriting & Key Shredding| TRUSTED DATA STORE| Forensic Memory Scrape Test | `TEAM-MEM` |
| `REQ-AND-01` | E2EE Out-of-Band Auth | `SYS-AND` | Noise Protocol Handshake & Biometrics| SECURE PERIPHERAL | `FIT-08`, OOB Challenge Tests | `TEAM-AND` |
| `REQ-REL-01` | Safe Crash Recovery | `SYS-CORE`, `SYS-DATA` | SQLite WAL Reconciliation & Ambiguity | KERNEL HOST | `FIT-01`, Chaos Crash Suite | `TEAM-CORE` |

---

## 2. SECURITY AND SAFETY INVARIANT TRACEABILITY

Every invariant below is traceable end to end. A row with any column marked `NONE` would be an unresolved finding; there are none.

| Invariant ID | Invariant | Requirement | Architecture Component | Contract | Enforcement Point | Trust Boundary | Failure Mode | Recovery | Audit Event | Verification Test |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `INV-FENCE-01` | No side effect commits without a live, current `OwnershipEpoch` | `REQ-EXEC-01` | `SYS-FCB` | `CTR-013` | `SYS-FCB` ledger check at `COMMIT` | HOST -> FCB (kernel-adjacent) | Epoch stale, lease expired, broker down | `FENCE_REJECTED`; staging purged; state `AMBIGUOUS_HALTED` or clean `FAILED` | `FENCE_REJECTION`, `EPOCH_INCREMENTED` | `SC-01`, `SC-02`, `SC-03` |
| `INV-FENCE-02` | Epoch is durable before acknowledgement (crash cannot resurrect a revoked epoch) | `REQ-EXEC-01`, `REQ-REL-01` | `SYS-FCB` `fencing.db` | `CTR-013` | fsync in `SYS-FCB` before ACK | FCB -> disk | Power loss mid-increment | WAL replay; increment either committed or absent, never half-applied | `EPOCH_INCREMENTED` | `SC-10`, `SC-23` |
| `INV-AUTH-01` | Only `SYS-SEC` classifies risk; no model, plan, or manifest input can set it | `REQ-SEC-02` | `SYS-SEC` | `CTR-003` | deterministic re-computation in `SYS-SEC` | PROPOSAL -> SEC | Caller supplies a wrong tier | Supplied value ignored; classification recomputed; `SECURITY_ANOMALY_TAINT_IN_AUTHORITY_FIELD` if tainted input present | `POLICY_DECISION` | `SC-10` |
| `INV-AUTH-02` | Confirmation is bound to the exact authorized operation | `REQ-SEC-02` | `SYS-SEC`, `SYS-CORE`, `SYS-CRED` | `CTR-003`, `CTR-014` | `challenge_binding` hash compared at execution | HUMAN -> SEC | Parameters change after approval | Challenge invalidated; fresh challenge required | `CHALLENGE_REPLAY_REJECTED`, `CHALLENGE_EXPIRED` | `SC-11`, `SC-17`, `SC-18` |
| `INV-AUTH-03` | No component may widen its own authority (replan cannot self-expand) | `REQ-SEC-01` | `SYS-PLAN`, `SYS-SEC` | `CTR-005` | `ScopeDelta` evaluation before admission | PLAN -> SEC | Material delta attempted silently | Task re-enters `POLICY_EVALUATION`; prior grants revoked | `REPLAN_REAUTHORIZED`, `SCOPE_EXPANSION_REQUESTED` | `SC-18`, replan suite |
| `INV-CONF-01` | `RISK_TIER_3`/`RISK_TIER_4` always require explicit confirmation, bound to canonical action | `REQ-SEC-02` | `SYS-SEC`, `SYS-FE` | `CTR-003` | Policy Engine + modal binding | HUMAN -> CORE | Spoofed / clickjacked modal | Modal refuses; `RISK_TIER >= 3` never granted by lease | `CHALLENGE_ISSUED`, `POLICY_DECISION` | `SC-11`, anti-clickjacking suite |
| `INV-CONF-02` | A `RISK_TIER_2` action may run without a synchronous challenge only under a valid `PreApprovalLease` | `REQ-SEC-02` | `SYS-SEC` | `CTR-003` | lease predicate check | HUMAN -> SEC | Expired or exhausted lease | Falls back to per-action challenge | `PREAPPROVAL_LEASE_USED`, `..._EXPIRED` | `SC-12` |
| `INV-DEDUP-01` | Same logical operation is not performed twice unintentionally | `REQ-EXEC-01` | `SYS-EXEC` | `CTR-002` | `OperationLedger` lookup on `op_id` | WORKER -> EXEC | Duplicate delivery within a task | Attach to in-flight attempt or reuse committed result | `OP_ID_REUSED`, `INTENT_REPEAT` | `SC-06` |
| `INV-DEDUP-02` | Deliberate repetition is never silently suppressed | `REQ-EXEC-01` | `SYS-EXEC`, `SYS-SEC` | `CTR-002` | new `intent_token` forces re-performance | HUMAN -> EXEC | Repeat treated as duplicate | New token short-circuits reuse; challenge states prior count | `INTENT_REPEAT`, `MANUAL_REISSUE` | `FIT-06`, repeat-intent suite |
| `INV-IDEM-01` | Automatic retry requires runtime-verified idempotency, never a declaration | `REQ-REL-01` | `SYS-TCR`, `SYS-EXEC` | `CTR-015` | `retry_eligible` gate | AUTHOR -> SEC | Malicious manifest claims idempotency | Retry rejected; operation falls to clean failure | `ASSURANCE_DOWNGRADED`, `RETRY_ISSUED` | `FIT-04`, `FIT-05` |
| `INV-IDEM-02` | Ambiguous outcomes are never retried automatically | `REQ-REL-01` | `SYS-EXEC`, `SYS-VERIFY` | `CTR-002` | `OperationLedger` state `AMBIGUOUS` blocks retry | EXEC -> HUMAN | Network drop mid-dispatch | `AMBIGUOUS_HALTED`; human resolution only | `OP_ID_AMBIGUOUS_BLOCKED`, `AMBIGUITY_ENTERED` | `FIT-07`, `SC-28`, `SC-29` |
| `INV-ABORT-01` | Abortability claims are admitted only from `ARCHITECTURALLY_VERIFIED` evidence | `REQ-EXEC-02` | `SYS-TCR`, `SYS-EXEC` | `CTR-015` | assurance gate on abortability | AUTHOR -> SEC | Manifest overstates abortability | Claim refused; class treated as the lower verified class | `ASSURANCE_DOWNGRADED` | `FIT-04` |
| `INV-INJ-01` | No authority is derived from model output | `REQ-INT-02`, `REQ-SEC-02` | `SYS-AI`, `SYS-SEC` | `CTR-004` | taint + schema + capability + scope validation | UNTRUSTED -> PIPELINE | Successful prompt injection | Proposal denied downstream; user sees a suggestion at most | `SECURITY_ANOMALY_INJECTION_ATTEMPT` | `FIT-07`, injection corpus, `SC-26` |
| `INV-INJ-02` | Untrusted content cannot populate an authority-bearing field | `REQ-INT-02` | `SYS-AI`, `SYS-SEC` | `CTR-004` | taint validator rejects tainted authority fields | CONTENT -> DECISION | Tainted value presented as a tier, scope, or path | Rejection + audit anomaly | `SECURITY_ANOMALY_TAINT_IN_AUTHORITY_FIELD` | `SC-26` |
| `INV-BROWSER-01` | Credentials are never exposed to the Low-Integrity renderer | `REQ-WEB-01` | `SYS-CRED`, `SYS-BROWSER` | `CTR-014` | broker-owned request path + CDP allowlist | BROKER -> RENDERER | Renderer RCE | Attacker gets no cookie material; lease revocable | `CREDENTIAL_ACCESS_DENIED`, `CREDENTIAL_SESSION_REVOKED` | `SC-08` |
| `INV-BROWSER-02` | Authenticated state-changing requests are broker-executed and confirmation-bound | `REQ-WEB-01` | `SYS-CRED`, `SYS-SEC` | `CTR-014` | `ActionLease` body-hash binding | RENDERER -> BROKER | Malicious page POSTs | Request lacks a lease, or body hash mismatches -> refused | `CREDENTIAL_ACTION_LEASE_MINTED`, `BROWSER_STATE_CHANGE_CONFIRMED` | `FIT-08`, `SC-09` |
| `INV-IPC-01` | Every IPC peer is authenticated; bootstrap secret is never observable | `REQ-SEC-01` | `SYS-IPC`, `SYS-CORE` | `CTR-016`, IPC spec | DACL + peer verification + signature | PROCESS -> PROCESS | Rogue same-user client / token replay | Connection dropped; anomaly recorded | `SECURITY_ANOMALY_IPC_PEER`, `SECURITY_ANOMALY_BOOTSTRAP_REPLAY` | `SC-14`, `SC-15` |
| `INV-IPC-02` | Frame size is bounded and length fields are trusted only within the bound | `REQ-SEC-01` | `SYS-IPC` | `CTR-001` §1.2 | receiver pre-allocation check | NETWORK-ADJACENT -> PROCESS | Oversized frame attack | Pipe terminated; peer restarted | `SECURITY_ANOMALY_OVERSIZE_FRAME` | `SC-15` |
| `INV-AND-01` | Android authorization is biometric, bound, and non-replayable | `REQ-AND-01` | `SYS-AND`, `SYS-SEC` | `CTR-011` | challenge binding + biometric signature | DEVICE -> HOST | Compromised companion / replayed approval | Binding mismatch rejected; challenge expires | `SECURITY_ANOMALY_ANDROID_BINDING_MISMATCH` | `SC-18`, OOB suite |
| `INV-PLUGIN-01` | A plugin cannot exceed its manifest-granted sandbox | `REQ-SEC-01` | `SYS-PLUGINS` | plugin manifest | AppContainer + DACL + broker-only capability access | PLUGIN -> KERNEL | Malicious plugin | Blocked at NT boundary; plugin terminated | `PLUGIN_SANDBOX_ACL_MISMATCH` | `SC-12`, `SC-13` |
| `INV-PLUGIN-02` | A plugin cannot grant itself safety authority | `REQ-SEC-01` | `SYS-TCR` | `CTR-015` | `DECLARED` ceiling until evidence | PLUGIN -> SEC | Manifest lies about idempotency/abortability | All claims inert until verified | `ASSURANCE_ASSIGNED` | `FIT-04` |
| `INV-FS-01` | Filesystem writes stay inside canonicalized, authorized scope | `REQ-WIN-02` | `SYS-WIN`, `SYS-FCB` | `CTR-013` | canonical path resolution + broker write | WORKER -> FS | Symlink/junction/short-name bypass | Path canonicalized before authorization; write refused | `SCOPE_MISMATCH` | `SC-16`, symlink fuzz suite |
| `INV-AUDIT-01` | Every authority-bearing decision is durably recorded before it takes effect | `REQ-SEC-03` | `SYS-AUD` | `CTR-016` | synchronous append gate | ALL -> AUDIT | Append fails / disk full | Action refused; `SAFE_LOCKDOWN` | `SAFE_LOCKDOWN_ENTERED` | `FIT-03`, `SC-20` |
| `INV-AUDIT-02` | Ledger tampering and rollback are both detectable | `REQ-SEC-03` | `SYS-AUD` | `CTR-016` | hash chain + signed anchors + TPM NV counter | DISK -> AUDIT | Truncation / partial rewrite with valid chain | Counter mismatch halts startup | `AUDIT_ROLLBACK_DETECTED`, `AUDIT_ANCHOR_VERIFIED` | `FIT-03`, `SC-19` |
| `INV-AUDIT-03` | Audit key compromise has bounded, stated consequences | `REQ-SEC-03` | `SYS-AUD` | `CTR-016` | key hierarchy + rotation | KEY -> LEDGER | Anchor key theft | Re-certification detects change without rotation; degraded mode if lost | `AUDIT_KEY_ROTATED`, `AUDIT_DEGRADED_ENTERED` | `SC-20` |
| `INV-REC-01` | No task may be silently re-executed after a crash | `REQ-REL-01` | `SYS-CORE`, `SYS-REC` | `CTR-013` | restart reconciliation | CRASH -> CORE | In-flight task at crash | Classified per fenceability; ambiguous tasks need human resolution | `RECOVERY_SUMMARY`, `AMBIGUITY_ENTERED` | `FIT-01`, `SC-21` |
| `INV-REC-02` | An ambiguous task always has a defined human path out | `REQ-REL-01` | `SYS-CORE`, `SYS-FE` | `CTR-001` | resolution-action state machine | HUMAN -> CORE | Task stuck in `AMBIGUOUS_HALTED` | Five defined actions; no self-resolution ever | `AMBIGUITY_*` | `SC-22`, `SC-27` |
| `INV-SIM-01` | Simulation never relaxes authorization | `REQ-SEC-02` | `SYS-SIM`, `SYS-SEC` | `CTR-003` | simulation output is advisory only | SIM -> HUMAN | Clean simulation on a dangerous action | Confirmation still required; tier unchanged | `POLICY_DECISION` | `SC-24` |
| `INV-VER-01` | Only the Verification Plane establishes facts; commits are not success claims | `REQ-INT-01` | `SYS-VERIFY` | `CTR-013` | commit-receipt/observation cross-check | EXEC -> VERIFY | Commit lands but postcondition unmet | `UNSATISFIED`; replan or escalate; never auto-retry | `POLICY_DECISION`, `AMBIGUITY_ENTERED` | `SC-23` |
| `INV-VOX-01` | Voice input can never grant authority | `REQ-VOX-01` | `SYS-VOX`, `SYS-SEC` | voice pipeline | asymmetric cancellation rule | AUDIO -> CORE | Replayed / synthesized phrase | At worst suspension (denial of service); never an action | `VOICE_CANCEL_SUSPENDED`, `SECURITY_ANOMALY_INAUDIBLE_CARRIER` | `SC-30`, audio spoof suite |
| `INV-CLOCK-01` | Wall-clock manipulation cannot extend a lease, challenge, or token | `REQ-SEC-01` | `SYS-IPC`, `SYS-FCB`, `SYS-SEC` | `CTR-013` | monotonic elapsed time for expiry | OS -> PROCESS | Clock set backwards | Expiry never extended; challenges re-issued | `SECURITY_ANOMALY_CLOCK_DRIFT` | `SC-28` |
| `INV-LOCAL-01` | Local trust limitations are documented, not assumed away | `REQ-SEC-01` | all components | `—` (no contract: this invariant constrains stated scope, not an interface) | stated boundary (SECURITY §4.3) | SAME-USER -> CORE | Debug-privileged same-user attacker | Cannot forge authorizations, land stale commits, or rewrite the ledger silently | `SECURITY_ANOMALY_IPC_PEER` | `SC-14`, `SC-15` |

---

## 3. REPAIR-CHAIN COMPLETENESS (`F-A-01` … `F-A-03`, `XD-02`)

The repair mandate requires a ten-link chain for every valid finding: **finding → root cause → decision → authoritative component → enforcement mechanism → trust boundary → failure behaviour → recovery behaviour → audit record → verification test**. For the three CRITICAL findings and the tier-2 contradiction, the links resolve as follows. (Each cell names the document and section that carries the link; a `—` would mean an unresolved link, and there are none.)

### 3.1 `F-A-01` — stale worker commit authority

| Link | Resolution |
| :--- | :--- |
| Finding | CHANGELOG §2.1 (`F-A-01`) |
| Root cause | EXECUTION §2.1 — two enforcement points were permitted ("local check **or** authoritative wrapper"), so no single component owned the commit decision |
| Decision | ADR-019 (Fencing & Commit Broker as sole commit authority) |
| Authoritative component | `SYS-FCB` (EXECUTION §2.0, COMPONENTS §2.12) |
| Enforcement mechanism | Broker-held writable handles + durable `EpochLedger` + `CTR-013` commit protocol (`BEGIN_TXN` / `STAGE_DATA` / `COMMIT` / `ABORT`, single-use `commit_id`) |
| Trust boundary | HOST → `SYS-FCB`; workers hold proposals, never handles (EXECUTION §2.2) |
| Failure behaviour | `FENCE_REJECTED` / `SCOPE_MISMATCH` / `INDETERMINATE` (EXECUTION §2.5); `FENCEABLE_GATED` delivery-boundary limit stated; `NON_FENCEABLE_*` classes carry declared residual risk |
| Recovery behaviour | RECOVERY §4.2 per-class proof rules; staging purge; epoch increment before any resolution (STATE_MODEL §1.6 guard 2) |
| Audit record | `FENCED_COMMIT_APPLIED`, `FENCE_REJECTION`, `EPOCH_INCREMENTED`, `STAGING_PURGED` (EVENT_MODEL §2.2) |
| Verification test | `SC-01`, `SC-02`, `SC-03`, `FIT-02` (FAILURE_INJECTION §3) |

### 3.2 `F-A-02` — self-declared safety authority

| Link | Resolution |
| :--- | :--- |
| Finding | CHANGELOG §2.1 (`F-A-02`) |
| Root cause | EXECUTION/TOOLS consumed manifest fields (`idempotency_class`, `simulatable`, abortability) directly, so an untrusted author granted itself safety authority |
| Decision | ADR-021 (assurance levels + `SYS-TCR`) |
| Authoritative component | `SYS-SEC` writing `SYS-TCR` (SECURITY §5.4) |
| Enforcement mechanism | Four assurance levels with evidence requirements; `CTR-015` query; retry/simulation/abortability gates (`retry_eligible`) |
| Trust boundary | AUTHOR → `SYS-SEC` (manifest is a *claim*, never an authority) |
| Failure behaviour | Claim refused; capability held at the lower verified class; retry disabled (SECURITY §5.4 downgrade rules) |
| Recovery behaviour | Promotion only by evidence; automatic downgrade on version/signature/environment/expiry change |
| Audit record | `ASSURANCE_ASSIGNED`, `ASSURANCE_PROMOTED`, `ASSURANCE_DOWNGRADED`, `ASSURANCE_EXPIRED`, `ASSURANCE_REVOCATION_REJECTED` |
| Verification test | assurance suite, `SC-04`, `FIT-04`, `FIT-05` |

### 3.3 `F-A-03` / `F-A-13` — credentials inside the browser trust zone

| Link | Resolution |
| :--- | :--- |
| Finding | CHANGELOG §2.1 (`F-A-03`), §2.2 (`F-A-13`) |
| Root cause | SECURITY §6.1 — live session cookies were placed in a Low-Integrity renderer, and "human visual supervision" was treated as the control |
| Decision | ADR-022 (Credential Broker and authenticated automation boundary) |
| Authoritative component | `SYS-CRED` (COMPONENTS §2.13, SECURITY §6) |
| Enforcement mechanism | `SessionLease` (domain-scoped, ≤ 8 h, 15 min idle) + single-request `ActionLease` bound to `(method, canonical_url, body_sha256, session_lease_id)`; CDP cookie methods denied; no getter API |
| Trust boundary | BROKER → RENDERER (the renderer receives capability, never material) |
| Failure behaviour | Unleased or mismatched request refused; `CREDENTIAL_ACCESS_DENIED`; session revoked on suspicion |
| Recovery behaviour | Re-authentication; lease re-issuance; profile termination and fresh profile provisioning |
| Audit record | `CREDENTIAL_LEASE_ISSUED`, `CREDENTIAL_LEASE_USED`, `CREDENTIAL_ACTION_LEASE_MINTED`, `CREDENTIAL_ACCESS_DENIED`, `CREDENTIAL_SESSION_REVOKED` |
| Verification test | `SC-08`, `SC-09`; renderer-RCE blast-radius suite; body-hash binding test |

### 3.4 `XD-02` — `RISK_TIER_2` confirmation contradiction

| Link | Resolution |
| :--- | :--- |
| Finding | CHANGELOG §2.5 (`XD-02`) |
| Root cause | Two documents described the tier-2 control differently ("synchronous confirmation **or** pre-approval lease" vs "challenge for every tier ≥ 2") |
| Decision | SECURITY §2.2 — explicit `PreApprovalLease`, the only silent-tier-2 path |
| Authoritative component | `SYS-SEC` (lease issuance is itself a confirmed act) |
| Enforcement mechanism | Lease predicate at `POLICY_PREAPPROVED` transition; `max_risk_tier ≤ RISK_TIER_2`; TTL ≤ 8 h; `max_uses`; revocation list |
| Trust boundary | HUMAN → `SYS-SEC` |
| Failure behaviour | Expired/exhausted/revoked lease falls back to a per-action challenge |
| Recovery behaviour | Re-mint through a fresh `RISK_TIER_3`-equivalent confirmation; no renewal, widening, or auto-extension |
| Audit record | `PREAPPROVAL_LEASE_ISSUED`, `PREAPPROVAL_LEASE_USED`, `PREAPPROVAL_LEASE_EXPIRED`, `PREAPPROVAL_LEASE_REVOKED` |
| Verification test | `SC-12`; lease expiry, exhaustion, and revocation tests |
