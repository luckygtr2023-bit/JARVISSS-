# TAMPER-EVIDENT AUDIT LEDGER SPECIFICATION
Document Identifier: JARVIS-ARCH-022
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CRYPTOGRAPHIC HASH CHAIN ARCHITECTURE

All audit events are committed to an append-only, SHA-256 hash-chained ledger. Any retroactive modification or truncation immediately breaks the cryptographic proof.
```text
+--------------------------------------------------------------------------+
| Event N-1 |
| - Event Hash: 4a2f8c... |
+--------------------------------------------------------------------------+
|
| SHA-256(Event Data + PrevHash)
v
+--------------------------------------------------------------------------+
| Event N |
| - Sequence: 1042 |
| - Timestamp: 2025-05-18T10:14:02.124Z |
| - Event Type: CAPABILITY_INVOCATION |
| - Actor: CORE_ORCHESTRATOR |
| - Task ID: 7fa8d5e2-9b2e-4b68-b7d1-0f4930e48c77 |
| - Previous Hash: 4a2f8c... |
| - Payload Hash: e7d2b1... |
| - Current Event Hash: 9f1a3b... |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| Event N+1 |
| - Previous Hash: 9f1a3b... |
+--------------------------------------------------------------------------+
```


---

## 2. WHAT THE LEDGER DOES AND DOES NOT PROVE

Two distinct properties have historically been conflated in this document. They are now separated explicitly.

| Property | Mechanism | What it proves | What it does NOT prove |
| :--- | :--- | :--- | :--- |
| **Ledger integrity** | SHA-256 hash chain + sequence numbers within the file | No record *inside the current chain* was altered, inserted, or removed without breaking the chain | That the file is the *authentic* chain. An attacker with file write access can regenerate a wholly consistent shorter chain |
| **Historical authenticity (rollback detection) — TPM 2.0 systems** | Signed Merkle anchors + TPM 2.0 hardware monotonic counter (NV register) | That the current chain extends the last anchored state, and that the chain has not been truncated or rolled back. Rollback is **detectable** at boot: counter mismatch is proof. | Anything at all if the TPM itself is compromised (out of scope) |
| **Historical authenticity (rollback detection) — Non-TPM systems (DEGRADED SECURITY MODE)** | Signed Merkle anchors + DPAPI-protected software counter file | The current chain extends the last anchored state at the time the counter was written. **Rollback is NOT detectably prevented.** Attacker with file-write access can reset counter and rewind ledger. | Hardware-grade rollback protection. This system operates in DEGRADED SECURITY MODE and must be marked accordingly at runtime. |

**Invariant:** a valid in-file hash chain with a mismatched anchor counter is a **rollback attempt**, not a clean ledger. Both checks are mandatory; either one failing triggers `SAFE_LOCKDOWN`.

## 3. KEY CUSTODY & ANCHORING

### 3.1 Key hierarchy

| Key | Custody | Purpose | Exportable |
| :--- | :--- | :--- | :--- |
| **Root Key** (`AUDIT_ROOT_KEY`) | TPM 2.0, non-exportable, generated on-device at provisioning; private half never enters any process address space | Certifies the Anchor Signing Key; the root of all audit trust | No |
| **Anchor Signing Key** (`AUDIT_ANCHOR_KEY`) | Distinct from the machine identity key. TPM-resident, non-exportable, usable only through the TPM command interface (`NCryptSignHash`) | Signs Merkle roots | No |
| **Machine Identity Key** (`HOST_MACHINE_KEY`) | TPM-resident | Device identity, IPC peer attestation, Android pairing | No |
| **Ledger Write Key** | Not a key: append authority is a DACL + append-only file handle | Prevents truncation by ordinary processes | n/a |

`AUDIT_ANCHOR_KEY` is deliberately **separate** from `HOST_MACHINE_KEY` (F-A-08): compromise of routine device-identity operations must not yield the ability to forge anchors, and rotation of the identity key must not invalidate the historical anchor chain.

### 3.2 Anchor storage and rollback resistance

1. **Anchor record:** `{anchor_seq, merkle_root, tip_event_seq, tip_hash, signed_at, signature, key_id}`.
2. **Storage:** written to an OS-isolated anchor log file whose DACL grants write access only to the audit process, and **additionally** to a monotonic store that cannot be rewound: a TPM NV counter incremented alongside each anchor. The TPM counter is the rollback detector; the file is the convenience copy.
3. **Anchor frequency (F-A-16):** an anchor is computed on **whichever of the following occurs first**: 256 events, 5 minutes, immediately before and after any `RISK_TIER >= 2` commit, on `SAFE_LOCKDOWN` entry, and on graceful shutdown. The previous "1,000 events or 24 hours" schedule left up to a day of ledger exposed to undetectable truncation and is withdrawn.
4. **Boot-time verification:** the audit engine verifies (a) the in-file hash chain from the last anchor to the tip, (b) the signature of every anchor under `AUDIT_ANCHOR_KEY`, (c) that the TPM NV counter matches the highest `anchor_seq` on disk. Mismatch in (c) is proof of rollback regardless of chain validity.
5. **Non-TPM fallback (DEGRADED SECURITY MODE - FINDING-005 repair):** On systems where TPM 2.0 is unavailable, a software DPAPI-protected counter file provides the anchor store. This configuration is classified as **DEGRADED SECURITY MODE**: the counter is cryptographically protected but not hardware-isolated, and an attacker with file-write access can reset the counter and rewind the audit ledger. This limitation is documented in the audit log at boot as `AUDIT_COUNTER_DEGRADED_MODE`, and `RISK_TIER >= 2` dispatch includes a persistent banner indicating reduced rollback resistance. Systems with TPM 2.0 are strongly recommended; non-TPM operation is accepted only for development environments or when the residual risk is explicitly acknowledged by the operator.

### 3.3 Compromise assumptions (stated plainly)

| Compromise | Detectable? | Consequence |
| :--- | :--- | :--- |
| Ledger file modified | Yes — chain break | `SAFE_LOCKDOWN` |
| Ledger truncated / replaced with a shorter self-consistent chain | Yes — TPM NV counter mismatch | `SAFE_LOCKDOWN`; the deviation is itself recorded |
| `AUDIT_ANCHOR_KEY` compromised, root intact | Anchors forged are still **detectable** by re-certifying the key against the root key and observing that the key fingerprint changed without a recorded rotation | Rotation required; all anchors after compromise are treated as unverifiable |
| Root Key compromised | **No** | The architecture makes no claim. Historical authenticity of the whole ledger is lost; only the in-file chain remains |
| Audit process memory scraped (same-user + debug) | No | Attacker can read log content and could sign anchors as the process. Mitigated only by the root key never being in memory, and by recording anchor events in the Windows Event Log alongside |

### 3.4 Recovery behavior

* **Tamper Protocol:** if a hash mismatch, missing sequence number, invalid signature, or counter mismatch is encountered: Core halts startup and enters `SAFE_LOCKDOWN`; all capability execution is blocked; an alert is written to the Windows Event Log and raised as a high-priority system modal. Silent repair, truncation, overwrite, or "rebuild" is prohibited.
* **Key rotation:** `AUDIT_ANCHOR_KEY` is rotated on schedule (90 days), on suspected compromise, and on OS re-provisioning. Rotation is an audited event that records the old key fingerprint, the new key fingerprint, the root-key certification, and the last anchor signed by the old key. **The pre-rotation chain is never re-signed.**
* **Full key loss:** if `AUDIT_ANCHOR_KEY` is lost, the ledger remains verifiable as a chain but not as an authentic history. The system enters `AUDIT_DEGRADED` — execution continues only for `RISK_TIER_0`/`RISK_TIER_1` operations, every status display shows the degraded badge, and `RISK_TIER >= 2` dispatch is refused until the user re-provisions. The event is recorded in the ledger and the Windows Event Log.
* **Append failure (disk full, I/O error):** `SAFE_LOCKDOWN` per the existing rule; no execution continues without a durable audit record.
