# VOICE & AUDIO PROCESSING SPECIFICATION
Document Identifier: JARVIS-ARCH-014
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. VOICE PROCESSING PIPELINE
```text
+--------------------------------------------------------------------------+
| 1. HARDWARE CAPTURE & DSP |
| - Continuous circular audio ring buffer (16kHz, 16-bit PCM). |
| - Acoustic Echo Cancellation (AEC) & Noise Suppression. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 2. LOCAL WAKE-WORD ENGINE (Zero Network Egress) |
| - Lightweight ONNX model continuously evaluating wake-word probability. |
| - Power-efficient background operation; low CPU utilization (< 1%). |
+--------------------------------------------------------------------------+
| (Wake-Word Detected)
v
+--------------------------------------------------------------------------+
| 3. STREAMING SPEECH-TO-TEXT (STT) |
| - Local streaming model (Whisper.cpp) or low-latency cloud WebSocket. |
| - Emits partial transcript tokens in real-time. |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 4. BARGE-IN & INTERRUPTION DETECTOR |
| - Monitors user voice activity during active system TTS playback. |
| - Immediately halts audio output upon user speech onset (< 50ms latency).|
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 5. NEURAL TEXT-TO-SPEECH (TTS) SYNTHESIS |
| - Low-latency streaming neural synthesis engine. |
+--------------------------------------------------------------------------+
```


---

## 2. PRIVACY CONTROLS & PHYSICAL INDICATORS

1. Hardware Mute Honor: The system listens to OS-level audio device state changes and updates its internal state when hardware mute switches are toggled.
2. Visual Recording Indication: Whenever the audio pipeline captures audio beyond the local wake-word buffer, a high-contrast recording indicator is rendered on the desktop and companion HUD.
3. Voice Cancellation: see §3. A spoken cancellation phrase is a **request to suspend**, never a cryptographic authorization. It is treated asymmetrically because cancellation is the fail-safe direction of travel.

---

## 3. CANCELLATION AUTHORITY & SEMANTICS

### 3.1 What a spoken phrase proves

> A spoken "JARVIS, cancel" proves that **some audio** reached the microphone. It does **not** prove that the registered user spoke it. Voice is unauthenticated input: it can be replayed from a recording, synthesized by TTS, or injected through another process holding the audio session.

Cancellation is therefore modeled with **asymmetric authority**, which is sound because cancellation only ever *reduces* the set of permitted future actions:

| Operation risk | Voice cancel effect | Requires further authentication? |
| :--- | :--- | :--- |
| `RISK_TIER_0` / `RISK_TIER_1` | Immediate cancellation of pending work | No |
| `RISK_TIER_2` / `RISK_TIER_3` | **Immediate suspension**: stop dispatch, revoke leases at `SYS-FCB`, purge staging, freeze the task | To *resume* the task, yes. To stay suspended, no |
| `RISK_TIER_4` | Immediate suspension, plus lockout of further `RISK_TIER_4` dispatch until re-authentication | Yes, to resume |

Because suspension is always safe and always permitted, a spoofed cancellation phrase can at worst cause a denial of service. **A spoofed phrase can never cause an action to run** — no voice path can mint an authorization, confirm a challenge, or widen a scope. Speaker verification (below) may *raise* assurance for other purposes but is never what makes cancellation safe.

### 3.2 Speaker verification (optional, additive)

When enabled, the pipeline computes a speaker-embedding match against the enrolled user. A match promotes the cancellation to *authenticated cancellation* (usable for `CONFIRM_FAILED` on an ambiguous task, §3.4). A mismatch does **not** block suspension; it blocks only the authoritative resolution actions. Speaker verification is `ASSURANCE_REVIEWED`, never `ASSURANCE_RUNTIME_CONFIRMED`, and is never the sole control on a state-changing path.

### 3.3 Cancellation semantics by target

1. **Pending (not yet dispatched) nodes:** removed from the DAG; no lease was ever issued.
2. **Leased but not begun:** `SYS-FCB` epoch increment; staging purged; resource provably untouched.
3. **Executing, `FENCEABLE_BROKERED`:** epoch increment makes the pending commit impossible (`FENCE_REJECTED`); `TerminateJobObject` reaps the worker; verification confirms the resource is unchanged.
4. **Executing, `FENCEABLE_GATED` (UI input):** the Input Gate refuses further frames; input already queued in a Windows message queue cannot be recalled, so the system observes the target after the queue drains and reports `CANCELLED` or `AMBIGUOUS_HALTED`.
5. **Executing, `NON_FENCEABLE_EXTERNAL`:** dispatch cannot be recalled. State becomes `AMBIGUOUS_HALTED` unless a provider-side idempotency key or receipt proves the outcome; the user is informed that the external effect may have occurred, with the exact request digest.
6. **Already committed side effect:** cancellation is recorded as `CANCELLATION_AFTER_COMMIT`. The system does not claim reversal. It launches verification, offers the standard resolution actions (`ARCHITECTURE_STATE_MODEL.md` §1.6), and records which compensations (if any) are architecturally available.
7. **Ambiguous state:** cancellation is idempotent — it keeps the task in `AMBIGUOUS_HALTED` and never triggers a retry.
8. **Worker termination:** `TerminateJobObject` on the worker's job object; failure to die within 5 s escalates to `PROCESS_TERMINATION` on the FCB control plane and emits `WORKER_TERMINATION_FORCED`.

### 3.4 Authoritative resolution of an ambiguous task

Resolving ambiguity (`CONFIRM_COMPLETED`, `CONFIRM_FAILED`, `SAFE_REPLAN`) is a state-changing decision and therefore requires **authenticated** input: desktop confirmation modal (`RISK_TIER_2`-equivalent) or Android biometric approval (`ARCHITECTURE_ANDROID.md` §3). Voice alone may request `INSPECT` and `ABANDON`, which only ever stop or inspect work.

---

## 4. AUDIO ATTACK SURFACE

1. **Inaudible / ultrasonic command injection:** commands modulated above the audible band (or masked by noise) can reach the STT pipeline without the user hearing them. Mitigations: (a) the capture path applies a low-pass anti-alias filter at 8 kHz for the 16 kHz pipeline, which attenuates the ultrasonic band; (b) a wake-word confidence and duration envelope gate rejects the short, high-energy bursts typical of modulated carriers; (c) any command whose intent implies a side effect still traverses policy, authorization, and confirmation, so inaudible input cannot execute anything on its own; (d) sustained sub-band energy above the filter floor raises `SECURITY_ANOMALY_INAUDIBLE_CARRIER` and mutes the pipeline pending user acknowledgement. **Residual risk is stated:** a determined ultrasound attacker can still cause a spurious *proposal*, which will then hit the same deterministic barriers as any other injection.
2. **Microphone state truth:** hardware mute and OS mute are honored, and the physical recording indicator is driven by actual capture state. A software process that silently re-enables capture is a same-user threat (`ARCHITECTURE_SECURITY.md` §4.3) — the indicator reflects what JARVIS itself does, and the architecture does not claim it can defeat a malicious driver or a hijacked audio endpoint.
3. **Consistency with the pipeline diagram (§1):** the barge-in detector operates on the *local* capture buffer and can only suppress TTS playback; it never carries authority to cancel an execution. Execution cancellation is `SYS-CORE` acting on the §3 decision table.
