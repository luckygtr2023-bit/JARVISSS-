# SIMULATION & DRY-RUN ARCHITECTURE
Document Identifier: JARVIS-ARCH-020
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. THREE-CLASS SIMULATION CAPABILITY (`SIMULATION_FIDELITY_*`)

Prior to requesting user confirmation for `RISK_TIER_2` and `RISK_TIER_3` actions, the Simulation Engine predicts side effects and estimates the plan's blast radius.

```text
                   +------------------------+
                   | Candidate Action Node  |
                   +------------------------+
                               |
                               v
                   +------------------------+
                   | Simulation Class Check |
                   +------------------------+
                               |
     +-------------------------+-------------------------+
     |                         |                         |
     v                         v                         v
+------------------+ +------------------+ +------------------+
| FULLY_SIMULATABLE| |PARTIALLY_SIMULATE| | NOT_SIMULATABLE |
| - Local FS Copy | | - Browser DOM | | - Send Email |
| - Temp File Ops | | Click | | - Financial Pay |
+------------------+ +------------------+ +------------------+
| | |
v v v
+------------------+ +------------------+ +------------------+
| Execute in Staged| | Emulate in Mock | | Generate Blast- |
| Virtual Sandbox | | Headless DOM | | Radius Estimate |
+------------------+ +------------------+ +------------------+
| | |
+-------------------------+-------------------------+
|
v
+--------------------------+
| Produce Simulation Report|
| Diff: Files, Reg, Net |
+--------------------------+
```


---

## 2. SIMULATION REPORT SCHEMAS

The output of the Simulation Engine is presented directly in the human confirmation dialog:
```json
{
  "simulation_status": "SIMULATED_SUCCESS",
  "fidelity": "HIGH",
  "predicted_side_effects": {
    "files_created": ["C:\\Users\\User\\Documents\\Summary.docx"],
    "files_modified": [],
    "files_deleted": [],
    "network_endpoints": ["api.anthropic.com"],
    "estimated_cost_usd": 0.015
  },
  "uncertainty_notes": null
}
```
Invariant: A successful simulation is an informational tool for the user; it never bypasses the requirement for human authorization on high-risk operations.

---

## 3. SIMULATION AUTHORITY & LIMITS (F-A-02)

1. **Eligibility is not self-declared.** A capability is simulatable only if `SYS-TCR` reports `simulation_eligible: true`, which requires at least `ASSURANCE_REVIEWED`. A manifest's `simulatable: true` field only places the capability in the review queue; it does **not** enable simulation.
2. **Simulation never relaxes authorization.** A clean simulation is information for the human. It cannot downgrade a risk tier, satisfy a confirmation challenge, or advance a state machine past `AWAITING_CONFIRMATION`. Transition to `DISPATCHED` still requires the challenge response.
3. **Never a shortcut for `RISK_TIER_3`/`RISK_TIER_4`.** For those tiers the report is displayed *beside* the confirmation, with fidelity and uncertainty shown explicitly.
4. **Fidelity must be shown.** `SIMULATION_FIDELITY_LOW` results are labelled as estimates; a `NULL` or stale simulation is displayed as "no simulation available", never as "no side effects predicted".
5. **Simulated is not verified.** Simulation predicts; only the Verification Plane (`ARCHITECTURE_VERIFICATION.md`) establishes facts. `SIMULATED_SUCCESS` is not a postcondition.
6. **Simulation runs under the same fencing rules.** Dry-run execution writes into a disposable overlay through the `FENCEABLE_BROKERED` path; the overlay is destroyed on completion and its destruction emits `SIMULATION_OVERLAY_DESTROYED`.
