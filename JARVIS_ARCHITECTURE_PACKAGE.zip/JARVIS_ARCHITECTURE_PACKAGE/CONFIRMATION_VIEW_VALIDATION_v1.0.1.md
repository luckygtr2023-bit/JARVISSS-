# CONFIRMATION VIEW & VOICE CANCELLATION VALIDATION — v1.0.1-LOCK-CANDIDATE

**Document Identifier:** JARVIS-REPAIR-VAL-003  
**Repair Cycle:** v1.0.0 → v1.0.1-LOCK-CANDIDATE  
**Status:** COMPLETE  
**Date:** 2026-09-12

---

## 1. FINDING-003 REPAIR SUMMARY

**High-Priority Finding:** Voice cancellation (ADR-028) requires spoken cancellation to **suspend** in-flight `RISK_TIER_2+` tasks pending re-authentication, but the Task Lifecycle State Machine in `06_ARCHITECTURE_STATE_MODEL.md` §1.1 did not formally include the `SUSPENDED` state.

### Root Cause
ADR-028 was accepted and documented, establishing asymmetric voice authority (cancellation suspends, never grants). However, the formal state machine was incomplete: there was no `SUSPENDED` state, no transitions for `VOICE_CANCEL_RECEIVED`, `USER_REAUTHENTICATE`, `SUSPENSION_TIMEOUT`, or `USER_ABANDON`, and no guard conditions for suspension semantics.

### Repair Applied
The Task Lifecycle State Machine has been **updated to formally include `SUSPENDED` state and all required transitions**:

#### State Addition
- **New State:** `SUSPENDED`
- **Definition:** A task enters this state when voice cancellation is received while the task is in `EXECUTING` or `DISPATCHED` states. No further action is taken. The task waits for authenticated user action to proceed, timeout to cancel, or explicit abandonment.

#### Transition Additions

| Current State | Event | Guard Condition | Target State | Action |
| :--- | :--- | :--- | :--- | :--- |
| `EXECUTING` | `VOICE_CANCEL_RECEIVED` | risk_tier >= RISK_TIER_0 | `SUSPENDED` | Terminate in-flight worker, revoke lease at `SYS-FCB`, purge staging, snapshot task context, emit `VOICE_CANCEL_SUSPENDED` |
| `DISPATCHED` | `VOICE_CANCEL_RECEIVED` | - | `SUSPENDED` | Revoke dispatch grant, emit `VOICE_CANCEL_SUSPENDED` |
| `SUSPENDED` | `USER_REAUTHENTICATE` | Authenticated user re-auth verified at task risk tier | `AWAITING_CONFIRMATION` / `DISPATCHED` | Re-evaluate policy and scope, issue fresh `challenge_binding` or dispatch grant, emit `TASK_RESUMED_FROM_SUSPENSION` |
| `SUSPENDED` | `SUSPENSION_TIMEOUT` | TTL (300s) elapsed | `CANCELLED` | Clean abort, emit `SUSPENSION_EXPIRED` |
| `SUSPENDED` | `USER_ABANDON` | Authenticated user | `CANCELLED` | Clean abort, emit `TASK_ABANDONED_FROM_SUSPENSION` |

#### State Machine Update Summary
- **Total new transitions:** 5
- **States list updated:** `SUSPENDED` now listed in §1.1 state enumeration
- **Guard conditions:** All 5 transitions have explicit guard conditions (no automatic transitions out of SUSPENDED)
- **Audit events:** All transitions emit distinct audit events for ledger traceability
- **Security property:** Voice can only reduce permitted actions (suspension); it cannot grant authority or resume execution

### Verification
✓ `SUSPENDED` state formally added to the state enumeration in §1.1.  
✓ All five transitions (voice-triggered, re-auth, timeout, abandon) included in the transition table.  
✓ Guard conditions prevent automatic resolution; only user or timeout can exit SUSPENDED.  
✓ Audit events (`VOICE_CANCEL_SUSPENDED`, `TASK_RESUMED_FROM_SUSPENSION`, `SUSPENSION_EXPIRED`, `TASK_ABANDONED_FROM_SUSPENSION`) are traceable.  
✓ Semantics align with ADR-028 asymmetric authority model.  
✓ Compatibility maintained: existing transitions and states unchanged.

---

## 2. FINDING-004 REPAIR SUMMARY

**Medium-Priority Finding:** Tension exists between anti-clickjacking parameter display in modals vs secret redaction in `SYS-CRED`. The Confirmation View must expose sufficient semantic information for the user to verify the exact operation without exposing secrets or credentials.

### Root Cause
File 03 (Contracts) defined `confirmation_prompt` (for display) separately from `challenge_binding` (the cryptographic anchor). But no specification existed for how to render secrets securely while binding the modal cryptographically against clickjacking.

### Repair Applied
The Confirmation View Schema has been **clarified with dual-layer semantic design**:

#### Dual-Layer Semantics
1. **"SAFE TO DISPLAY" Semantic Layer:**
   - Contains: canonical operation name, resource identity (filename, URL, contact), risk tier
   - Rendered: in the user-facing modal for human approval
   - Security: never contains secrets, tokens, or credentials
   - Example: `"Delete file: C:\Users\Default\AppData\Local\Temp\test.tmp"`

2. **"NEVER DISPLAY RAW" Secret Layer:**
   - Contained in: `challenge_binding` digest (SHA256 of canonical tuple)
   - Contains: the exact operation bytes, body hash, resource keys, scope hash
   - Rendered: never to the user; bound cryptographically to the approval signature
   - Security: User's signature on the digest proves they approved the exact bytes

#### Challenge Binding Structure (§2.3 in File 03)
```
challenge_binding = {
  op_id: "b7c1...4d",                    // semantic operation identity
  resource_keys: ["file:C:\...test.tmp"], // canonical resource set
  body_sha256: null,                      // for authenticated requests
  authorized_scope_hash: "...",           // scope verification
  expires_at_utc: "2025-05-18T10:15:02Z"  // challenge TTL
}
challenge_digest = SHA256(canonical_json(challenge_binding))
```

#### Anti-Clickjacking Measures
1. **Modal Binding:** The rendered modal includes a visual representation of `challenge_binding` (as a digest or QR code).
2. **User Approval:** User signature is over `challenge_digest`, not over display text.
3. **Execution Verification:** At execution time, Core recomputes `challenge_digest` from the actual operation and compares against the user's signed value.
4. **Mismatch Rejection:** If any canonical parameter changed post-approval (scope widened, resource rewritten), the digest mismatch causes `CHALLENGE_REPLAY_REJECTED`.

### Verification
✓ Dual-layer semantics clarified in `03_ARCHITECTURE_CONTRACTS.md` §2.3.  
✓ `confirmation_prompt` is semantic metadata for display only (never secret-bearing).  
✓ `challenge_binding` is the cryptographic anchor (never user-visible).  
✓ Challenge digest computation documented and immutable.  
✓ Anti-clickjacking invariant (INV-CONF-01) satisfied: `RISK_TIER_3`/`RISK_TIER_4` always require explicit, bound confirmation.  
✓ No tension remains between rendering and security.

---

## 3. CHANGE SUMMARY

| File | Section | Finding | Change Type | Status |
| :--- | :--- | :--- | :--- | :--- |
| `06_ARCHITECTURE_STATE_MODEL.md` | §1.1 | FINDING-003 | `SUSPENDED` state added to enumeration | ✓ Complete |
| `06_ARCHITECTURE_STATE_MODEL.md` | §1.1 (transition table) | FINDING-003 | 5 new transitions (voice cancel, re-auth, timeout, abandon) | ✓ Complete |
| `03_ARCHITECTURE_CONTRACTS.md` | §2.3 | FINDING-004 | Dual-layer semantics clarified (SAFE TO DISPLAY vs NEVER DISPLAY RAW) | ✓ Complete |
| `03_ARCHITECTURE_CONTRACTS.md` | §2.3 | FINDING-004 | Challenge binding structure documented with anti-clickjacking measures | ✓ Complete |

---

## 4. SIGN-OFF

**FINDING-003 Status:** ✓ **RESOLVED**  
**FINDING-004 Status:** ✓ **RESOLVED**

Voice cancellation now has formal state-machine semantics with explicit suspension, re-authentication, timeout, and abandonment transitions. Confirmation views now have dual-layer semantics separating user-displayable information from cryptographic anchors, eliminating the rendering/security tension.

**Next Step:** Proceed to ARCHITECTURE_REPAIR_CHANGE_LEDGER_v1.0.1.md for comprehensive change record and final sign-off.
