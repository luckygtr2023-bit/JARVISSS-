# ARCHITECTURAL OPEN QUESTIONS & RESEARCH SPIKES
Document Identifier: JARVIS-ARCH-034
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. BASELINE RESEARCH SPIKES & OPEN TRADEOFFS (0.1.0-DRAFT)

The following architectural questions are actively undergoing empirical evaluation and must be resolved prior to moving the architecture from DRAFT to LOCKED baseline:

### Q-01: Local Multimodal Vision Latency vs. Cloud Privacy Tradeoff
* Affected Subsystem: `SYS-VIS`, `SYS-AI`
* Context: Real-time visual screen grounding requires parsing high-resolution desktop frames. Cloud multimodal models (e.g., Claude 3.5 Sonnet, GPT-4o) offer superior grounding accuracy but introduce network egress latency (800ms - 2500ms) and privacy concerns. Local multimodal models (e.g., LLaVA, Phi-3-Vision) offer zero egress and lower latency (200ms - 600ms on RTX 4080+) but exhibit lower spatial precision on dense UI accessibility trees.
* Architectural Impact: Determining whether visual grounding should default to local models with cloud fallback or enforce strict local-only execution for all screen analysis.
* Recommended Initial Direction: Implement a hybrid approach: Local OCR + UIA semantic tree first; if element lookup fails, execute local CV redaction before dispatching visual frame to the user-authorized model tier.

### Q-02: AppContainer vs. Hyper-V/WSL2 Containers for Untrusted Code Execution
* Affected Subsystem: `SYS-PLUGINS`, `SYS-TOOL`
* Context: Running user-authored Python or Node.js automation scripts requires heavy sandboxing. Windows AppContainers provide lightweight, native OS process isolation but share the NT kernel. Micro-VM containers (Hyper-V / WSL2 lightweight utility VMs) provide hardware-assisted kernel isolation but incur memory overhead (~500MB RAM) and cold-boot delays (~1.5s).
* Architectural Impact: Affects plugin host initialization time and host memory footprint.
* Recommended Initial Direction: Use Windows AppContainers for native compiled C++/Win32 plugins; use ephemeral WSL2 micro-containers for dynamic Python/Bash script execution.

### Q-03: TPM 2.0 Hardware Attestation for Android Companion Pairing
* Affected Subsystem: `SYS-AND`, `SYS-SEC`
* Context: Should desktop-to-Android pairing secrets be physically bound to the host PC's TPM 2.0 chip using Windows Platform Crypto Provider, or is standard Windows DPAPI software encryption sufficient?
* Architectural Impact: Binding to TPM 2.0 prevents credential extraction even if the host hard drive is forensically cloned, but increases development complexity on custom Windows desktop hardware lacking TPM configuration.
* Recommended Initial Direction: Require TPM 2.0 by default, with automatic software fallback to DPAPI on systems where hardware TPM is unavailable, logging a security warning to the audit ledger.

---

## 2. RESOLVED DURING THE AUDIT A REPAIR CYCLE

| Former question | Resolution | Where |
| :--- | :--- | :--- |
| Whether a local epoch check is sufficient, or an authoritative wrapper is required (`F-A-01`) | Resolved: neither, in isolation. A single broker (`SYS-FCB`) is the sole commit authority; local checks are advisory only. | EXECUTION §2; ADR-019 |
| Whether safety attributes can be trusted from a signed manifest (`F-A-02`) | Resolved: no. Assurance levels with evidence requirements; `SYS-SEC`-only registry. | SECURITY §5; ADR-021 |
| Whether live credentials may be held by a Low-Integrity browser (`F-A-03`) | Resolved: no. Credentials are confined to `SYS-CRED`; the renderer receives a capability. | SECURITY §6; BROWSER §4; ADR-022 |
| Whether prompt delimiters constitute a prompt-injection defense (`F-A-06`) | Resolved: no. Deterministic taint/validation pipeline is the control; delimiters are defense in depth. | AI §3; ADR-023 |
| Whether a spoken cancellation phrase is an authority (`F-A-07`) | Resolved: no. Asymmetric authority — voice suspends, never grants. | VOICE §3; ADR-028 |
| Whether "same user" may be treated as trusted (`F-A-12`, `F-A-14`) | Resolved: no. Explicit threat model plus documented limitations; key custody moved out of Core. | SECURITY §4; ADR-026 |
| Whether `AMBIGUOUS_HALTED` may auto-resolve after a timeout (`F-A-11`) | Resolved: no. Five human resolution actions only; never self-resolving. | STATE_MODEL §1.6; ADR-024 |

## 3. OPEN QUESTIONS CARRIED INTO THE NEXT BASELINE

These remain genuinely open. None of them blocks the LOCK CANDIDATE, because each has a defined, enforceable default in the current architecture; they are optimisation and hardening questions, not correctness gaps.

### Q-04: Kernel-enforced fencing (minifilter) versus broker-enforced fencing
* Affected Subsystem: `SYS-FCB`, `SYS-WIN`
* Context: The broker prevents stale commits for every fenced resource, but the broker itself is a user-mode process and therefore a single high-value target. A filesystem minifilter could enforce epochs below the broker, removing the broker-compromise path for filesystem operations.
* Architectural Impact: Trusted-computing-base size, driver signing and servicing burden, kernel stability risk, and support for non-filesystem resources (registry, process, clipboard, UI input) which a minifilter cannot cover.
* Recommended Initial Direction: Ship broker-enforced fencing (ADR-019). Revisit minifilter enforcement only if a driver budget and a kernel-security review process are established, and only for the filesystem subset.

### Q-05: `SYS-FCB` internal concurrency model
* Affected Subsystem: `SYS-FCB`
* Context: The ledger lock must be held for the epoch check and the commit application. Under high parallel dispatch this becomes the throughput ceiling. Candidate designs: single-threaded serialization, sharded ledgers per resource class, or an optimistic compare-and-swap on the epoch with a retry loop.
* Architectural Impact: Throughput ceiling and latency distribution; also affects how `FENCE_REJECTED` storms interact with circuit breakers.
* Recommended Initial Direction: Single-threaded serialization per resource class (sharded), because it is provably correct and easy to test; measure before optimizing.

### Q-06: Assurance review throughput for third-party capabilities
* Affected Subsystem: `SYS-TCR`, `TEAM-SEC`
* Context: `ASSURANCE_ARCHITECTURALLY_VERIFIED` requires human review. A large plugin ecosystem may exceed review capacity, which would keep most capabilities at `DECLARED` and disable retry for them.
* Architectural Impact: Whether retry coverage in practice is broad enough to meet reliability goals.
* Recommended Initial Direction: Automate structural verification (proving an operation takes the brokered commit path is a code-level property) while keeping human review for semantic claims (abortability, side-effect classification).

### Q-07: Cross-installation ledger portability
* Affected Subsystem: `SYS-AUD`
* Context: The anchor chain is bound to a TPM-resident key. Reinstalling the OS, replacing the TPM, or migrating a machine invalidates anchor verification, and the current rule is to treat the ledger as unverifiable.
* Architectural Impact: Forensics and support workflows on repair/replace paths.
* Recommended Initial Direction: Allow an explicit, user-confirmed export of a final anchor signed by the vendor root as a migration artefact, clearly labelled as a weaker guarantee than on-device verification.

### Q-08: `NON_FENCEABLE_EXTERNAL` compensation catalogue
* Affected Subsystem: `SYS-TOOL`, `SYS-VERIFY`
* Context: Some external operations have provider-side reversal or idempotency APIs (message recall, transaction reversal) and some do not. There is currently no declarative catalogue of compensations.
* Architectural Impact: Quality of human resolution of ambiguous tasks; the difference between "we can undo it" and "you must reconcile with the remote party".
* Recommended Initial Direction: Add an optional `compensation_plan` block to capability manifests, admitted only at `ASSURANCE_ARCHITECTURALLY_VERIFIED`, and display it during ambiguity resolution.

### Q-09: Trust-boundary contracts without a specified schema
* Affected Subsystem: `TEAM-AI`, `TEAM-PLAN`, `TEAM-AND`
* Context: `ARCHITECTURE_CONTRACTS.md` allocated `CTR-004`, `CTR-005`, `CTR-011` to owning teams. In v1.0.0-LOCK-CANDIDATE, schemas were specified in §2.8–2.10.
* **Status (v1.0.1 RESOLVED):** All three trust-boundary contracts now carry complete JSON Schema Draft 2020-12 specifications with caller/receiver, transport, request/response schemas, and invariants. See `03_ARCHITECTURE_CONTRACTS.md` §2.8, §2.9, §2.10.
* Architectural Impact: None — interfaces already existed; documentation completion only.
* Where Specified: `03_ARCHITECTURE_CONTRACTS.md` §2.8–2.10; `30_ARCHITECTURE_TEAM_BOUNDARIES.md` §1 (team chart updated)
