# JARVIS ARCHITECTURE CONTRADICTION & DISCREPANCY MATRIX

**Document Identifier:** JARVIS-AUDIT-MATRIX-001  
**Audit Baseline:** JARVIS Architecture v1.0.0-LOCK-CANDIDATE (Files 01–36)  
**Status:** COMPLETE ADVERSARIAL AUDIT  

---

## 1. EXECUTIVE OVERVIEW

This document establishes the comprehensive cross-document contradiction, discrepancy, and misalignment matrix for the JARVIS 36-document architecture specification extracted from `E:\ARCHITECTURE.txt`.

While the architecture exhibits advanced conceptual rigor in core areas (such as the Fencing & Commit Broker `SYS-FCB` and the Credential Broker `SYS-CRED`), cross-document synthesis reveals several structural contradictions, state machine gaps, unverified test mappings, and deferred normative contracts.

---

## 2. CROSS-DOCUMENT CONTRADICTION REGISTER

| Contradiction ID | Primary Affected Documents | Severity | Contradiction Summary | Architectural Impact | Current State & Resolution Path |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **CONTR-01** | `06_ARCHITECTURE_STATE_MODEL.md`<br>`15_ARCHITECTURE_VOICE.md`<br>`34_ARCHITECTURE_ADRS.md` (ADR-028) | **HIGH** | **Voice Cancellation State Machine Gap:** File 15 §3.1 and ADR-028 define asymmetric voice cancellation as an immediate **suspension** of in-flight `RISK_TIER_2+` tasks requiring explicit re-authentication to resume. However, File 06 §1.1 (Task Lifecycle State Machine) omits `SUSPENDED` / `FROZEN` from its formal state list and transition table. | A voice "cancel" event arriving during `EXECUTING` or `DISPATCHED` has no legal state transition in the formal state machine, forcing the runtime to either illegally abort (`CANCELLED`) or crash due to undefined transition. | **Contradictory / Incomplete.** Add formal state `SUSPENDED` and transitions `EXECUTING -> SUSPENDED` and `SUSPENDED -> AWAITING_CONFIRMATION` / `DISPATCHED` to File 06 §1.1. |
| **CONTR-02** | `33_ARCHITECTURE_TRACEABILITY.md`<br>`32_ARCHITECTURE_FAILURE_INJECTION.md` | **CRITICAL** | **Traceability Matrix Test Mapping Disconnect:** File 33 maps major invariants to test IDs in File 32 that test completely different subsystems (e.g., `INV-AUTH-01` mapped to `FIT-04` [AI HTTP 500]; `INV-DEDUP-01` mapped to `FIT-06` [DAG cycles]; `INV-BROWSER-01` mapped to `FIT-08` [Android disconnect]; `INV-FENCE-01` mapped to `SC-09` [Web POST]). | Traceability claims are illusory; verifying File 32 tests will pass without testing the actual security and execution invariants claimed in File 33. | **Severe Incoherence.** File 33 test mappings must be rewritten to align with actual scenario definitions in File 32 §1 and §3. |
| **CONTR-03** | `03_ARCHITECTURE_CONTRACTS.md`<br>`30_ARCHITECTURE_TEAM_BOUNDARIES.md`<br>`35_ARCHITECTURE_OPEN_QUESTIONS.md`<br>`36_ARCHITECTURE_CHANGELOG.md` | **HIGH** | **Deferred Trust-Boundary Contracts (CTR-004, CTR-005, CTR-011):** File 36 changelog item `CF-03` identified missing contract schemas as HIGH severity. Rather than providing normative schemas, the issue was relabeled as Open Question `Q-09` in File 35. File 03 lists them as "allocated" without schemas. | Subsystems crossing critical trust boundaries (`TEAM-AI`, `TEAM-PLAN`, `TEAM-AND`) have no binding JSON schemas for inference requests, plan compilation, or remote intents. | **Unresolved Gap.** Normative request/response schemas for `CTR-004`, `CTR-005`, and `CTR-011` must be drafted and placed in File 03 §2. |
| **CONTR-04** | `03_ARCHITECTURE_CONTRACTS.md`<br>`30_ARCHITECTURE_TEAM_BOUNDARIES.md` | **LOW** | **Superseded Contract Identifier Collision (CTR-012 vs CTR-016):** File 03 §1.3 and §2.7 state that `CTR-012` is superseded by `CTR-016` (Audit Append). However, File 30 §2.12 still lists `CTR-012` as the sole contract boundary for `TEAM-AUD`. | Engineering teams implementing boundaries face conflicting documentation on the normative contract ID for audit logging. | **Discrepancy.** Update File 30 §2.12 to reference `CTR-016` uniformly. |
| **CONTR-05** | `23_ARCHITECTURE_AUDIT.md`<br>`27_ARCHITECTURE_CONFIGURATION.md`<br>`31_ARCHITECTURE_THREAT_MODEL.md`<br>`34_ARCHITECTURE_ADRS.md` (ADR-027) | **MEDIUM** | **TPM Fallback & Monotonic Counter Rollback Overclaim:** File 23 §3.2 and ADR-027 state Merkle root verification provides rollback detection via hardware TPM NV monotonic counters. File 27 §2 admits fallback to DPAPI software counters on systems without TPM NV. Software counters on the same disk can be restored in a full filesystem restore, defeating rollback detection. | Rollback resistance is overclaimed for non-TPM environments without an explicit residual risk entry in the Threat Model. | **Overclaim / Inconsistency.** Update File 23 and File 31 to explicitly document the residual risk of audit rollback on non-TPM platforms. |
| **CONTR-06** | `07_ARCHITECTURE_SECURITY.md`<br>`14_ARCHITECTURE_BROWSER.md`<br>`28_ARCHITECTURE_FRONTEND_BOUNDARY.md`<br>`34_ARCHITECTURE_ADRS.md` (ADR-022) | **MEDIUM** | **Confirmation Parameter Transparency vs Secret Redaction:** File 07 §2.1 and File 28 §2 require human confirmation to display exact operation parameters to prevent UI redress / clickjacking. File 07 §6 and File 14 require secrets to never leave `SYS-CRED`. When a web automation action submits an auth token or sensitive payload, displaying the payload leaks the secret; redacting it blinds the user to what is being executed. | User either suffers credential leakage in confirmation UI or must blindly approve a redacted payload, which prompt injection can exploit. | **Design Tension / Unspecified Mechanism.** Specify a dual-layer confirmation schema in `SYS-CRED` showing destination domain, endpoint, and semantic action type with token provenance without raw secret disclosure. |

---

## 3. DETAILED CONTRADICTION PROFILES

### 3.1 Profile CONTR-01: Voice Cancellation State Representation
* **Affected Files:** `06_ARCHITECTURE_STATE_MODEL.md` (lines 14–30), `15_ARCHITECTURE_VOICE.md` (§3.1), `34_ARCHITECTURE_ADRS.md` (ADR-028)
* **Description:**
  `15_ARCHITECTURE_VOICE.md` §3.1 establishes:
  > `RISK_TIER_2 / RISK_TIER_3`: Immediate suspension: stop dispatch, revoke leases at SYS-FCB, purge staging, freeze the task. To resume the task, yes [requires authentication]. To stay suspended, no.
  > `RISK_TIER_4`: Immediate suspension, plus lockout of further RISK_TIER_4 dispatch until re-authentication.
  
  ADR-028 ratifies this: "A spoken phrase suspends execution, but resuming requires explicit confirmation."
  
  However, in `06_ARCHITECTURE_STATE_MODEL.md` §1.1:
  - Allowed states: `RECEIVED`, `PARSING`, `PLANNED`, `POLICY_EVALUATION`, `AWAITING_CONFIRMATION`, `DISPATCHED`, `EXECUTING`, `OBSERVED`, `VERIFYING`, `COMPLETED`, `FAILED`, `AMBIGUOUS_HALTED`, `CANCELLED`.
  - There is no `SUSPENDED` state.
  - The only cancellation transitions defined are `AWAITING_CONFIRMATION -> CANCELLED` and `AMBIGUITY_HALTED -> CANCELLED` (via `ABANDON`).
* **Technical Defect:**
  If an audio cancel occurs while a task is in `EXECUTING` or `DISPATCHED`, the execution engine has no valid state transition. If it transitions to `CANCELLED`, the task is permanently terminated and cannot be resumed upon re-authentication, violating ADR-028 and File 15 §3.1. If it halts in `AMBIGUOUS_HALTED`, it pollutes the ambiguity resolution queue with non-faulted tasks.

---

### 3.2 Profile CONTR-02: Traceability Matrix vs Failure Injection Catalog
* **Affected Files:** `33_ARCHITECTURE_TRACEABILITY.md` (§2), `32_ARCHITECTURE_FAILURE_INJECTION.md` (§1, §3)
* **Description:**
  `33_ARCHITECTURE_TRACEABILITY.md` contains an invariant verification table that purports to map all 32 core invariants to concrete tests in `32_ARCHITECTURE_FAILURE_INJECTION.md`.
  
  A systematic cross-referencing audit reveals extreme semantic disconnects:
  1. `INV-AUTH-01` (Risk classification authority) -> maps to `FIT-04` ("AI Model Provider: Return HTTP 500 followed by garbage token stream").
  2. `INV-DEDUP-01` (Deduplication) -> maps to `FIT-06` ("Task Planner: Inject synthetic goal that generates cyclic DAG").
  3. `INV-IDEM-01` (Runtime idempotency verification) -> maps to `FIT-04` and `FIT-05` ("Windows Pipe IPC: Inject duplicated message frame with old nonce").
  4. `INV-BROWSER-01` (Browser credential isolation) -> maps to `FIT-08` ("Android Gateway: Sever network connection during biometric confirmation").
  5. `INV-FENCE-01` (Epoch-fenced commits) -> maps to `SC-09` ("Malicious webpage issues state-changing POST") instead of `SC-01` ("Stale worker after cancellation").
  6. `INV-FENCE-02` (Durable epoch acknowledgement) -> maps to `SC-10` ("Prompt injection in a web page") and `SC-23` ("Verification failure") instead of `SC-02` ("Stale worker after Core crash").
  7. `INV-CONF-01` (Mandatory confirmation for Tier 3/4) -> maps to `SC-11` ("OCR / screenshot prompt injection").
  8. `INV-FS-01` (Filesystem boundary) -> maps to `SC-16` ("Forged authorization token").
  9. `INV-VER-01` (Verification plane supremacy) -> maps to `SC-25` ("Android companion compromise") instead of `SC-23` ("Verification failure").
* **Technical Defect:**
  The traceability matrix gives false assurance of test coverage. Anyone executing the test harness specified in `33_ARCHITECTURE_TRACEABILITY.md` will execute tests that do not evaluate the invariants they are claimed to verify.

---

### 3.3 Profile CONTR-03: Relabeled Trust-Boundary Contracts (CTR-004, CTR-005, CTR-011)
* **Affected Files:** `03_ARCHITECTURE_CONTRACTS.md` (§1.3), `35_ARCHITECTURE_OPEN_QUESTIONS.md` (`Q-09`), `36_ARCHITECTURE_CHANGELOG.md` (`CF-03`)
* **Description:**
  In `36_ARCHITECTURE_CHANGELOG.md`, audit finding `CF-03` noted that `CTR-004` through `CTR-012` were allocated to teams in `30_ARCHITECTURE_TEAM_BOUNDARIES.md` but had no schemas in `03_ARCHITECTURE_CONTRACTS.md`.
  
  The changelog claimed this was resolved by adding an ID numbering table and recording the gap as `Q-09`.
  
  `35_ARCHITECTURE_OPEN_QUESTIONS.md` (§Q-09) admits:
  > "A team can currently claim conformance to an interface that has no normative shape, which is exactly how interface drift begins. The three remaining contracts (CTR-004 model inference request, CTR-005 plan compilation, CTR-011 remote intent) do cross trust boundaries, so the gap is real rather than cosmetic."
* **Technical Defect:**
  Claiming "LOCK CANDIDATE" status with zero high-severity findings while deferring trust-boundary interface schemas into an open questions document is a governance contradiction. These schemas define how untrusted models return structured data, how planners emit DAGs, and how remote Android devices transmit user intent.

---

## 4. CONTRADICTION IMPACT MATRIX BY SUBSYSTEM

| Subsystem / Plane | Affected Documents | Contradiction Risk | Action Required Before Implementation |
| :--- | :--- | :--- | :--- |
| **Control & State Machine** | 06, 15, 34 | **HIGH** | Add `SUSPENDED` state to Task Lifecycle State Machine in File 06. |
| **Testing & Traceability** | 32, 33 | **CRITICAL** | Remap all 32 invariants in File 33 to their authentic `FIT` and `SC` scenario IDs. |
| **AI, Planning & Android IPC** | 03, 30, 35 | **HIGH** | Write normative schemas for `CTR-004`, `CTR-005`, and `CTR-011`. |
| **Audit & Storage** | 23, 27, 31, 34 | **MEDIUM** | Harmonize non-TPM rollback threat modeling across Files 23, 27, and 31. |
| **Security & Frontend UI** | 07, 14, 28, 34 | **MEDIUM** | Formalize redacted parameter confirmation schemas in `SYS-CRED`. |
