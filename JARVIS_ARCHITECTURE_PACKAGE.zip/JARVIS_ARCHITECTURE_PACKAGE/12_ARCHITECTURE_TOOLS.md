# CAPABILITY & TOOL SUBSYSTEM SPECIFICATION
Document Identifier: JARVIS-ARCH-011
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CAPABILITY MANIFEST SCHEMA

Every capability exposed to JARVIS must be defined by a strictly typed manifest. No dynamic or undeclared tool execution is permitted.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "CapabilityManifest",
  "type": "object",
  "properties": {
    "capability_id": { "type": "string", "pattern": "^[a-z0-9_]+\\.[a-z0-9_]+$" },
    "version": { "type": "string", "pattern": "^\\d+\\.\\d+\\.\\d+$" },
    "display_name": { "type": "string" },
    "description": { "type": "string" },
    "risk_tier": {
      "type": "string",
      "description": "DECLARED claim only. SYS-SEC recomputes the tier deterministically from the capability signature and canonical parameters; this field is never consumed as an authorization input (F-A-04, F-A-02).",
      "enum": ["RISK_TIER_0", "RISK_TIER_1", "RISK_TIER_2", "RISK_TIER_3", "RISK_TIER_4"]
    },
    "idempotency_class": { "type": "string", "enum": ["STRICTLY_IDEMPOTENT", "CONDITIONALLY_IDEMPOTENT", "NON_IDEMPOTENT"] },
    "side_effect_classification": { "type": "string", "enum": ["READ_ONLY", "LOCAL_FS_WRITE", "LOCAL_PROCESS_MUTATION", "NETWORK_EGRESS", "EXTERNAL_COMMUNICATION"] },
    "simulatable": { "type": "boolean" },
    "input_schema": { "type": "object" },
    "output_schema": { "type": "object" },
    "required_privilege_level": { "type": "string", "enum": ["SANDBOX_LOW", "STANDARD_MEDIUM", "ELEVATED_HIGH"] }
  },
  "required": [
    "capability_id", "version", "display_name", "risk_tier",
    "idempotency_class", "side_effect_classification",
    "simulatable", "input_schema", "output_schema"
  ]
}
```
2. SEMANTIC OPERATION IDENTITY & DEDUPLICATION

The previous design keyed deduplication on `TaskID`, which made the same logical operation distinct in every task (so "email the report" twice sent two emails) while treating two calls inside one task as identical (so an intentional repeat was suppressed). Both behaviors are wrong. Deduplication is now built on **semantic operation identity**, and `TaskID` is deliberately **not** part of the key.

### 2.1 Operation identity

```text
OperationIdentity (OpID)
  = SHA256(
      CapabilityID
      ∥ CapabilityVersion
      ∥ CanonicalJSON(CanonicalParameters)
      ∥ ResourceIdentitySet
      ∥ SideEffectClass
      ∥ ScopeDiscriminator
    )
```

| Component | Definition |
| :--- | :--- |
| `CapabilityID` + `CapabilityVersion` | Exact capability, so a version change invalidates dedup history |
| `CanonicalParameters` | Parameters normalized by the capability's declared canonicalizer: paths resolved to volume-GUID canonical form, URLs lower-cased host + normalized path, numbers normalized, key order fixed, whitespace-insignificant text folded. A capability with no declared canonicalizer is treated as `NON_DEDUPLICABLE` |
| `ResourceIdentitySet` | Sorted set of `ResourceKey`s — the *objects acted upon*, not the task that requested it |
| `SideEffectClass` | From `ARCHITECTURE_SECURITY.md` §5.6-adjacent manifest classification; prevents a read from being deduplicated against a write on the same resource |
| `ScopeDiscriminator` | Explicit per-capability discriminator that distinguishes *semantically different* operations that would otherwise collide (e.g. `smtp.send` includes the message body hash **and** the caller-declared `ThreadRef`; `payment.transfer` includes the payee + amount + invoice reference). It contains **no** task or session identifier |

`TaskID`, `session_id`, `request_id`, and worker identity are **excluded from `OpID`** and recorded only as *attribution* on the resulting ledger entry.

### 2.2 The Operation Ledger

`SYS-EXEC` (with `SYS-FCB` as the commit recorder) maintains a persistent `OperationLedger` keyed by `OpID`, surviving restarts, containing:

| Field | Meaning |
| :--- | :--- |
| `op_id` | as above |
| `state` | `EXECUTING`, `COMMITTED`, `FAILED_CLEAN`, `AMBIGUOUS`, `ABORTED` |
| `intent_token` | the confirmed human/literal intent instance that authorized it |
| `intent_instance` | monotonically increasing counter of how many times this exact operation has been intentionally performed |
| `outcome` | result digest for reuse; never raw secret-bearing payload |
| `attribution` | task, node, attempt, worker, session |
| `assurance` | assurance level at the time of execution (`ARCHITECTURE_SECURITY.md` §5.3) |
| `committed_at`, `verified_at` | timestamps |

### 2.3 Lookup policy (cross-task, by design)

1. **`EXECUTING` and OpID matches** → the caller attaches to the in-flight attempt and awaits its result. No second dispatch.
2. **`COMMITTED` and OpID matches** → the stored outcome is returned **without physical re-execution**, if and only if all of: (a) the operation is `STRICTLY_IDEMPOTENT` or `CONDITIONALLY_IDEMPOTENT` with its declared condition satisfied; (b) assurance is at least `ASSURANCE_ARCHITECTURALLY_VERIFIED`; (c) the caller did not present a new `intent_token` (see 2.4); (d) the `ResourceIdentitySet` is unchanged since the record was written (a resource that has subsequently been modified invalidates reuse).
3. **`FAILED_CLEAN` and OpID matches** → a new attempt is permitted only if the capability permits retry at its assurance level.
4. **`AMBIGUOUS` and OpID matches** → **no automatic reuse, no retry, for any class.** The operation is escalated to human resolution (`ARCHITECTURE_STATE_MODEL.md` §1.6). For `NON_FENCEABLE_EXTERNAL` classes an ambiguous record is terminal until a human resolves it.
5. **No record** → normal dispatch, and the ledger entry is created *before* the first side-effect attempt (`EXTERNAL_COMMIT_ATTEMPTED` for external classes).

### 2.4 Intentional repetition — distinguishing "same operation" from "do it again"

Deduplication must never silently suppress a deliberate repeat ("send the report again", "run the backup again").

* Every dispatched operation carries an **`intent_token`** minted when the user's intent is confirmed (or when a deterministic trigger fires, in which case the token is derived from the trigger occurrence, not the trigger definition).
* A *new* `intent_token` for an existing `OpID` means **intentional repetition**. The system: (a) does not reuse the stored result; (b) increments `intent_instance`; (c) for `RISK_TIER >= 2` or `NON_IDEMPOTENT` operations issues a fresh `ConfirmationChallenge` whose prompt states that this exact operation was already performed N times, with timestamps; (d) records `INTENT_REPEAT` in the ledger.
* A *repeated* `intent_token` (same token, same OpID) is a duplicate delivery of the same intent — deduplicated under 2.3.
* Replay protection on the token itself: tokens are single-use, expire in 120 s if unused, and are bound to `(op_id, session_id, challenge_hash)`.

### 2.5 Recovery and manual reissue

* On restart, `SYS-CORE` reconciles the `OperationLedger` with `SYS-FCB`'s `COMMIT_RECORD`s. A `COMMIT_RECORD` without a ledger terminal state promotes the entry to `COMMITTED`; a ledger `EXECUTING` with no commit record and no live lease becomes `AMBIGUOUS`.
* **Manual reissue** is the only sanctioned path to re-perform an operation recorded `AMBIGUOUS` or `COMMITTED`: an explicit user action (`CONFIRM_FAILED` + `SAFE_REPLAN`, or an explicit repeat) which mints a new `intent_token`, requires confirmation, and writes `MANUAL_REISSUE` to the ledger.
* External side effects additionally record an `external_reference` (provider idempotency key, transaction id, message id) that is presented to the user during resolution so a human can reconcile against the remote system.
