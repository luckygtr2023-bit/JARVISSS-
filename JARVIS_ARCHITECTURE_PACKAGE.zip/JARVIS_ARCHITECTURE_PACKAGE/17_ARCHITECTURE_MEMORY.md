# MEMORY & KNOWLEDGE ARCHITECTURE SPECIFICATION
Document Identifier: JARVIS-ARCH-016
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. HIERARCHICAL MEMORY TIERS

JARVIS organizes memory into four distinct operational tiers:
```text
+--------------------------------------------------------------------------+
| 1. WORKING SESSION CONTEXT (Transient / In-Memory) |
| Current conversation turns, immediate tool observations, active plan DAG.|
| Scope: Active Session | Storage: Non-pageable RAM | Retention: Session end|
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 2. EPISODIC TASK MEMORY (Short-Term / Persistent SQLite) |
| History of completed tasks, execution failures, and replan logs. |
| Scope: 30-Day Sliding Window | Storage: SQLite (WAL) | TTL Enforced |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 3. SEMANTIC USER PREFERENCES (Long-Term / Vector & Relational) |
| Stated preferences, coding styles, recurring workflows, entity records. |
| Scope: Permanent until forgotten | Storage: SQLite + Vector Index |
+--------------------------------------------------------------------------+
|
v
+--------------------------------------------------------------------------+
| 4. PROCEDURAL MEMORY (Verified Automation Workflows) |
| Compiled, deterministic DAG macros known to succeed for specific goals. |
| Scope: Permanent | Storage: Cryptographically signed plan library |
+--------------------------------------------------------------------------+
```


---

## 2. PROVENANCE & THE "FORGET" ENGINE

### 2.1 Memory Ingestion Invariant
Every long-term memory record must maintain an explicit provenance chain:
$$\text{MemoryRecord} \to \langle \text{TaskID}, \text{NodeID}, \text{OriginatingModality}, \text{Timestamp}, \text{Confidence} \rangle$$
Unverified AI assumptions or hallucinated user facts are barred from long-term memory insertion without explicit user confirmation.

### 2.1a Taint on Memory Records (F-A-06)

Every `MemoryRecord` additionally carries a `ProvenanceTaintLabel` (ARCHITECTURE_DATA_MODEL.md §3.1). Rules:

1. Taint is stored **with** the record and survives retrieval. A record whose `taint_class` is `PROVENANCE_UNTRUSTED_CONTENT` or `PROVENANCE_MODEL_OUTPUT` is returned to the planner as *tainted*, so the planner cannot use it to populate an authority-bearing field.
2. A tainted record may only be promoted to `classification: FACT` by an explicit user confirmation, recorded as `MEMORY_DECLASSIFY` with the approving actor.
3. A `SECRET_BEARING` record (for example anything derived from a clipboard read or a redacted field) forces `PRIVACY_CLASS_0_NO_EGRESS` on every subsequent model call that includes it, unless the user overrides for a single call.
4. Procedural memory (compiled DAG macros) may only be stored from a task whose verification verdict was `SATISFIED` and all of whose nodes executed under a valid `OwnershipGrant`; a macro containing a tainted parameter is stored as a template, never as a bound plan.

### 2.2 Cryptographic Deletion ("The Forget Engine")

When a user issues a command to forget an entity or interaction ("Forget my credit card details", "Delete all memory of project X"):
1. Query & Target: A combined vector and full-text search locates all matching candidate memory records.
2. Deletion Confirmation: The user approves the list of matched records.
3. Overwrite & Shred: The SQLite rows and associated vector index nodes are scrubbed with random bytes, and the local encryption key for that memory partition is rotated.
