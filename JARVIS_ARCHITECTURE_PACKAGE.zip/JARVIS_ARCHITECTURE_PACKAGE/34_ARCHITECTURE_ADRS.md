# ARCHITECTURAL DECISION RECORDS (ADRS)
Document Identifier: JARVIS-ARCH-033
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## ADR INDEX

* ADR-001: Central Core Authority Model
* ADR-002: Inter-Process Communication via Named Pipes with DACLs
* ADR-003: Multi-Process Isolated Worker Topology
* ADR-004: Fencing Epochs and Lease Tokens for Side-Effect Control
* ADR-005: Quad-Tier Action Abortability Classification
* ADR-006: Cryptographic Deduplication Identity for Idempotency *(SUPERSEDED by ADR-020; retained for history)*
* ADR-007: Decoupled Policy Decision Point and Human Confirmation
* ADR-008: Zero-Knowledge Secret Storage with Memory Pinning
* ADR-009: Hybrid Relational-Vector Storage Architecture
* ADR-010: Cryptographic Hash-Chained Audit Ledger with Merkle Anchoring
* ADR-011: Multi-Profile Process-Isolated Browser Daemon via CDP
* ADR-012: Dual-Mode Windows Automation (UI Automation + Vision Fallback)
* ADR-013: Android Companion Zero-Trust Peripheral Architecture
* ADR-014: Three-Tier Simulation Subsystem for Blast-Radius Prediction
* ADR-015: Conservative Ambiguity Recovery Protocol
* ADR-016: Provider-Agnostic LLM Routing with Constrained Decoding
* ADR-017: Windows AppContainer Sandboxing for Third-Party Plugins
* ADR-018: Separation of Execution, Observation, and Verification
* ADR-019: Fencing & Commit Broker as Sole Commit Authority *(supersedes ADR-004 §enforcement)*
* ADR-020: Semantic Operation Identity for Deduplication *(supersedes ADR-006)*
* ADR-021: Safety Assurance Levels and Trust Classification Registry
* ADR-022: Credential Broker and Authenticated Automation Boundary *(supersedes ADR-011 §credential handling)*
* ADR-023: Untrusted-Content Taint Containment *(supersedes ADR-016 §prompt-injection)*
* ADR-024: Human Resolution Actions for Ambiguous Tasks *(extends ADR-015)*
* ADR-025: Canonical Identifier Namespace Separation
* ADR-026: Local Threat Model and Documented Trust-Boundary Limitations
* ADR-027: Audit Key Hierarchy, Anchor Cadence, and Rollback Detection *(supersedes ADR-010 §key custody)*
* ADR-028: Asymmetric Authority for Voice Cancellation

---

### ADR-001: Central Core Authority Model
* Status: ACCEPTED
* Context: Modern generative AI models exhibit hallucinations, probabilistic variance, and susceptibility to prompt injection. Allowing an AI model direct access to operating system APIs or execution authority introduces unacceptable catastrophic risk.
* Decision: Establish an absolute architectural authority hierarchy: AI Proposes, Policy Authorizes, Core Executes, Sensors Observe, Verification Proves. The Core Orchestrator is the sole entity capable of generating signed execution tokens.
* Alternatives Considered:
  1. Autonomous Agent Model (AI directly invokes tool binaries): Rejected due to complete lack of deterministic safety boundaries.
  2. Rule-Based System without AI: Rejected due to inability to understand flexible natural language intent.
* Consequences: Strict security boundary; requires formal serialization and IPC overhead between planner and executor.
* Security Impact: Removes *authority* from the AI plane entirely: a model cannot execute, authorize, or self-approve. **Corrected claim (F-A-27):** this eliminates prompt-injection-to-execution *paths that depend on model authority*. It does **not** eliminate prompt injection as an attack. Injected content can still produce a misleading proposal or a well-formed but unwanted action that a user might approve. Containment therefore rests on the deterministic pipeline in ARCHITECTURE_AI.md §3 (schema, taint, capability, scope, policy, confirmation), not on the model's behaviour. The previous wording ("completely eliminates direct prompt-injection-to-execution vulnerabilities") overstated the property and is withdrawn.
* Reliability Impact: Centralized state machine enables predictable crash recovery and auditing.

### ADR-004: Fencing Epochs and Lease Tokens for Side-Effect Control
* Status: ACCEPTED — **enforcement point superseded by ADR-019** (the epoch/lease concept stands; the commit authority moves to `SYS-FCB`)
* Context: In distributed and multi-process systems, worker processes may experience latency spikes, garbage collection pauses, or network hangs. If a worker resumes execution after the Core has timed it out and reassigned the task, destructive write collisions occur.
* Decision: Require all state-modifying capabilities to validate a monotonic `OwnershipEpoch` and `grant_token` against the authoritative ledger before committing physical I/O.
* Enforcement point (ADR-019): validation is performed **inside `SYS-FCB`**, which is also the only holder of writable handles. The original text permitted "a synchronous check against the local Resource Lock Table **or** an authoritative transactional wrapper"; that ambiguity is withdrawn — a local check has no commit authority.
* Alternatives Considered: Universal Distributed Locking (Consul/ZooKeeper): Rejected as overly complex and heavy for a single-host desktop application.
* Consequences: Capability workers must implement epoch checks in their execution harnesses.
* Security & Reliability Impact: Eliminates split-brain execution and stale-worker file corruption.

### ADR-010: Cryptographic Hash-Chained Audit Ledger with Merkle Anchoring
* Status: ACCEPTED — **key custody and anchor cadence superseded by ADR-027**
* Context: Standard flat text logs can be easily modified, truncated, or deleted by compromised subprocesses or malicious actors attempting to hide unauthorized actions.
* Decision: Implement an append-only audit ledger where every event encapsulates the SHA-256 hash of its predecessor, anchored periodically by signed Merkle roots. Core boot enforces strict verification; any hash mismatch halts the system into `SAFE_LOCKDOWN`.
* Alternatives Considered: Windows Event Log exclusively: Insufficient structured querying and lack of native cryptographic hash-chaining across application-level entities.
* Consequences: Requires local signing key management; audit storage must be append-only.
* Security Impact: Provides *tamper-evident* proof. **Corrected claim:** the hash chain alone does not prove authenticity — an attacker with file-write access can regenerate a shorter, self-consistent chain. Rollback resistance therefore requires the signed anchor chain plus a monotonic TPM NV counter (ADR-027, ARCHITECTURE_AUDIT.md §2). The word "immutable" was an overclaim and is withdrawn; the accurate term is "tamper-evident with rollback detection".

---

### ADR-019: Fencing & Commit Broker as Sole Commit Authority
* Status: ACCEPTED (supersedes the enforcement-point wording of ADR-004)
* Context: The original fencing design allowed two enforcement points — "a local hardware/kernel-fenced check against the Resource Lock Table" **or** "an authoritative transactional wrapper". Two enforcement points means there is no authoritative answer to *who prevents a stale worker from committing*. A local check runs inside the very process that may have been compromised, and every adapter would independently need to be correct.
* Decision: Introduce `SYS-FCB`, the Fencing & Commit Broker — a dedicated Medium-Integrity process that (a) solely owns `OwnershipEpoch` in a durable `EpochLedger`, (b) solely holds writable handles to fenced resources, and (c) solely executes the commit protocol. Workers stage data and request commits; they cannot write. Every operation is classified `FENCEABLE_BROKERED`, `FENCEABLE_GATED`, `NON_FENCEABLE_EXTERNAL`, or `NON_FENCEABLE_KERNEL`, with the residual risk of each class stated explicitly.
* Alternatives Considered: (1) Local epoch check in each adapter — rejected: N enforcement points, all inside untrusted processes. (2) Filesystem minifilter driver enforcing epochs — rejected: requires a signed kernel driver, expands the trusted computing base, and conflicts with the no-kernel-component scope. (3) Trusted Execution Environment — rejected: not available for this workload on commodity Windows desktops.
* Consequences: All capability adapters must be rewritten against `CTR-013`; a new process joins the Job Object; every fenced write pays a staging cost (accepted: correctness over latency).
* Security Impact: Removes stale-commit as a category for `FENCEABLE_BROKERED`, and bounds it to the delivery boundary for `FENCEABLE_GATED`. Introduces a new high-value target (`SYS-FCB`), mitigated by `MicrosoftSignedOnly`, ACG/CFG, a minimal API surface, and the observation that an attacker who owns the broker already owns the machine.
* Reliability Impact: Adds a staging lifecycle requiring garbage collection; recovery must reconcile the epoch ledger with the operation ledger.

### ADR-020: Semantic Operation Identity for Deduplication
* Status: ACCEPTED (supersedes ADR-006)
* Context: Keying deduplication on `TaskID` produced two opposite failures: the same logical operation requested from two tasks was treated as distinct (duplicate emails, duplicate payments), while two deliberate calls inside one task were treated as identical (a deliberate repeat silently suppressed).
* Decision: Identity is `op_id = SHA256(capability_id ∥ version ∥ canonical_parameters ∥ resource_identity_set ∥ side_effect_class ∥ scope_discriminator)`. `TaskID`, session, request, and worker identifiers are attribution only. Deliberate repetition is expressed by minting a **new `intent_token`**, which permits re-performance and, for `RISK_TIER >= 2` or `NON_IDEMPOTENT` operations, requires a challenge stating that the operation was already performed N times. `AMBIGUOUS` records are never reused automatically, for any class.
* Alternatives Considered: (1) Keep `TaskID` and add a caller-supplied "force" flag — rejected: makes safety depend on a flag the caller controls. (2) Deduplicate on parameters alone — rejected: collides semantically distinct operations (same amount, different payee reference).
* Consequences: Every capability must declare a canonicalizer and a `scope_discriminator`; capabilities without one are `NON_DEDUPLICABLE` (a safe default).
* Security Impact: Prevents accidental double side effects across tasks; makes stored-result reuse conditional on assurance and on resource stability.
* Reliability Impact: Requires a durable cross-task `OperationLedger` and restart-time reconciliation with commit records.

### ADR-021: Safety Assurance Levels and Trust Classification Registry
* Status: ACCEPTED
* Context: Capability manifests declared `idempotency_class`, `simulatable`, and abortability, and those declarations were consumed directly by the Execution Controller — letting an untrusted third-party author grant itself safety authority.
* Decision: Four assurance levels (`ASSURANCE_DECLARED`, `ASSURANCE_REVIEWED`, `ASSURANCE_ARCHITECTURALLY_VERIFIED`, `ASSURANCE_RUNTIME_CONFIRMED`) held in `SYS-TCR`, writable only by `SYS-SEC`. Retry requires `RUNTIME_CONFIRMED`; simulation eligibility requires `REVIEWED`; abortability claims and admission to `RISK_TIER >= 3` capability sets require `ARCHITECTURALLY_VERIFIED`. Automatic downgrade on version change, signature change, environment change, expiry, or fencing-rejection evidence.
* Alternatives Considered: (1) Trust vendor signatures — rejected: a signature proves authorship, not truth. (2) Manual review only — rejected: does not scale and yields no runtime evidence.
* Consequences: A review pipeline is required for `TEAM-SEC`; capability admission becomes a gate rather than a registration.
* Security Impact: Removes self-granted safety authority; a malicious manifest can no longer obtain retry eligibility.
* Reliability Impact: Retry coverage shrinks until capabilities earn `RUNTIME_CONFIRMED` — accepted, fail-closed.

### ADR-022: Credential Broker and Authenticated Automation Boundary
* Status: ACCEPTED (supersedes the credential-handling portion of ADR-011)
* Context: The architecture placed live authenticated session cookies inside a Low-Integrity browser daemon and relied implicitly on "real-time human visual supervision" as the control. A renderer RCE would then be direct credential theft, and human attention is not an enforcement mechanism.
* Decision: All long-lived credentials and session material live in `SYS-CRED` (own process, TPM/DPAPI-bound, no getter API). The browser daemon receives a domain-scoped `SessionLease` capability and never cookie values; CDP cookie-enumeration methods are denied by an allowlist. State-changing authenticated requests are executed by `SYS-CRED`'s request proxy under an `ActionLease` bound to `(method, canonical_url, body_sha256, session_lease_id)` and require `RISK_TIER_3` confirmation.
* Alternatives Considered: (1) Encrypt cookies inside the daemon — rejected: the key would live in the same process. (2) Run the browser at Medium Integrity — rejected: widens the blast radius of a renderer exploit. (3) Ban authenticated automation entirely — rejected: it is a core product goal (G-03).
* Consequences: New process, new contract (`CTR-014`), CDP allowlist maintenance, and a confirmation UI that must display the exact request bytes.
* Security Impact: Renderer compromise no longer yields credential theft; the daemon becomes a bounded renderer driver.
* Reliability Impact: Re-authentication is required after a broker restart; leases fail closed.

### ADR-023: Untrusted-Content Taint Containment
* Status: ACCEPTED (supersedes the prompt-injection claim of ADR-016)
* Context: The architecture claimed that nonce-delimited XML blocks and "cryptographic boundary tokens" defended against prompt injection. LLM instruction-following is not a security boundary; a delimiter is a formatting convention the model may ignore.
* Decision: Untrusted content is a first-class typed entity (`ProvenanceTaintLabel`). Taint is contagious and monotone, and is cleared only by an auditable `SYS-SEC` declassification rule. Untrusted-derived values may influence proposals and never risk tier, resource scope, authorization, confirmation text, capability admission, or timing. The containment pipeline is deterministic: schema → taint → capability → scope → policy → authorization → confirmation → execution → verification.
* Alternatives Considered: (1) Instruction-hierarchy prompting — rejected: heuristic, unenforceable. (2) A separate "no-tools" model for untrusted content — rejected as the *sole* control (it still influences proposals a human may approve), retained as defense in depth.
* Consequences: Every value crossing a trust boundary must carry a label; validators must reject tainted input in authority-bearing fields.
* Security Impact: Injection cannot cross a deterministic boundary; it can still cause user-facing nuisance.
* Reliability Impact: Slight pipeline overhead; declassification rules must be maintained.

### ADR-024: Human Resolution Actions for Ambiguous Tasks
* Status: ACCEPTED (extends ADR-015)
* Context: `AMBIGUOUS_HALTED` was defined as a terminal sink with "human intervention required" but without defined actions, authorization, transitions, or downstream effects — leaving recovery unspecified in precisely the case where it matters.
* Decision: Five resolution actions (`INSPECT`, `CONFIRM_COMPLETED`, `CONFIRM_FAILED`, `SAFE_REPLAN`, `ABANDON`) with defined authorization, preconditions, transitions, downstream effects, guard conditions, and audit events. No timer, watchdog, retry policy, or model may resolve ambiguity. `CONFIRM_COMPLETED` on a `NON_FENCEABLE_EXTERNAL` node additionally requires an external reference or an explicit user attestation.
* Alternatives Considered: (1) Automatic timeout-based resolution — rejected: it is a guess and violates the ambiguity-averse axiom. (2) Direct database editing — rejected: un-auditable authority.
* Consequences: A UI surface for ambiguity resolution is required on desktop and companion.
* Security Impact: An attacker cannot wait out an ambiguity and have it silently resolved.
* Reliability Impact: Tasks may wait indefinitely; this is the intended trade.

### ADR-025: Canonical Identifier Namespace Separation
* Status: ACCEPTED
* Context: The identifier "tier" was reused for execution risk, model privacy clearance ("Privacy 0"), abortability, simulation classes, browser script modes, memory storage, and configuration precedence. `Tier 1` meant "low execution risk" in the Security document and "a memory storage tier" in the Memory document, so cross-document reasoning about a "tier" was unsafe.
* Decision: One namespace per concept — `RISK_TIER_*`, `PRIVACY_CLASS_*`, `ABORTABILITY_CLASS_*`, `ASSURANCE_*`, `JS_MODE_*`, `SIMULATION_FIDELITY_*`, `CONFIG_LEVEL_*`, `MEMORY_TIER_*` — tabulated in ARCHITECTURE_SECURITY.md §5.6, with no reuse across namespaces.
* Alternatives Considered: Retain "tier" with qualifiers — rejected: qualifiers drift under editing, which is exactly how the collision arose.
* Consequences: All 36 documents must use canonical names; the risk-tier enum changes from `TIER_2_MEDIUM_REVERSIBLE` to `RISK_TIER_2`, a contract-visible change recorded in the changelog with its migration.
* Security Impact: Removes an ambiguity class in which a privacy classification could be mistaken for an execution-risk classification.
* Reliability Impact: None material.

### ADR-026: Local Threat Model and Documented Trust-Boundary Limitations
* Status: ACCEPTED
* Context: The architecture implied "same user = trusted" without stating it. On Windows, a same-user process with debug privilege can read and modify another same-user process's memory.
* Decision: Adversary classes, addressed threats, and explicit limitations are documented in ARCHITECTURE_SECURITY.md §4. The architecture does **not** claim to prevent same-user-plus-debug memory access; it removes the *value* of that access (no long-lived secrets or signing keys in Core memory) and makes authorization tokens unforgeable at the enforcement point. `SeDebugPrivilege` holders, local administrators, and physical attackers are declared out of scope.
* Alternatives Considered: (1) Protected Process Light — unavailable without Microsoft signing; documented instead. (2) Claim immunity — rejected as false.
* Consequences: A residual-risk statement must accompany security claims in user-facing and audit documentation.
* Security Impact: Honest scoping; prevents security theatre.
* Reliability Impact: None.

### ADR-027: Audit Key Hierarchy, Anchor Cadence, and Rollback Detection
* Status: ACCEPTED (supersedes key custody and cadence in ADR-010)
* Context: Anchors were signed with "the host's private machine key" — reusing the device identity key — every 1,000 events or 24 hours, and boot verification checked only the in-file chain. That left up to a day of ledger exposed to undetectable truncation, conflated two key purposes, and never actually detected rollback.
* Decision: A key hierarchy (offline Vendor Root → TPM-resident, non-exportable Anchor Signing Key distinct from the machine identity key). Anchors are computed on whichever comes first: 256 events, 5 minutes, immediately before and after any `RISK_TIER >= 2` commit, `SAFE_LOCKDOWN` entry, or graceful shutdown. Rollback detection uses a TPM NV counter that cannot be rewound; a counter mismatch is proof of rollback regardless of chain validity. Ledger integrity and historical authenticity are documented as separate properties with separate guarantees, and root-key compromise is declared out of scope.
* Alternatives Considered: (1) Reuse the machine identity key — rejected: blast-radius coupling. (2) External timestamp authority — rejected as a baseline (requires network trust and egress); retained as an optional enhancement.
* Consequences: A TPM requirement (with a documented software fallback that lowers the rollback-resistance claim) and more frequent anchoring I/O.
* Security Impact: Rollback becomes detectable; key-compromise blast radius is scoped.
* Reliability Impact: Additional TPM interaction on the commit path, with a bounded anchoring budget so it cannot stall execution.

### ADR-028: Asymmetric Authority for Voice Cancellation
* Status: ACCEPTED (v1.0.1-LOCK-CANDIDATE repair: voice cancellation formally adds `SUSPENDED` state per FINDING-003)
* Context: The architecture stated that a spoken cancellation phrase ("JARVIS, cancel") authoritatively aborts in-flight operations. Voice is unauthenticated input — it can be replayed or synthesized — so treating it as an authority would let a recording stop work, and any later extension would let a recording start it.
* Decision: Cancellation has **asymmetric authority**, because it only ever reduces the set of permitted future actions. Voice cancellation immediately suspends work at every risk tier and never grants authority. Resolving a suspended task (`USER_REAUTHENTICATE`, `USER_ABANDON`, `SUSPENSION_TIMEOUT`) requires authenticated desktop or biometric confirmation. Optional speaker verification raises assurance for other purposes and is never the control that makes cancellation safe.
* Alternatives Considered: (1) Require biometrics for every voice cancel — rejected: harms the fail-safe direction. (2) Allow voice to confirm low-risk actions — rejected: extends authority to unauthenticated input.
* Consequences: Suspension semantics must be defined per fenceability class (§1.6 of STATE_MODEL), including the delivery-boundary limitation for UI input and the cannot-recall case for external commits. `SUSPENDED` state formally added to Task Lifecycle State Machine (ARCHITECTURE_STATE_MODEL.md §1.1).
* Security Impact: A spoofed phrase can at worst cause a denial of service (suspension, not execution).
* Reliability Impact: Users may need an authenticated step to resume a suspended task.
