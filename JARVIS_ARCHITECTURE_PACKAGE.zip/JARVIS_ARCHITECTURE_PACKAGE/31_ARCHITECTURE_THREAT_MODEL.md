# COMPREHENSIVE SYSTEM THREAT MODEL
Document Identifier: JARVIS-ARCH-030
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. STRIDE-AI THREAT MATRIX

The architecture defends against 24 originally enumerated adversarial threats across the AI, Operating System, Network, and Memory vectors; §3 adds 22 further threats (`THR-25` … `THR-46`) identified during the Audit A repair cycle, together with the residual risks the architecture explicitly does **not** claim to eliminate.

| Threat ID | Threat Vector | Target Subsystem | Architectural Defense | Residual Risk | Verification Method |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `THR-01` | Prompt Injection via Malicious Webpage | `SYS-AI`, `SYS-PLAN` | Structural XML encapsulation; strict GBNF schema decoding; non-authoritative AI. | Model refusal hallucination. | Failure-injection suite: Web injection harness. |
| `THR-02` | Stale Worker Write Race Condition | `SYS-EXEC`, `SYS-TOOL` | Monotonic `OwnershipEpoch` fencing tokens validated pre-write. | Delayed read locks. | Race condition injector: Delayed worker write. |
| `THR-03` | Silent Audit Ledger Tampering | `SYS-AUD` | SHA-256 hash chaining; periodic signed Merkle anchors; fail-stop lockdown. | Block device rollback. | Byte-corruption test of audit ledger file. |
| `THR-04` | Malicious Plugin Sandbox Escape | `SYS-PLUGINS` | Windows AppContainer isolation; zero direct OS API handles; restricted DACLs. | 0-day Windows kernel bug.| Automated container escape test suite. |
| `THR-05` | Forged User Confirmation via Clickjack | `SYS-FE`, `SYS-SEC` | Topmost secure window overlays; randomized interaction targets; focus validation. | Physical human error. | Focus-stealing and mouse-event injection tests. |
| `THR-06` | Android Companion Man-in-the-Middle | `SYS-AND` | Noise Protocol E2EE with out-of-band pinned Ed25519 public keys. | Compromised Android OS. | TLS/Noise packet tampering test harness. |
| `THR-07` | Filesystem Symlink Traversal Attack | `SYS-WIN`, `SYS-TOOL` | Kernel path canonicalization via `GetFinalPathNameByHandleW`. | NTFS lock contention. | Path-traversal fuzzing (`..\..`, junctions). |
| `THR-08` | Zombie Worker Surviving Core Crash | `SYS-EXEC` | Windows Job Objects configured with `KillOnJobClose`; startup PID sweep. | Slow OS process teardown.| Core kill -9 stress test. |
| `THR-09` | Secret Exfiltration via Outbound Prompts | `SYS-AI`, `SYS-NET` | In-memory Aho-Corasick secret scrubber; DPAPI-bound key isolation. | Novel representation of key.| Prompt egress scanner audit. |
| `THR-10` | Memory Poisoning via Untrusted Chat | `SYS-MEM` | Explicit provenance tracking; unverified assertions barred from long-term memory. | Subtle user preference drift.| Memory poison insertion test. |
| `THR-11` | Denial of Service via Resource Exhaustion| `SYS-EXEC` | Hard Job Object memory limits; per-task timeout budgets; rate limiters. | Temporary task queue delay.| Fork-bomb / memory-leak tool injection. |
| `THR-12` | Ambiguous Re-execution of Financial Tool | `SYS-CORE`, `SYS-PLAN`| Strict non-idempotent deduplication keys; automatic transition to `AMBIGUOUS_HALTED`.| User manual retry delay. | Network drop during HTTP POST test. |
| `THR-13` | UI Automation Desynchronization | `SYS-WIN`, `SYS-VIS` | Semantic UIA validation coupled with OCR spatial visual fallback. | Flashing UI/dynamic animations.| Dynamic UI repositioning test. |
| `THR-14` | Insecure IPC Client Spoofing | `SYS-IPC` | Client PID validation, binary digital signature, and DACL pipe checks. | Local Administrator rootkit.| Rogue named pipe connection attempt. |
| `THR-15` | Malicious Audio Ingestion (Ultrasonic) | `SYS-VOX` | Bandpass audio filtering (300Hz - 8kHz); explicit wake-word confirmation. | Acoustic interference. | High-frequency audio injection test. |
| `THR-16` | Configuration Downgrade Attack | `SYS-CONF` | Cryptographically signed policy manifests; immutable precedence hierarchy. | Physical disk replacement.| Tampered `policy.json` startup test. |
| `THR-17` | Infinite Replanning Loop | `SYS-PLAN` | Hard ceiling on replan attempts (max 3); cycle detection algorithms. | Task premature termination. | Cyclic DAG failure injection. |
| `THR-18` | Screen Capture Data Leak (Passwords) | `SYS-VIS` | Local CV/OCR PII redaction engine with Gaussian blurring before routing. | Unrecognized custom UI fields. | Screen capture with mock password fields. |
| `THR-19` | Replay Attack on Remote Intent | `SYS-AND`, `SYS-IPC` | Monotonic 64-bit sequence counters; sliding nonce cache (300s window). | Local clock skew. | IPC packet replay injection. |
| `THR-20` | Browser DOM Script Injection (XSS) | `SYS-BROWSER` | Strip `<script>`, `<iframe>`; execute in isolated headless CDP sandbox. | Dynamic DOM mutation tricks.| Injected XSS payload test suite. |
| `THR-21` | Clipboard Hijacking & Data Leak | `SYS-TOOL`, `SYS-SEC` | Scoped clipboard access; auto-clear clipboard timers for sensitive data. | Third-party clipboard spy. | Clipboard read/write fuzzing. |
| `THR-22` | Elevation of Privilege via UAC Bypass | `SYS-WIN`, `SYS-SEC` | Core runs as Standard User; elevation delegated strictly to out-of-process UAC. | Social engineering of user. | Mock UAC trigger validation. |
| `THR-23` | Database Corruption via Power Cut | `SYS-DATA` | SQLite WAL mode with synchronous=NORMAL; cold boot `integrity_check`. | Storage hardware failure. | Power-loss simulation / WAL kill test. |
| `THR-24` | Model Provider Outage / Token Starvation| `SYS-AI` | Provider-agnostic router; local model circuit-breaker fallback. | Degraded reasoning capacity. | Synthetic 503 provider injection. |

---

## 3. THREAT-MODEL ADDITIONS FOR THE REPAIRED ARCHITECTURE (Audit A)

The STRIDE-AI matrix in §1 remains valid. The following vectors were identified during the Audit A repair cycle and now carry explicit defenses rather than implied ones.

| Threat ID | Threat Vector | Target Subsystem | Architectural Defense | Residual Risk | Verification Method |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `THR-25` | Stale worker commits after revocation | `SYS-FCB` | Sole-commit authority; workers hold no write handles; durable epoch ledger | Broker compromise only | Scenario 1, 2, 3; `FIT-02` |
| `THR-26` | Commit lands at the delivery boundary (UI input) | `SYS-FCB` Input Gate | Input Gate serialization + mandatory post-action observation | Input already queued cannot be recalled | Scenario 30; UI race suite |
| `THR-27` | Self-declared safety attributes in a capability manifest | `SYS-TCR` | Assurance levels; `SYS-SEC`-only write authority; automatic downgrade | Reviewer error | Scenario 4; assurance suite |
| `THR-28` | Credential theft through renderer RCE | `SYS-CRED`, `SYS-BROWSER` | Credentials never enter the renderer; CDP cookie methods denied; lease capability | Broker compromise | Scenario 8; renderer-RCE suite |
| `THR-29` | Malicious page issues an authenticated state change | `SYS-CRED` | `ActionLease` bound to method + URL + body hash; `RISK_TIER_3` confirmation | User approves a well-formed malicious action (social engineering) | Scenario 9; body-hash binding test |
| `THR-30` | Prompt injection via OCR / screenshot text | `SYS-VIS`, `SYS-AI` | Vision text is `PROVENANCE_UNTRUSTED_CONTENT`; taint gate before authority fields | Model produces a misleading proposal | Scenario 11 |
| `THR-31` | Replay of a verified submission acknowledgement | `SYS-IPC`, `SYS-FE` | Signed `SubmitResponse` with `response_nonce`; client rejects mismatches | None identified | Response-integrity suite |
| `THR-32` | Bootstrap handshake token captured from command line or environment | `SYS-IPC` | Inherited anonymous pipe handle only; single use; 30 s TTL; bound to pid + creation time | Same-user memory scraper (documented limitation) | Scenario 14; token-replay test |
| `THR-33` | Rogue same-user IPC client impersonating a worker or frontend | `SYS-IPC`, `SYS-CORE` | Pipe DACL, `FIRST_PIPE_INSTANCE`, peer PID/signature/integrity checks, per-worker Ed25519 signing | Debug-privileged same-user attacker | Scenario 14 |
| `THR-34` | Forged policy file with a valid-looking signature | `SYS-SEC`, config | Key hierarchy with offline root, certificate chaining, monotonic anti-downgrade counter | Root key compromise (out of scope) | Scenario 16; downgrade test |
| `THR-35` | Audit rollback: replacing the ledger with an older, self-consistent chain | `SYS-AUD` | **TPM 2.0 systems:** Monotonic NV counter verified at boot; mismatch is proof of rollback. **Non-TPM systems (DEGRADED MODE):** DPAPI-protected counter file; attacker with file-write access can reset counter and rewind ledger undetectably. | On non-TPM systems: disk image rollback cannot be detected. System marked DEGRADED SECURITY MODE at runtime. | Scenario 19; `FIT-03`; TPM vs non-TPM degraded-mode test |
| `THR-36` | Anchor signing key reuse across purposes amplifies compromise | `SYS-AUD` | Dedicated, non-exportable anchor key distinct from the machine identity key; rotation with fingerprint recording | Key loss ⇒ degraded mode | Scenario 20 |
| `THR-37` | Clock manipulation to extend a lease, challenge, or token | `SYS-IPC`, `SYS-FCB` | Monotonic elapsed time for expiry; HLC cross-check; drift anomaly | None identified | Scenario 28 |
| `THR-38` | Duplicate external side effect across separate tasks | `SYS-EXEC` | Task-independent `op_id` and the `OperationLedger` | Intersecting-but-distinct parameter sets not covered by the canonicalizer | Scenario 6; dedup suite |
| `THR-39` | Replayed voice command (recording or synthesis) to cancel or steer work | `SYS-VOX` | Asymmetric cancellation (suspend only); authority actions require authentication | Denial of service | Scenario 30; audio spoof suite |
| `THR-40` | Inaudible / ultrasonic command injection | `SYS-VOX` | Anti-alias filtering, envelope gating, carrier anomaly detection, and the fact that no voice path grants authority | A spurious proposal remains possible | Scenario 30; acoustic test rig |
| `THR-41` | Plugin reads clipboard secrets as an ambient permission | `SYS-PLUGINS` | `ClipboardReadGrant` single-use, purpose-bound, TTL <= 30 s; content never persisted; secret-bearing handling forces local-only inference | User grants a malicious purpose string without reading it | Scenario 13; clipboard suite |
| `THR-42` | Plugin writes outside its sandbox via ACL inheritance or reparse points | `SYS-PLUGINS` | Protected DACL with per-plugin container SID; reparse-point creation denied; ACL re-verified at load | None identified | Scenario 13 |
| `THR-43` | Scope creep through replanning (new capability, resource, or budget) | `SYS-PLAN`, `SYS-SEC` | `AuthorizedScope` tuple + component-wise `ScopeDelta`; material deltas force re-authorization and epoch revocation | Non-material drift accumulating into a material change is detected only at the next delta evaluation | Scenario 18; replan suite |
| `THR-44` | Ambiguity used as a denial-of-service sink | `SYS-CORE` | Ambiguity always has five defined resolution actions; UI affordance and daily reminder; no garbage collection of the record | An unattended machine can leave tasks unresolved indefinitely | Scenario 27 |
| `THR-45` | Tainted value used to satisfy an authority-bearing field | `SYS-AI`, `SYS-SEC` | Taint labels with monotone propagation; validators reject tainted authority fields | Capability schema design error | Scenario 10, 11; `SC-26` |
| `THR-46` | Oversized or malformed IPC frame used to exhaust memory | `SYS-IPC` | `MAX_FRAME_SIZE = 4 MiB` enforced before allocation; pipe terminated on violation; bulk streams on a separate chunked channel | None identified | Scenario 12; `SC-15` |

### 3.1 Accepted, documented residual risks (not "resolved")

These are recorded as limitations, not as mitigated threats. They must be reproduced verbatim in any security summary derived from this architecture.

1. **Same-user + `SeDebugPrivilege`.** A debug-privileged same-user process can read or modify JARVIS process memory. Mitigated only by removing the *value* of that access (no long-lived secrets or signing keys in Core memory; authorization verified at the enforcement point).
2. **Local administrator and kernel attackers.** Out of scope; no user-mode architecture defends against them.
3. **`NON_FENCEABLE_EXTERNAL` effects.** At-most-once dispatch and deterministic ambiguity classification are guaranteed; prevention and atomicity are **not**. The remote party may already have applied the effect.
4. **`FENCEABLE_GATED` delivery boundary.** Input already delivered to a Windows message queue cannot be recalled; a bounded race exists and is compensated by mandatory post-action observation.
5. **Audit root key compromise.** Undetectable by this architecture; historical authenticity of the ledger is lost.
6. **Human approval of a well-formed malicious action.** Confirmation is bound and canonically rendered, but the architecture cannot prevent a user from approving something harmful that is accurately described.
7. **Model proposals.** Injection cannot cross a deterministic boundary, but a misleading proposal can still reach the user.
