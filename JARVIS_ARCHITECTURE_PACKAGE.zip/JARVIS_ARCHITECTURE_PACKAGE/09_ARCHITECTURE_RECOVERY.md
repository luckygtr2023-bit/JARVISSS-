# CRASH RECOVERY & STATE RECONCILIATION
Document Identifier: JARVIS-ARCH-008
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. RECOVERY PRINCIPLES

1. Zero Silent Resumption: The system shall never blindly re-execute non-idempotent operations following a crash or restart.
2. Conservative Ambiguity Classification: Any task in-flight during a crash whose verified completion cannot be proven through sensory observation is classified as `AMBIGUOUS_HALTED`.
3. Deterministic Journal Replay: Upon startup, the Core Orchestrator reconciles its in-memory task graph strictly from the append-only SQLite WAL transaction log.

---

## 2. CRASH RECONCILIATION PROTOCOL

```text
            +----------------------------+
            |    System Boot / Restart   |
            +----------------------------+
                          |
                          v
            +----------------------------+
            |    Audit Log Hash Check    |
            +----------------------------+
                          |
             +------------+------------+
             |                         |
     (Integrity OK)             (Hash Mismatch)
             v                         v
+----------------------------+ +----------------------------+
| Scan SQLite Task Journal | | ENTER SAFE LOCKDOWN |
+----------------------------+ | Halt all execution |
| +----------------------------+
v
+-------------------------------------------------------+
| Identify Tasks in EXECUTING / DISPATCHED Status |
+-------------------------------------------------------+
|
v
+-------------------------------------------------------+
| Query Verification Plane for Target Resource State |
+-------------------------------------------------------+
|
+----------+-----------------------+
| |
(State Proved Unchanged) (State Mutated or Unknown)
v v
+----------------------------+ +----------------------------+
| Mark Task as FAILED | | Mark Task as |
| Safe to Replan | | AMBIGUOUS_HALTED |
+----------------------------+ | Human Intervention Required|
+----------------------------+
```


---

## 3. ORPHAN PROCESS & RESOURCE RECLAMATION

1. Job Object Cleanup: Because worker processes are bound to Windows Job Objects with `KillOnJobClose`, an abrupt termination of the Core process triggers the operating system kernel to automatically terminate all associated worker processes.
2. Zombie Process Sweeper (F-A-17 — race-free definition): on initialization the Core enumerates processes matching the binary signature `jarvis-worker-*.exe`. A candidate is killed **only if all** of the following hold:
   * it is not a member of any Job Object belonging to the current Core instance (checked via `IsProcessInJob`);
   * its `(pid, creation_time)` pair is absent from this boot's `SpawnRegistry` (workers are registered at `CreateProcess` time, before the process can run);
   * its bootstrap token is absent from the (unique-per-boot) token table, or the token has expired;
   * a 5-second grace window has elapsed since Core reached the reconciliation barrier, so a worker that is mid-handshake is never mistaken for a zombie.
   Kills are performed with `TerminateProcess`, each kill emits `WORKER_RECLAIMED`, and a kill that fails after two attempts escalates to `WORKER_RECLAIM_FAILED` and blocks new dispatch (`SAFE_LOCKDOWN`) rather than being ignored.
   The previous formulation ("any worker not linked to an active Core lease handle") was racy against a worker spawned milliseconds earlier and is withdrawn.
3. Staged Workspace Eviction: Uncommitted files located in `C:\ProgramData\JARVIS\Staging\` older than 3600 seconds are safely purged to prevent disk bloat.

---

## 4. AMBIGUITY RESOLUTION (F-A-11) AND EXTERNAL PROOF (F-A-24)

### 4.1 Every `AMBIGUOUS_HALTED` task is resolvable

The reconciliation protocol classifies an in-flight task as `AMBIGUOUS_HALTED` when completion cannot be proven. That classification is a *decision point*: the task record keeps its `AmbiguityRecord` and exposes the five resolution actions (`ARCHITECTURE_STATE_MODEL.md` §1.6). Recovery is therefore never a dead end; it is a bounded wait for a human decision with deterministic consequences for each choice.

### 4.2 Proof rules per fenceability class

| Class | Proof available at recovery | Result |
| :--- | :--- | :--- |
| `FENCEABLE_BROKERED` | `CommitRecord` in the epoch ledger plus resource hash observation | `COMMITTED` if a `commit_receipt` exists and the observed hash matches; `FAILED` (safe to replan) if no receipt exists and the observed hash is unchanged; otherwise `AMBIGUOUS_HALTED` |
| `FENCEABLE_GATED` | Input frames accepted by the Input Gate (durably logged) plus post-queue observation of the target UI | `COMMITTED` if the observed UI matches the postcondition; `FAILED` if the frames were never accepted; otherwise `AMBIGUOUS_HALTED` |
| `NON_FENCEABLE_EXTERNAL` | **External reference only**: provider idempotency key lookup, transaction receipt, message id, or user attestation | `COMMITTED` only with a verified receipt; otherwise `AMBIGUOUS_HALTED` and the user is shown the exact request digest and the external reference to reconcile against the remote system |
| `NON_FENCEABLE_KERNEL` | Hardware state read-back where supported | `AMBIGUOUS_HALTED`; resolution requires explicit user acknowledgement of the possible effect |

**No-invention rule:** recovery never infers success from "probably". If the proof is absent, the state stays `AMBIGUOUS_HALTED` and the human decides.

### 4.3 Restart-time reconciliation order

1. Verify the audit ledger (hash chain + anchor counter, `ARCHITECTURE_AUDIT.md` §3.2). Failure ⇒ `SAFE_LOCKDOWN`.
2. Replay `SYS-FCB`'s `fencing.db`: purge staging, rebuild epochs, list `CommitRecord`s.
3. Replay the `OperationLedger` and join it with `CommitRecord`s (ARCHITECTURE_TOOLS.md §2.5).
4. Classify each in-flight task using §4.2.
5. Emit a recovery summary `RECOVERY_SUMMARY` audit event listing every task by outcome, and surface unresolved ambiguity in the UI with the resolution actions available.
