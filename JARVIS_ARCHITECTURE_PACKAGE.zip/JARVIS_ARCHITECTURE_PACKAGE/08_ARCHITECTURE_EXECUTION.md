# EXECUTION CONTROLLER & FENCING SPECIFICATION
Document Identifier: JARVIS-ARCH-007
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. WORKER SUPERVISION & PROCESS MODEL

Capabilities never execute within the Core Orchestrator process. Execution is delegated to sandboxed child worker processes monitored via Windows Job Objects.
```text
+------------------------------------------------------------------+
| Core Orchestrator Process |
| (Medium Integrity / Host) |
+------------------------------------------------------------------+
| |
| IPC (Named Pipe) | IPC (Named Pipe)
v v
+-------------------------------+ +-------------------------------+
| Windows Worker Process | | Browser Daemon Process |
| (Low/Medium Integrity Job) | | (Low Integrity Job) |
| - Win32 Automation | | - Chromium Instance |
| - Filesystem Adapters | | - CDP Session |
+-------------------------------+ +-------------------------------+
| |
| PROPOSE (BEGIN_TXN / STAGE_DATA / COMMIT|ABORT) — NO write handles
v v
+------------------------------------------------------------------+
| Fencing & Commit Broker (SYS-FCB) — Medium Integrity |
| - Sole holder of writable resource handles |
| - Sole authority for OwnershipEpoch. |
| - Input Gate (serializes UI/CDP input under lease) |
+------------------------------------------------------------------+
```


### 1.1 Process Sandboxing & Job Limits
* Windows Job Object Limits:
  * `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`: Ensures that if the Core process crashes, all running worker processes are terminated instantly by the Windows kernel.
  * `JOB_OBJECT_LIMIT_ACTIVE_PROCESS`: Restricts worker processes from spawning arbitrary untracked subprocesses.
  * Memory Commit Limit: Hard cap per worker process (e.g., 512MB for UI workers, 2048MB for Browser daemons).

---

## 2. FENCING ENFORCEMENT: THE FENCING & COMMIT BROKER (`SYS-FCB`)

### 2.0 The single authoritative answer

> **A stale worker is prevented from physically committing a side effect by the Fencing & Commit Broker (`SYS-FCB`).**
> `SYS-FCB` is the only component holding writable handles to fenced resources and the only component permitted to mutate them. A worker holds no write authority for a fenced resource; it holds a *proposal*.

This supersedes the earlier dual-path wording ("a check against the local Resource Lock Table **or** an authoritative transactional wrapper"). There is no local check with commit authority anywhere in this architecture. The worker-side check survives only as an advisory pre-flight (`FCB_PREFLIGHT`) that reduces wasted work: it has **zero authority**, can commit nothing, and its removal would not weaken the property.

### 2.1 Why a broker rather than a local epoch check

1. A local check executes inside the same process that may have been compromised (RCE in a browser daemon, a malicious plugin host, a poisoned parser). The attacker can patch the check, the comparison, or the write itself.
2. A local check requires every adapter to be correct independently; the architecture would then have N enforcement points, i.e. N chances to fail open.
3. A single broker makes the epoch ledger, the resource handles, and the commit decision one indivisible trust unit that can be audited, fuzzed, and verified in isolation.

### 2.2 Component, process boundary, and owned state

| Property | Specification |
| :--- | :--- |
| Component ID | `SYS-FCB` |
| Process boundary | Dedicated out-of-process broker, **Medium Integrity**, child of the Core Job Object, `PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY = MicrosoftSignedOnly`, Control Flow Guard + Arbitrary Code Guard enabled |
| Control-plane endpoint | `\\.\pipe\jarvis-fcb-admin-{session_uuid}` — DACL: Core SID + Local System. Methods: `LEASE_REQUEST`, `REVOKE`, `EPOCH_QUERY`, `RECONCILE` |
| Data-plane endpoint | `\\.\pipe\jarvis-fcb-commit-{session_uuid}` — DACL: worker job SIDs (per-worker capability required per call). Methods: `BEGIN_TXN`, `STAGE_DATA`, `COMMIT`, `ABORT` only |
| Owned state | `EpochLedger` (authoritative `ResourceKey -> OwnershipEpoch`, persisted in `fencing.db` SQLite WAL), `LeaseTable`, `CommitTable`, staging tree, broker-held resource handles |
| Explicit non-responsibilities | Business logic, planning, policy decisions, model inference, network egress, reading user content, parsing untrusted documents |

**Epoch authority.** The `EpochLedger` is the sole authority for `OwnershipEpoch`. `SYS-CORE` and `SYS-SEC` may *request* an increment; they cannot mint, cache, predict, or rewind one. The earlier statement that "the Execution Controller maintains a monotonically increasing 64-bit integer `epoch_id`" is withdrawn and replaced by this table.

### 2.3 Ownership epoch semantics

* `OwnershipEpoch` is a per-`ResourceKey` monotonically increasing 64-bit counter owned exclusively by `SYS-FCB`.
* **Durability:** an increment is fsync-committed to `fencing.db` *before* the increment is acknowledged. A crash therefore cannot resurrect a revoked epoch.
* **Increment triggers:** lease issuance, lease expiry, explicit cancellation, timeout expiry, worker termination, `SYS-CORE` restart, manual revocation by the user, conflicting-write detection, and entry into `SAFE_LOCKDOWN`.
* **Monotonicity across restarts:** the ledger is the persisted source; there is no in-memory-only epoch.

### 2.4 Commit protocol — the only path to a fenced resource

Contract `CTR-013: FencedCommit` (see ARCHITECTURE_CONTRACTS.md §2.8).

1. `LEASE_REQUEST(resource_keys[], side_effect_budget)` → `SYS-FCB` allocates epochs and returns `OwnershipGrant(lease_id, resource_key, epoch_id, grant_token, expires_at)`.
2. `BEGIN_TXN(commit_id, lease_id, epoch_id, grant_token, intent_token)` → epoch is checked against the ledger; lease must be live; `intent_token` must be unused. Returns `commit_id`.
3. `STAGE_DATA(commit_id, payload)` → payload is written to `C:\ProgramData\JARVIS\Staging\{commit_id}\`, never to the target.
4. `COMMIT(commit_id, epoch_id, grant_token)` → under the ledger lock `SYS-FCB` re-validates the epoch, applies the staged payload to the target through a broker-held handle, appends `COMMIT_RECORD`, emits `FENCED_COMMIT_APPLIED`, and returns `COMMIT_APPLIED { resource_hash_after }`.
5. `ABORT(commit_id)` → staging discarded; target untouched.

**Atomicity per resource class**

| Resource class | Atomic primitive used by the broker |
| :--- | :--- |
| Workspace files | Staged temp + `ReplaceFileW` / `MoveFileEx(MOVEFILE_REPLACE_EXISTING)` — a single rename syscall |
| SQLite rows | One transaction in the owning subsystem's WAL |
| Registry values | Broker-held `HKEY` + single bounded `RegSetValueEx`; multi-value updates are staged into a hive copy and swapped with `RegReplaceKey` |
| Process lifecycle | `CreateProcess` / `TerminateProcess` issued by the broker itself |
| Clipboard | `OpenClipboard` owned by the broker; write is one empty-then-set sequence |

**Resource binding and anti-replay.** `commit_id` is bound to `(resource_key, lease_id, epoch_id, worker_id, intent_token)` and is **single-use** — consumed by the first terminal `COMMIT` or `ABORT`. Any frame presenting a mismatched `worker_id`, a consumed `commit_id`, a stale `epoch_id`, or a replayed nonce is rejected with `FENCE_REJECTED` and never reaches the target.

### 2.5 Cancellation, timeout, revocation, and worker misbehavior

| Event | Broker action | Effect on a stale worker |
| :--- | :--- | :--- |
| User or Core cancellation | `REVOKE(resource_key)`: durable epoch increment, staging purge | Every subsequent `COMMIT` is rejected `FENCE_REJECTED`; target untouched |
| Timeout | `REVOKE` + `TerminateJobObject` on the worker job | Same as above; the worker's last commit cannot land |
| Worker ignores cancellation | No resource effect. The worker may keep computing | Every commit path terminates at `SYS-FCB`. Escape requires broker compromise, not worker misbehavior |
| Conflicting writer detected | Epoch increment on the contended key; loser receives `FENCE_REJECTED` | Loser must restart from `BEGIN_TXN` with a fresh lease |

### 2.6 Crash behavior and recovery

| Failure | Behavior |
| :--- | :--- |
| `SYS-FCB` crash | Staging tree purged on restart; ledger replayed from WAL; leases are **not** auto-renewed; executions with unknown commit outcome are reported `INDETERMINATE` to `SYS-CORE` |
| `SYS-CORE` crash | Job Object `KILL_ON_JOB_CLOSE` terminates workers and the broker; on restart the ledger is reconstructed, staging discarded, and `ARCHITECTURE_RECOVERY.md` §2 reconciliation runs |
| Worker dies after `COMMIT` acked, before result delivery | The `COMMIT_RECORD` proves mutation. Verification observes the resource: `SATISFIED`, `UNSATISFIED`, or `AMBIGUOUS_HALTED`. Never silently retried |
| Power loss mid-commit | The WAL fsync boundary decides: record present → mutation treated as applied and verified; record absent → staging orphaned and purged |

### 2.7 Fenceability classes — what CAN and CANNOT be fenced

| Class | Representative operations | Enforcement | Residual risk (stated explicitly) |
| :--- | :--- | :--- | :--- |
| `FENCEABLE_BROKERED` | Workspace file write/delete, staging, registry write, SQLite row mutation, process spawn/terminate, clipboard write, capability install | `SYS-FCB` is the only holder of write handles. Stale commit is **impossible**. | Broker compromise only |
| `FENCEABLE_GATED` | UI input injection (`SendInput`, UIA `InvokePattern`), browser CDP actions, keystroke synthesis, TTS playback | All such operations serialize through the **Input Gate** inside `SYS-FCB`, which holds the input lease and refuses stale-epoch frames | Input already delivered to a Windows message queue cannot be recalled; a bounded delivery race exists between queue insertion and application effect. Compensated by mandatory post-action observation |
| `NON_FENCEABLE_EXTERNAL` | Outbound HTTP to a third party, email/SMS dispatch, payments, any effect applied by a remote party | **No pre-commit fence is possible.** Mitigation: `intent_token` exactly-once record written *before* dispatch, at-most-once dispatch, mandatory verification, forced `AMBIGUOUS_HALTED` on indeterminate outcome, human resolution required | The remote party may already have applied the effect |
| `NON_FENCEABLE_KERNEL` | Raw disk block write, OS boot configuration, firmware flash | Abort refused while in flight; requires `RISK_TIER_4` + out-of-band confirmation | Terminal hardware fault leaves state unknown |

**Honest limitation (must not be softened by later edits):** JARVIS claims *stale-commit prevention* only for `FENCEABLE_BROKERED`, and for `FENCEABLE_GATED` claims it **only up to the delivery boundary**. For `NON_FENCEABLE_*` classes the architecture claims *at-most-once dispatch* and *deterministic ambiguity classification* — it does **not** claim prevention or atomicity.

---

## 3. ABORTABILITY & TERMINATION TAXONOMY

`AbortabilityClass` is a distinct namespace (see ARCHITECTURE_SECURITY.md §5.4 for the canonical namespace table). Every capability manifest declares a class; the declaration is an **input**, not an authority — it takes effect only at the assurance level defined in ARCHITECTURE_SECURITY.md §5.

| Abortability Class | Definition | Fenceability | Recovery / Enforcement Action |
| :--- | :--- | :--- | :--- |
| `ABORTABILITY_CLASS_ARCHITECTURALLY_VERIFIED` | Native rollback/cancellation exists (transactional DB write, staged file copy) | `FENCEABLE_BROKERED` | Immediate abort; discard staging; resource provably untouched. Actionable only at assurance >= `ARCHITECTURALLY_VERIFIED` |
| `ABORTABILITY_CLASS_RUNTIME_CONFIRMED` | Execution process can be hard-killed before the target confirms (UI click still queued) | `FENCEABLE_GATED` | Hard termination via `TerminateJobObject`; broker purges pending input frames; UI state inspected via OCR to confirm cancellation |
| `ABORTABILITY_CLASS_EXTERNALLY_COMMITTED` | Effect is dispatched across a network or hardware interface | `NON_FENCEABLE_EXTERNAL` | Operation **CANNOT** be undone. `EXTERNAL_COMMIT_ATTEMPTED` is journaled before dispatch; connection loss ⇒ `AMBIGUOUS_HALTED` |
| `ABORTABILITY_CLASS_NON_ABORTABLE_CRITICAL` | Firmware, OS boot, raw disk block write | `NON_FENCEABLE_KERNEL` | Abort rejected while in flight; must await natural return or terminal hardware fault |
