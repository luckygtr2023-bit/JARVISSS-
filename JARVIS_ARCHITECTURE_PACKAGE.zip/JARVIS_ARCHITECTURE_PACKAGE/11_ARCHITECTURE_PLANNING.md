# TASK PLANNING & REPLANNING SPECIFICATION
Document Identifier: JARVIS-ARCH-010
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. THE PLANNING LIFECYCLE

The Task Planner translates unstructured natural language user goals into deterministic, validated Directed Acyclic Graphs (DAGs).
```text
Natural Language Intent: "Find the quarterly sales spreadsheet on my desktop,
calculate total expenses, and email the summary to finance."
|
v
+-------------------------------------------------------------------------+
| Structured Goal Extraction (SYS-AI) |
| Target Goal: Parse spreadsheet, compute aggregate, prepare email draft |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Candidate DAG Generation (SYS-PLAN) |
| Node 1: fs.locate("Desktop\sales.xlsx") |
| Node 2: excel.read_range(Node 1.output.path, "Expenses!A1:B50") |
| Node 3: math.sum(Node 2.output.values) |
| Node 4: email.draft(to="finance@company.com", body=Node 3.output.result)|
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Static DAG Validation: Cycle checks, parameter types, permission scopes |
+-------------------------------------------------------------------------+
|
v
+-------------------------------------------------------------------------+
| Policy Engine Authorization Matrix Evaluation |
+-------------------------------------------------------------------------+
```


---

## 2. DAG SPECIFICATION & INVARIANTS

### 2.1 Formal DAG Invariants
1. Directed Acyclic Property: $\forall u, v \in V, \text{Path}(u, v) \implies \neg \text{Path}(v, u)$. Cyclic graphs are rejected at the compilation phase.
2. Resource Non-Interference: Two concurrent nodes $N_a, N_b$ possessing no mutual dependency path cannot claim overlapping write locks on the same `ResourceKey`:
$$\text{Concurrent}(N_a, N_b) \implies \text{WriteResources}(N_a) \cap \text{WriteResources}(N_b) = \emptyset$$
3. Maximum Graph Complexity: A single plan cannot exceed 32 nodes, a maximum dependency depth of 8, or a fan-out factor of 6.

---

## 3. DYNAMIC REPLANNING BOUNDARIES

When an execution node fails or an environmental observation diverges from expected postconditions, the system triggers the Dynamic Replanner.

### 3.1 Replan Invariants & Policies
* Delta Isolation: The replanner shall only modify the subgraph downstream of the failed node. Completed and verified nodes remain immutable and are never re-executed.
* Replan Ceiling: A task is permitted a maximum of three (3) replan cycles. Upon reaching the fourth failure, the system automatically transitions to `FAILED` and escalates to the user.
* **Scope Preservation (F-A-10).** Authorization is a tuple, not a tier. Every plan binds to an `AuthorizedScope`:

```text
AuthorizedScope = {
  capability_set[]        # exact capability ids + versions authorized
  risk_tier_ceiling       # RISK_TIER_0 .. RISK_TIER_4, never raised by a replan
  resource_keys[]         # the objects the plan may touch (canonical form)
  write_scope[]           # permitted write roots (canonical paths / URL prefixes)
  side_effect_budget      # max number of committing operations, per class
  tool_identity[]         # exact tool/adapter identity (publisher + version)
  privacy_constraints[]   # PRIVACY_CLASS_* ceiling for model egress
  relevant_parameters_hash# hash of the parameters the user actually saw
}
```

  `authorized_scope_hash = SHA256(canonical_json(AuthorizedScope))` is carried on every `DispatchExecution` frame and re-checked by `SYS-FCB` at `LEASE_REQUEST` time.

* **Scope Delta evaluation.** Before a replanned sub-DAG is admitted, the Replanning Engine computes `ScopeDelta(original, replanned)` component-wise over the tuple above. Admission rules:

| Delta component | Rule |
| :--- | :--- |
| New capability, or a different capability version | **Material** — fresh `ConfirmationChallenge` required |
| Higher `risk_tier_ceiling` | **Material** — never permitted silently; fresh challenge, re-classified by `SYS-SEC` |
| New `ResourceKey` outside the declared set, or a `write_scope` expansion | **Material** — fresh challenge; path canonicalization re-run |
| `side_effect_budget` increase | **Material** — fresh challenge |
| Different `tool_identity` (publisher/version change that alters the commit path) | **Material** — fresh challenge and assurance re-check |
| Weaker `privacy_constraints` (more egress) | **Material** — fresh challenge; routed to `SYS-CRED`/redaction pipeline |
| Parameter values changing within an already-authorized enumerated domain | **Non-material** — allowed, recorded as `REPLAN_PARAMETER_DRIFT` |
| Node reordering, node removal, added read-only nodes inside scope | **Non-material** |

  A **material** delta does not merely re-prompt: the task re-enters `POLICY_EVALUATION` as a *new* authorization cycle, and the previous grants are revoked at `SYS-FCB` (epoch increments) so no in-flight commit from the old plan can land after the scope changed.
* **Authorization binding to the human decision.** The challenge hash covers `(AuthorizedScope, canonical action, body/parameter digests)`. A replan whose material delta was approved keeps the same `op_id`s only for operations that are byte-identical; anything else receives new `op_id`s and new `intent_token`s (ARCHITECTURE_TOOLS.md §2.4).
* **Replan and evidence.** Every replan writes `REPLAN_APPLIED` (non-material) or `REPLAN_REAUTHORIZED` (material) to the audit ledger with the `ScopeDelta` recorded verbatim.
