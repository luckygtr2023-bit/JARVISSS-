# CONFIGURATION & POLICY MANAGEMENT
Document Identifier: JARVIS-ARCH-026
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CONFIGURATION PRECEDENCE HIERARCHY

Configuration settings are resolved deterministically through a strict five-tier precedence hierarchy:
```text
[Level 1: Hardcoded Engine Defaults (Immutable Compiled Constants)]
|
v
[Level 2: Machine Security Policy (Cryptographically Signed JSON File)]
|
v
[Level 3: Administrator Configuration (System-Wide Protected Reg/Disk)]
|
v
[Level 4: User Preferences (Encrypted Profile Database)]
|
v
[Level 5: Session Ephemeral Overrides (In-Memory CLI/IPC Flags)]
```


* Invariant: A lower level cannot override or weaken a constraint imposed by a higher level. An ephemeral session override cannot relax a Machine Security Policy constraint.

---

## 2. SCHEMA VALIDATION & INTEGRITY SEALING

All configuration updates undergo strict JSON schema validation prior to application. Changes to Security Policy files require an accompanying digital signature file (`policy.json.sig`) verified against the system's root public key.

---

## 3. SIGNING KEYS, CUSTODY, AND ANTI-DOWNGRADE (F-A-22)

The previous text verified `policy.json.sig` against "the system's root public key" without defining custody, hierarchy, or replay handling. That is now specified.

### 3.1 Key hierarchy

| Key | Custody | Signs | Online? |
| :--- | :--- | :--- | :--- |
| **Vendor Root Key** (`VENDOR_ROOT_KEY`) | Offline / HSM at the vendor; never present on a user machine | Release signing keys, revocation lists | No |
| **Release Signing Key** (`RELEASE_SIGNING_KEY`) | Offline build infrastructure | Application binaries, installer, plugin allowlist | No |
| **Policy Signing Key** (`POLICY_SIGNING_KEY`) | Administrator-held, TPM-backed on the machine or an enterprise management host | `policy.json`, machine security policy, administrator configuration | Yes, TPM-gated |
| **Update Manifest Key** (`UPDATE_MANIFEST_KEY`) | Offline; certified by the vendor root | Update manifests, version metadata | No |

### 3.2 Verification rules

1. **Chain, not a single key.** A policy file is accepted only if `policy.json.sig` verifies under `POLICY_SIGNING_KEY` **and** that key's certificate chains to `VENDOR_ROOT_KEY` (or to a locally pinned administrator key the user explicitly installed).
2. **Pinning.** Root public keys are pinned at install time and updated only by a signed rotation artifact notarized by the offline root. There is no automatic key-discovery path.
3. **Anti-downgrade.** Every policy and update artifact carries a strictly increasing `policy_version` / `build_version`; the highest accepted value is persisted in a monotonic store (TPM NV counter where available, otherwise a DPAPI-protected counter with an integrity MAC). A correctly signed artifact whose version is *lower* than the persisted value is rejected with `POLICY_DOWNGRADE_REJECTED` — this defends against replay of a genuinely signed but more permissive older policy.
4. **Revocation.** A signed revocation list naming a compromised `POLICY_SIGNING_KEY` or `UPDATE_MANIFEST_KEY` is honored immediately; affected keys are disabled and the system enters `POLICY_PROVISIONING_REQUIRED` (execution limited to `RISK_TIER_0`/`RISK_TIER_1`) until a replacement is installed.
5. **Failure behavior.** Signature failure, missing signature, unknown key, or downgrade attempt ⇒ the change is refused, the previous configuration stays in force, `CONFIG_SIGNATURE_REJECTED` is audited, and if the change was a *security relaxation* the system also enters `SAFE_LOCKDOWN` pending user review.
6. **Session overrides.** `CONFIG_LEVEL_5` overrides cannot relax `CONFIG_LEVEL_2` or `CONFIG_LEVEL_3` constraints and cannot disable signature verification; they are in-memory only and cannot persist.

---

## 4. CONFIGURATION LEVEL NAMESPACE

The precedence hierarchy is the `CONFIG_LEVEL_*` namespace (`CONFIG_LEVEL_1` … `CONFIG_LEVEL_5`) and is not a risk tier. See ARCHITECTURE_SECURITY.md §5.6 for the canonical namespace table.
