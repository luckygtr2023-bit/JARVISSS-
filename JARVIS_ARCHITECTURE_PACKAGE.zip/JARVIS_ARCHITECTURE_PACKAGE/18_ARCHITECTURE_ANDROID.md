# ANDROID COMPANION SUBSYSTEM ARCHITECTURE
Document Identifier: JARVIS-ARCH-017
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CRYPTOGRAPHIC PAIRING & IDENTITY

The Android Companion connects as an authenticated out-of-band peripheral interface.

```text
   Host (Desktop)                                Android Companion
         |                                               |
         | 1. Generate Ephemeral QR Code                |
         |    (Host Ed25519 PubKey, Nonce, IP/Port)      |
         +---------------------------------------------->|
         |                                               | 2. Scan QR & Generate
         |                                               |    Device Keypair
         | 3. Out-of-Band Noise Protocol Handshake       |
         |<=============================================>|
         |                                               |
         | 4. Store Pinned Device Public Key             | 4. Store Pinned Host
         |    Issue Paired Device Certificate            |    Public Key
         +-----------------------------------------------+
```


---

## 2. MUTUAL AUTHENTICATION & TRANSPORT

* Transport: Direct LAN WebSocket connection protected via the Noise Protocol Framework (Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s). If out-of-home, traffic routes through an E2EE relay server with zero-knowledge packet forwarding.
* Heartbeat & Expiry: Active sessions exchange keep-alive heartbeats every 15 seconds. If no heartbeat is received for 45 seconds, the session drops, and any active confirmation challenges assigned to the device are revoked.

---

## 3. REMOTE INTENT & CONFIRMATION PROTOCOL

1. High-Risk Authorizations: `RISK_TIER_3` and `RISK_TIER_4` confirmation prompts dispatched to the Android device require local biometric authentication (Android `BiometricPrompt` with hardware-backed KeyStore signing) before the approval token is returned to the desktop.
   * The approval token is bound to the desktop-issued `challenge_binding` hash (op id, resource keys, body digest, expiry). The companion cannot alter, re-scope, or replay it; a token presented against a different binding is rejected by `SYS-SEC` and logged as `SECURITY_ANOMALY_ANDROID_BINDING_MISMATCH`.
   * Ambiguity resolution actions (`CONFIRM_COMPLETED`, `CONFIRM_FAILED`, `SAFE_REPLAN`, `ABANDON`) may also be authorized from the companion, with the same biometric requirement and the same binding rule.
   * A compromised companion can at worst authorize an action the *user* is shown and would have to approve for real — it has no authority to mint challenges, alter scopes, or execute desktop capabilities (see §2).
2. Architectural Boundary: The Android companion is an input/output peripheral. It cannot execute desktop capabilities directly, modify policies, or bypass Core security rules.
