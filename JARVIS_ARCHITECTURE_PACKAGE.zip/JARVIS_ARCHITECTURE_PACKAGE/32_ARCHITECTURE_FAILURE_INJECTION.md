# FAILURE INJECTION & CHAOS TESTING SPECIFICATION
Document Identifier: JARVIS-ARCH-031
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. CHAOS TESTING HARNESS

To validate system resilience, all components must pass automated chaos injection suites prior to production sign-off.

```text
   +-------------------------------------------------------+
   |             Chaos Orchestrator Harness                |
   +-------------------------------------------------------+
        |                     |                       |
        v                     v                       v
[Fault Injector]      [State Observer]       [Assertion Engine]
- Process Kill        - IPC Bus Sniffer      - Invariant Verifier
- Memory Corruption   - Audit Log Reader     - State Machine Prover
- Network Delay/Drop  - DB Journal Scanner   - Recovery Timer
```


---

## 2. FAULT INJECTION TEST MATRIX

| Test ID | Injection Target | Injected Fault Mechanism | Expected System Response | Invariant Checked |
| :--- | :--- | :--- | :--- | :--- |
| `FIT-01` | Core Orchestrator | `kill -9` during active execution of Plan Node. | Worker processes killed by OS Job Object; Core recovers via SQLite WAL on reboot; Task marked `AMBIGUOUS_HALTED`. | No orphan processes; no unlogged execution. |
| `FIT-02` | Capability Worker | Inject a 10,000 ms delay during a physical file write. | Execution Controller times out and **requests** an epoch increment at `SYS-FCB`; the broker applies it durably and purges staging; the delayed worker's `COMMIT` is rejected `FENCE_REJECTED` and the target is unchanged; a fresh worker is spawned under a new grant. | Fencing epoch integrity and the single-commit-authority claim (`SC-01`). |
| `FIT-03` | Audit Log Ledger | Flip random bits in `audit.log` during runtime. | On next append/boot, SHA-256 verification fails; Core enters `SAFE_LOCKDOWN`; halts capability dispatch. | Audit tamper resistance. |
| `FIT-04` | AI Model Provider | Return HTTP 500 followed by garbage token stream. | Constrained decoder rejects syntax; circuit breaker trips; fallback to local model or clean failure. | Zero unhandled crashes; schema fidelity. |
| `FIT-05` | Windows Pipe IPC | Inject duplicated message frame with old nonce. | IPC receiver drops packet; emits replay alert; sequence counter remains monotonic. | Replay protection invariant. |
| `FIT-06` | Task Planner | Inject synthetic goal that generates cyclic DAG. | DAG compiler detects cycle; rejects plan before submission to policy; returns planning error. | Directed Acyclic Graph invariant. |
| `FIT-07` | Browser Daemon | Inject a malicious webpage containing prompt injection. | Sanitization reduces carriers; content is taint-labelled; the model's output cannot populate an authority-bearing field; any proposed action still passes schema, capability, scope, policy, and confirmation. **The test asserts containment, not that the model ignores the text.** | Prompt-injection containment (never "elimination"). |
| `FIT-08` | Android Gateway | Sever the network connection during biometric confirmation. | The companion session drops after 45 s of missed heartbeats and the challenge bound to that device is revoked; the task stays in `AWAITING_CONFIRMATION` and a fresh challenge is issued to the desktop channel (`CHALLENGE_EXPIRED`). It reaches `CANCELLED` only through `CHALLENGE_WITHDRAWN` (no authenticated channel at all) or an explicit `USER_DENY` — an interrupted confirmation is **never** read as approval, and never as a denial. | Fail-safe confirmation invariant (absence of evidence is not consent). |

---

## 3. ADVERSARIAL REGRESSION SCENARIOS (IDs `SC-01` … `SC-30`)

Scenario IDs are `SC-01` … `SC-30`, numbered in the order of the table below. They are distinct from the `FIT-*` fault-injection tests in §2: `FIT-*` injects a fault into a component, while `SC-*` exercises a complete adversarial path across components and asserts the end-to-end outcome. Every `SC-*` row is a release gate for version 1.0.0-LOCK-CANDIDATE.

Each scenario is stated as: **attack -> expected behaviour -> authoritative enforcement -> resulting state -> audit event -> recovery**. These 30 scenarios are the regression gate for the audit loop; any future architecture change must re-run them.

| # | Attack / Scenario | Expected Behaviour | Authoritative Enforcement | Resulting State | Audit Event | Recovery |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Stale worker after cancellation | Worker's `COMMIT` is refused; target untouched | `SYS-FCB` epoch check at commit | `CANCELLED` (target provably unchanged) | `FENCE_REJECTION`, `LEASE_REVOKED` | Worker reaped; staging purged; task cancelled |
| 2 | Stale worker after Core crash | No write reaches the target; worker dies with the Job Object | Job Object `KILL_ON_JOB_CLOSE` + `SYS-FCB` epoch ledger | Tasks classified by fenceability | `WORKER_RECLAIMED`, `RECOVERY_SUMMARY` | Reconciliation per `ARCHITECTURE_RECOVERY.md` §4 |
| 3 | Worker ignores cancellation | No resource effect; worker may keep burning CPU | `SYS-FCB` refuses every commit; CPU quota enforced by Job Object | Task cancelled; worker terminated | `WORKER_TERMINATION_FORCED` | Job Object purge; no resource repair needed |
| 4 | Poisoned capability manifest (claims idempotent/abortable/simulatable) | Claims inert; capability stays `ASSURANCE_DECLARED` | `SYS-TCR` write authority is `SYS-SEC` only | Capability admitted at low privilege or rejected | `ASSURANCE_ASSIGNED`, `ASSURANCE_DOWNGRADED` | Review pipeline; no retry eligibility granted |
| 5 | Non-idempotent remote operation, connection lost | No retry, no inference of success | `OperationLedger` state `AMBIGUOUS` + reliability retry gate | `AMBIGUOUS_HALTED` | `EXTERNAL_COMMIT_ATTEMPTED`, `OP_ID_AMBIGUOUS_BLOCKED` | Human resolution with external reference |
| 6 | Duplicate request across two different tasks | Second request attaches to the same logical operation | `op_id` excludes `TaskID`; `OperationLedger` lookup | One execution, two attributions | `OP_ID_REUSED` | None required; result shared |
| 7 | Ambiguous network response | Treated as indeterminate, never as failure | `SYS-VERIFY` verdict `INDETERMINATE` | `AMBIGUOUS_HALTED` | `AMBIGUITY_ENTERED` | Human resolution; provider receipt reconciliation |
| 8 | Browser renderer compromise | Attacker gains no cookies; cannot mint a lease; egress allowlisted | `SYS-CRED` credential confinement + `ActionLease` requirement | Leased session revoked | `CREDENTIAL_ACCESS_DENIED`, `CREDENTIAL_SESSION_REVOKED` | Broker rotates session material; profile terminated |
| 9 | Malicious webpage issues state-changing POST | Request has no `ActionLease` or a mismatched body hash -> refused | `SYS-CRED` Authenticated Request Proxy | POST blocked | `BROWSER_NAVIGATION_BLOCKED` or `CREDENTIAL_ACTION_LEASE_MINTED` denial | Session lease narrowed or revoked |
| 10 | Prompt injection in a web page | Proposal only; authority-bearing fields unaffected | Schema -> taint -> capability -> scope -> policy pipeline | Task continues with a bounded proposal | `SECURITY_ANOMALY_INJECTION_ATTEMPT` | None needed beyond normal policy evaluation |
| 11 | OCR / screenshot prompt injection | Identical treatment to web text (`PROVENANCE_UNTRUSTED_CONTENT`) | Taint validator on vision-derived text | Proposal only | `SECURITY_ANOMALY_INJECTION_ATTEMPT` | None needed |
| 12 | Malicious plugin | Blocked at AppContainer boundary; capability calls policed | AppContainer + protected-DACL data dir + Core broker | Plugin terminated | `PLUGIN_SANDBOX_ACL_MISMATCH` | Plugin quarantined; user notified |
| 13 | Plugin data isolation breach attempt | Access to another plugin's directory or a user path denied | ACL with a per-plugin container SID; reparse-point creation denied | Attempt fails, plugin flagged | `PLUGIN_SANDBOX_ACL_MISMATCH` | Reinstall required after review |
| 14 | Rogue same-user IPC client | Connection refused; peer unverifiable | DACL + `GetNamedPipeClientProcessId` + signature + integrity check | No session established | `SECURITY_ANOMALY_IPC_PEER` | Operator review; audit entry retained |
| 15 | Core memory scraping by a debug-privileged process | Documented limitation: memory is readable, but no long-lived secret or signing key is present, and authorization is verified at the enforcement point rather than in Core memory | Key custody outside Core (`SYS-CRED`, TPM); `SYS-FCB` re-verifies every grant independently | The read may succeed; it yields no credential, no signing key, and no forgeable authorization | No event is emitted (a same-user debug read is, by declaration, outside the enforced boundary) | Rotate any session material that was resident; no key compromise is implied; the limitation is re-stated to the user on request |
| 16 | Forged authorization token | Signature verification fails at the enforcement point | `SYS-SEC` token signature checked by `SYS-FCB` | Dispatch refused | `SECURITY_ANOMALY_TAINT_IN_AUTHORITY_FIELD` | Credentials not consumed; source investigated |
| 17 | Replayed confirmation | Token single-use and bound to the challenge hash | `SYS-SEC` challenge consumption; `SYS-FCB` `intent_token` single use | Replayed response rejected | `CHALLENGE_REPLAY_REJECTED` | User re-prompted if the operation is still wanted |
| 18 | Resource changed between authorization and execution | Dispatch is refused or re-authorized | `SYS-FCB` scope + resource-hash comparison | `SCOPE_MISMATCH` or fresh challenge | `SCOPE_MISMATCH` | Replan within `AuthorizedScope` |
| 19 | Audit ledger rollback (valid chain, older file) | Detected by TPM NV counter mismatch | `SYS-AUD` boot verification | `SAFE_LOCKDOWN` | `AUDIT_ROLLBACK_DETECTED` | Operator review; no silent repair permitted |
| 20 | Audit anchor key compromise | Anchor fingerprint change without a recorded rotation is detectable | Anchor key certified by the offline root | `AUDIT_DEGRADED` on detection | `AUDIT_KEY_ROTATED` (attacker), `AUDIT_ANCHOR_VERIFIED` (verifier) | Rotate anchor key; treat post-compromise anchors as unverifiable |
| 21 | Core startup worker race | Only orphaned workers are killed; mid-handshake workers survive | `IsProcessInJob` + `SpawnRegistry` + bootstrap token table + grace window | No legitimate worker killed | `WORKER_RECLAIMED` | None |
| 22 | Database failure (corruption or lock) | Storage subsystem refuses to serve; no partial writes | SQLite WAL + `integrity_check` + single-writer discipline | Task `FAILED` or `AMBIGUOUS_HALTED` depending on fenceability | `RECOVERY_SUMMARY`, `AMBIGUITY_ENTERED` | Restore from WAL; if unrecoverable, human resolution with explicit data loss notice |
| 23 | Verification failure | Commit is not treated as success | `SYS-VERIFY` cross-check matrix | `UNSATISFIED` -> replan (retry-eligible only) | `POLICY_DECISION` | Delta replan within scope; otherwise escalate |
| 24 | Simulation mismatch with reality | Simulation is advisory; observed reality wins | `SYS-VERIFY` | Task continues on observed facts; discrepancy recorded | `POLICY_DECISION` | Re-simulate or replan; no authorization relaxation |
| 25 | Android companion compromise | Cannot forge a challenge, widen scope, or execute directly | Challenge binding + biometric + `SYS-AND` peripheral boundary | Requests rejected | `SECURITY_ANOMALY_ANDROID_BINDING_MISMATCH` | Unpair, rotate pairing secrets, re-establish |
| 26 | Credential exposure attempt (log, prompt, telemetry, memory) | Secret never leaves the broker; redaction filter strips any residue | `SYS-CRED` no-getter API + redaction filter | No secret in any record | `CREDENTIAL_ACCESS_DENIED` | Rotate the exposed credential if any residue is found |
| 27 | Malicious external content (document, email, file) | Parsed as data; taint labels applied; no authority path | Sanitization + taint + schema validation | Proposal only | `SECURITY_ANOMALY_INJECTION_ATTEMPT` | None needed |
| 28 | Clock manipulation (set backwards) | No expiry extended; challenges re-issued | Monotonic elapsed time + HLC cross-check | Operations unaffected; anomaly recorded | `SECURITY_ANOMALY_CLOCK_DRIFT` | None needed; user informed |
| 29 | Worker crash after a side effect | Commit receipt proves mutation; not re-executed | `SYS-FCB` `CommitRecord` + verification observation | `SATISFIED` or `UNSATISFIED`, never a blind retry | `FENCED_COMMIT_APPLIED`, `AMBIGUITY_ENTERED` | Verify and continue, or resolve as ambiguous |
| 30 | Browser action with unknown outcome | Never assumed successful | `SYS-VERIFY` on the leased session; `NON_FENCEABLE_EXTERNAL` classification | `AMBIGUOUS_HALTED` | `AMBIGUITY_ENTERED` | Human resolution; session lease revoked if compromised |

### 3.1 Mapping to automated tests

Scenarios 1-30 map to the fault-injection matrix above and to `FIT-01` … `FIT-08`; scenarios 9-30 additionally require the interface conformance suites listed in `ARCHITECTURE_TEAM_BOUNDARIES.md`. Scenario 15 has **no** automated test that can pass — it is a documented limitation and its "verification" is the audit assertion that no long-lived secret exists in Core memory, checked by a periodic key-inventory scan.
