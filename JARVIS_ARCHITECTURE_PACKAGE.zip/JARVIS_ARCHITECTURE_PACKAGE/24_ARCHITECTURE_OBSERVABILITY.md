# OBSERVABILITY & TELEMETRY SPECIFICATION
Document Identifier: JARVIS-ARCH-023
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. DISTRIBUTED TRACING & CORRELATION

JARVIS implements OpenTelemetry-compatible distributed tracing across all out-of-process boundaries:
```text
[User Request] -> Trace ID: 4bf92f3577b34da6a3ce929d0e0e4736
|
+---> [SYS-CORE: Dispatch Task] --------> Span ID: 00f067aa0ba902b7
|
+---> [SYS-PLAN: Compile DAG] ----------> Span ID: 5fb397be34d23b0f
|
+---> [SYS-SEC: Evaluate Policy] -------> Span ID: 377173483a9202b8
|
+---> [SYS-EXEC: Worker Invocation] ----> Span ID: 2b10ee410e31e592
```


---

## 2. METRICS & PERFORMANCE PROFILES

The Telemetry Engine tracks real-time performance counters exposed via local named pipes:
* `task_execution_duration_seconds`: Histogram measuring execution latency per capability.
* `model_token_consumption_total`: Monotonic counter tracking input/output tokens per provider.
* `active_worker_count`: Gauge tracking running child processes and Job Object memory usage.
* `verification_failure_ratio`: Ratio of postcondition failures to successful executions.

---

## 3. REAL-TIME SECRET & PII SANITIZATION

All log entries, traces, and metric labels pass through a real-time redaction filter:
* Regex-Based Scrubbing: Patterns for credit cards, Social Security Numbers, JWTs, and bearer tokens.
* Dynamic Secret Masking: Any string matching active secrets in the Secret Manager is replaced with `[REDACTED_SECRET]`.
