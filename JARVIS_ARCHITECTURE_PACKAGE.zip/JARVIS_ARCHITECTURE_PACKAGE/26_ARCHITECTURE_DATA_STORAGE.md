# DATA STORAGE & PERSISTENCE ARCHITECTURE
Document Identifier: JARVIS-ARCH-025
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. STORAGE REPOSITORY MAP

System persistence is partitioned across dedicated, purpose-built engines:

| Data Category | Target Engine | Encryption | Access Policy |
| :--- | :--- | :--- | :--- |
| Core Task State & DAGs | SQLite (WAL Mode) | DPAPI / AES-256 | Core Orchestrator exclusively |
| Fencing Epoch Ledger (`fencing.db`) | SQLite (WAL Mode) | DPAPI / AES-256 | `SYS-FCB` exclusively (write); Core via admin endpoint |
| Secret Store & Session Material | TPM / Credential Manager | TPM-bound DPAPI | `SYS-CRED` exclusively (no getter API) |
| Trust Classification Registry | SQLite (WAL Mode) | DPAPI / AES-256 | `SYS-SEC` exclusively (write); read via CTR-015 |
| Audit Ledger | Append-Only Flat File | SHA-256 Chained + TPM-anchored Merkle roots | Append: all components via the append-only endpoint. Read: `SYS-SEC` and the User Console only, through a separately DACL'd read endpoint (XD-05, CTR-016) |
| Semantic Memory Vectors| SQLite-vec / Chroma | AES-256 (User Key) | Memory Subsystem exclusively |
| Secrets & Tokens | Windows Credential Manager | OS-Level DPAPI | Security Kernel exclusively |
| Workspaces & Artifacts | Local NTFS Filesystem | Windows EFS / NTFS ACLs | Execution Controller & Workers |

---

## 2. CONCURRENCY & WRITE-AHEAD LOGGING (WAL)

All SQLite databases are configured in Write-Ahead Logging (`PRAGMA journal_mode=WAL;`) with synchronous commit flags (`PRAGMA synchronous=NORMAL;`).
* Single Writer, Multiple Readers: Writes are serialized through the owning subsystem's single-threaded event loop, avoiding database lock contention.
* Zero Corruption Assurance: Automated database integrity checks (`PRAGMA integrity_check;`) execute on every cold startup.
