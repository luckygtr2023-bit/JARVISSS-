# INTER-PROCESS COMMUNICATION (IPC) SPECIFICATION
Document Identifier: JARVIS-ARCH-018
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. TRANSPORT & SESSION BOOTSTRAP

All inter-process communication on the Windows host relies on Windows Named Pipes with Discretionary Access Control Lists (DACLs) restricted strictly to the current user SID and Local System.
```text
Core Orchestrator Worker Process
| |
| 1. Create Named Pipe with DACL |
| \.\pipe\jarvis-worker-pool-{UUID} |
| |
| 2. Spawn Worker; Handshake Token via INHERITED HANDLE |
+---------------------------------------------------------->|
| |
| 3. Worker Connects to Named Pipe |
|<==========================================================+
| |
| 4. Mutual Handshake: Exchange Nonces & Derive Session Key |
|<=========================================================>|
| |
| 5. Core Transmits Fenced Execution Grants |
+---------------------------------------------------------->|
```


---

## 2. PEER VERIFICATION & PROTOCOL DEFENSES

1. Process ID & Integrity Validation: Upon receiving a pipe connection, the Core uses Win32 `GetNamedPipeClientProcessId` to inspect the connecting process. It validates the binary path, digital signature, and Windows Integrity Level of the client PID before completing the handshake.
2. Replay Protection: Every IPC frame encapsulates a strictly increasing 64-bit sequence number and a 12-byte cryptographic nonce. Messages received with stale sequence numbers are dropped immediately.
3. Malformed Message Defense: Payload schemas are validated using zero-allocation stream validators. Any malformed frame, or any frame exceeding `MAX_FRAME_SIZE = 4 MiB` (ARCHITECTURE_CONTRACTS.md §1.2), triggers immediate pipe termination, emits `SECURITY_ANOMALY_OVERSIZE_FRAME`, and restarts the peer.
4. Pipe Hardening: every server pipe instance is created with `FILE_FLAG_FIRST_PIPE_INSTANCE` (so a squatter cannot pre-create the name) and an explicit DACL that names the current user SID, Local System, and — for worker pipes — only the AppContainer/job SIDs that are members of this JARVIS instance. `Everyone`, `Authenticated Users`, and `Users` are never in a JARVIS pipe DACL.
5. Bootstrap Token Channel (F-A-18): the handshake token is delivered through an **inherited anonymous pipe handle** using `STARTUPINFOEXW` + `PROC_THREAD_ATTRIBUTE_HANDLE_LIST`. It is never passed on the command line, never placed in the environment, and never written to disk. The token is single-use, expires after 30 s, is bound to `(child_pid, child_creation_time, worker_pubkey)`, and the channel is destroyed after first use. Any token presented twice is treated as an attack: `SECURITY_ANOMALY_BOOTSTRAP_REPLAY`.
6. Worker Authentication (F-A-12 / F-A-14): after bootstrap, each worker generates an Ed25519 keypair internally; the public key travels to `SYS-CORE`/`SYS-FCB` over the bootstrap channel. Every subsequent frame is signed (`worker_signature`) over `(method, frame_nonce, payload_sha256)`. A frame whose signature is absent, invalid, or not bound to the current worker incarnation is dropped without processing.
7. Same-user adversary: the DACL and signature checks do not make a same-user process trustworthy — they make it **identifiable and accountable**. A same-user attacker that can read process memory is a documented boundary limitation (ARCHITECTURE_SECURITY.md §4.3), not a defended condition.
