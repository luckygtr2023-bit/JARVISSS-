# SUBSYSTEM COMPONENT SPECIFICATION
Document Identifier: JARVIS-ARCH-001
Version: 1.0.1-LOCK-CANDIDATE
Status: LOCK CANDIDATE — pending independent adversarial audit (DeepSeek)

---

## 1. COMPONENT TAXONOMY & BOUNDARIES

Every component within the JARVIS architecture is formally specified with strict boundaries of responsibility, data ownership, permitted callers, and isolation parameters.

```text
   +-------------------------------------------------------+
   |               Frontend Layer (Untrusted)              |
   |  Desktop UI  |  Voice Overlay  |  Android Companion   |
   +-------------------------------------------------------+
                               | (Bounded IPC / TLS)
                               v
+---------------------------------------------------------------------+
| Core Subsystem (Trusted Host) |
| +--------------------+ +------------------+ +-----------------+ |
| | Request Dispatcher | | Session Manager | | Security Kernel | |
| +--------------------+ +------------------+ +-----------------+ |
| +--------------------+ +------------------+ +-----------------+ |
| | Task DAG Engine | | Replan Engine | | Trust Registry | |
| +--------------------+ +------------------+ +-----------------+ |
+---------------------------------------------------------------------+
| |
v v
+------------------------------+      +------------------------------+
| SYS-FCB Fencing & Commit     |      | SYS-CRED Credential Broker   |
| Broker (Medium Integrity)    |      | (Medium Integrity)           |
| - Sole OwnershipEpoch owner  |      | - Sole secret custodian      |
| - Sole resource write path   |      | - Auth request proxy         |
+------------------------------+      +------------------------------+
|                                     |
v                                     v
+---------------+ +-----------------+ +-----------------------+
| AI & Planning | | Execution Pool  | | Sensors & Context     |
| - AI Gateway | | - Win32 Worker | | - Screen Capture Daemon|
| - DAG Planner| | - Browser Daemon| | - Audio Capture Daemon|
| - Sanitizer | | - Plugin Worker | | - Memory Subsystem |
+---------------+ +-----------------+ +-----------------------+
```


---

## 2. DETAILED MODULE SPECIFICATIONS

### 2.1 Core Orchestrator (`SYS-CORE`)
* Purpose: Central authoritative controller for system lifecycle, session context, request intake, and execution sequencing.
* Responsibilities:
  * Ingest and validate incoming requests from presentation frontends.
  * Coordinate calls to the Planning Plane, Security Plane, and Execution Plane.
  * Enforce execution state transitions and prevent illegal state mutations.
  * Request cryptographic `OwnershipGrants` from `SYS-FCB` and track active leases. (The Core does **not** mint epochs: the `EpochLedger` is owned solely by `SYS-FCB`, per F-A-01.)
* Non-Responsibilities: Direct invocation of operating system APIs; raw model inference; UI rendering; direct database storage manipulation.
* Inputs: Canonical Request Objects, Execution Acknowledgments, State Query Requests.
* Outputs: Validated Execution Tokens, State Change Events, User Prompts.
* Owned State: In-memory Task State Registry, Active Lease Table, System Runlevel State.
* Dependencies: Security Kernel (`SYS-SEC`), Audit Engine (`SYS-AUD`).
* Permitted Callers: Frontend Adapters via authenticated IPC, Android Gateway via Mutual TLS.
* Forbidden Callers: Execution Workers, Tool Adapters, External Web Clients, AI Models.
* Trust Level: KERNEL (Highest Local System Trust).
* Security Boundary: Runs in isolated Medium-Integrity OS process; DACL-restricted IPC endpoint.
* Failure Modes: Core process crash, deadlock, lease exhaustion.
* Recovery Behavior: Reads SQLite write-ahead log upon restart, reconstructs task DAG states, marks unverified executions as `AMBIGUOUS`, reclaims worker handles.

### 2.2 Security Kernel & Policy Engine (`SYS-SEC`)
* Purpose: Authoritative Policy Decision Point (PDP) and Policy Enforcement Point (PEP).
* Responsibilities:
  * Evaluate candidate operations against declarative static policies and dynamic runtime state.
  * Classify candidate actions into the canonical execution-risk namespace `RISK_TIER_0` … `RISK_TIER_4` (see ARCHITECTURE_SECURITY.md §5.6).
  * Enforce multi-factor and out-of-band confirmation requirements.
  * Cryptographically sign `AuthorizationGrants`.
* Non-Responsibilities: Executing tools, parsing natural language, modifying user settings without audit.
* Inputs: Tool Invocation Proposal, Active Security Profile, Session Context.
* Outputs: `AuthorizationDecision` (`ALLOW`, `DENY`, `CONFIRM_REQUIRED`), Cryptographic Signature Token.
* Owned State: Policy Rule Base, Active Confirmation Challenge Table, Risk Tier Map.
* Dependencies: Cryptographic Hardware/OS Keystore (DPAPI/TPM), Audit Engine (`SYS-AUD`).
* Permitted Callers: Core Orchestrator (`SYS-CORE`) exclusively.
* Forbidden Callers: All other subsystems.
* Trust Level: KERNEL.
* Failure Modes: Policy evaluation timeout, corrupt policy database, keystore unavailability.
* Recovery Behavior: Fails CLOSED. If policy cannot be verified, default decision is `DENY`.

### 2.3 AI Gateway & Constrained Decoding Router (`SYS-AI`)
* Purpose: Provider-agnostic inference router, format enforcer, and sanitization boundary.
* Responsibilities:
  * Route inference requests to local models (Ollama/llama.cpp) or remote cloud providers (Anthropic, OpenAI) based on latency, privacy classification, and availability.
  * Enforce strict JSON schema conformance using grammar-guided decoding (e.g., GBNF grammars, JSON schema constraints).
  * Redact sensitive personal data and session secrets from prompt payloads prior to egress.
* Non-Responsibilities: Authorizing tool execution, committing memory records, generating system commands outside schemas.
* Inputs: Canonical Prompt Context, Response JSON Schema, Privacy Budget.
* Outputs: Structured, Schema-Validated Plan Projections or Natural Language Responses.
* Owned State: Provider Health Metrics, Rate Limit Token Buckets, In-Flight Inference Contexts.
* Dependencies: Local/Cloud Model Endpoints, PII Sanitizer.
* Permitted Callers: Task Planner (`SYS-PLAN`), Core Orchestrator (`SYS-CORE`).
* Forbidden Callers: Execution Workers, Presentation Frontends directly.
* Trust Level: UNTRUSTED / PROPOSAL ENGINE.
* Failure Modes: Upstream provider outage, malformed token streams, prompt injection evasion.
* Recovery Behavior: Circuit breaker trips to secondary provider or falls back to local degraded model.

### 2.4 Task Planner & Replanning Engine (`SYS-PLAN`)
* Purpose: Decomposes natural language user goals into valid, executable Directed Acyclic Graphs (DAGs) of discrete tool operations.
* Responsibilities:
  * Transform `GoalSpecification` into candidate `PlanDAG`.
  * Validate node dependencies, cycle freedom, parameter types, and resource key declarations.
  * Ingest node verification failures and synthesize surgical delta-replanning DAGs without invalidating unaffected nodes.
* Non-Responsibilities: Direct invocation of tools; evaluating security permissions; confirming actions with users.
* Inputs: Verified User Intent, Environmental Observation, Capability Registry.
* Outputs: Candidate `PlanDAG` structures.
* Owned State: Temporary planning graphs, replan iteration counters.
* Dependencies: AI Gateway (`SYS-AI`), Capability Registry (`SYS-TOOL`).
* Permitted Callers: Core Orchestrator (`SYS-CORE`).
* Forbidden Callers: Capability Workers, External Interfaces.
* Trust Level: UNTRUSTED PROPOSAL GENERATOR.
* Failure Modes: Generation of cyclic graphs, invalid tool parameters, infinite replan loops.
* Recovery Behavior: Cycle rejection at validation phase; hard ceiling on replan attempts (max 3) before escalating to user intervention.

### 2.5 Execution Controller (`SYS-EXEC`)
* Purpose: Authoritative manager of worker processes, tool dispatch, and lease *acquisition*. It is **not** a fencing authority.
* Responsibilities:
  * Spawn, monitor, and terminate sandboxed worker processes.
  * Request `OwnershipGrant`s (including epoch allocation) from the Fencing & Commit Broker (`SYS-FCB`) for the resource keys a node will touch.
  * Carry the granted `lease_id`, `epoch_id`, `grant_token`, and `authorized_scope_hash` into the dispatch frame (`CTR-002`).
  * Terminate stale or unresponsive workers via OS Job Objects, and request epoch revocation through the FCB admin endpoint.
* Authority note (F-A-01): `SYS-EXEC` **cannot** mint, cache, or predict an `OwnershipEpoch`, and cannot commit a side effect. Epoch authority and commit authority belong solely to `SYS-FCB`.
* Non-Responsibilities: Deciding if an action is safe (delegated to `SYS-SEC`); generating tool arguments (delegated to `SYS-PLAN`); establishing whether an action succeeded (delegated to the Verification Plane, `SYS-VERIFY`).
* Related component — Verification Plane (`SYS-VERIFY`): a plane of the Core kernel, not a separate process. It is the **sole authority for fact establishment** (`ARCHITECTURE_VERIFICATION.md`): it converts observations into `SATISFIED` / `UNSATISFIED` / `INDETERMINATE` verdicts, consumes `CommitRecord`s as evidence of mutation rather than evidence of success, and holds no commit authority of its own. A verification verdict may gate downstream nodes; it may never mutate a resource, and it may never resolve an ambiguous outcome.
* Inputs: Authorized Plan Node, Cryptographic `AuthorizationGrant`.
* Outputs: Execution Result, Hardware Resource Telemetry, Failure Alerts.
* Owned State: Active Worker Process Pool, leased resource key set (mirror only; the authoritative `EpochLedger` is owned by `SYS-FCB`).
* Dependencies: Core Orchestrator (`SYS-CORE`), OS Process Subsystem (Win32 Job Objects).
* Permitted Callers: Core Orchestrator (`SYS-CORE`).
* Forbidden Callers: Presentation Layer, Worker Processes (downstream).
* Trust Level: TRUSTED HOST.
* Failure Modes: Worker process hang, memory leak, IPC disconnect.
* Recovery Behavior: Worker termination via `TerminateJobObject`; epoch revocation **requested** from `SYS-FCB` (the broker performs it); resource lease rollback; any execution with an unknown commit outcome is reported to `SYS-CORE` as `INDETERMINATE` and never retried automatically.

### 2.6 Capability Registry & Tool Adapters (`SYS-TOOL`)
* Purpose: Central directory and execution harness for all system capabilities (filesystem, process control, system settings, application automation).
* Responsibilities:
  * Expose immutable tool manifests detailing inputs, outputs, side-effect classifications, and required permissions.
  * Execute tool logic inside bounded worker environments.
  * Return structured observations and execution metadata to the Execution Controller.
* Non-Responsibilities: Self-authorization, direct network calls outside sandboxed channels, persistence of execution state.
* Inputs: Validated Execution Token, Input Parameters, Fencing Token.
* Outputs: Raw Execution Observation (`ToolResult`).
* Owned State: Transient tool runtime state.
* Dependencies: Underlying OS APIs (Win32, COM, PowerShell), External Binaries.
* Permitted Callers: Execution Controller (`SYS-EXEC`) exclusively.
* Forbidden Callers: AI Gateway, Planner, Frontend UI.
* Trust Level: BOUNDED SANDBOX (varies by `RISK_TIER`).
* Failure Modes: Unhandled exception in tool, native binary crash, target application hang.
* Recovery Behavior: Encapsulate crash in structured `ToolResult` with error category, release OS handles, exit worker.

### 2.7 Windows Platform Controller (`SYS-WIN`)
* Purpose: Provides deep semantic and visual automation of the Windows 11 desktop environment.
* Responsibilities:
  * Query and manipulate application UI elements using Microsoft UI Automation (UIA) COM interfaces.
  * Enforce canonical path resolution and directory boundary validation for filesystem access.
  * Manage application lifecycles (launch, activate, minimize, terminate) using Win32 APIs wrapped in Job Objects.
* Non-Responsibilities: Direct user input spoofing without authorization; bypassing Windows UAC or security controls.
* Inputs: Window Handles (HWND), UIA Search Criteria, Canonical Path Directives.
* Outputs: Accessibility Tree Snapshots, Process Handles, Interaction Acknowledgments.
* Owned State: Cached HWND tables, active UIA event listeners.
* Dependencies: Windows OS Subsystems (User32, Oleacc, UIAutomationCore).
* Permitted Callers: Execution Controller (`SYS-EXEC`) via local worker.
* Forbidden Callers: Untrusted plugins, remote callers.
* Trust Level: TRUSTED WORKER.
* Failure Modes: COM interface freeze, UIA tree mutation during traversal, DPI scaling coordinate misalignment.
* Recovery Behavior: Fallback from semantic UIA to OCR/Computer Vision coordinate targeting; re-enumeration of window handles.

### 2.8 Sandboxed Browser Daemon (`SYS-BROWSER`)
* Purpose: Isolated, multi-profile automation of modern web browsers via the Chrome DevTools Protocol (CDP).
* Responsibilities:
  * Manage distinct browser storage profiles (Ephemeral Scraping vs. Authenticated User Session).
  * Execute DOM inspection, navigation, form interaction, and network request interception.
  * Sanitize extracted web content, stripping executable scripts and hidden prompt injection payloads.
* Non-Responsibilities: Exposing user credentials directly to AI models; executing arbitrary unvetted client-side JavaScript.
* Inputs: Navigation Targets, DOM Selectors, Bounded Action Directives.
* Outputs: Sanitized DOM Trees, Text Extractions, Screenshots, Network Audit Logs.
* Owned State: Active CDP WebSocket connections, ephemeral profile directories.
* Dependencies: Chromium / Edge binary, DevTools Protocol engine.
* Permitted Callers: Execution Controller (`SYS-EXEC`).
* Forbidden Callers: AI Gateway, Presentation Layer.
* Trust Level: ISOLATED WORKER (Low Integrity).
* Failure Modes: Browser tab crash, memory exhaustion, malicious script evasion.
* Recovery Behavior: Hard termination of tab/browser process; recreation of ephemeral profile; zero persistence of untrusted state.

### 2.9 Memory & Knowledge Subsystem (`SYS-MEM`)
* Purpose: Encrypted, tiered repository for session, episodic, and long-term semantic knowledge.
* Responsibilities:
  * Store and retrieve user preferences, task histories, and entity associations.
  * Provide vector similarity search across past resolutions with strict privacy filtering.
  * Enforce user-directed cryptographic deletion ("forgetting") of memories.
* Non-Responsibilities: Making execution decisions; bypassing Policy Engine based on stored preferences.
* Inputs: Memory Ingestion Requests, Vector Similarity Queries, Deletion Directives.
* Outputs: Scored Memory Records, Provenance Metadata.
* Owned State: SQLite Relational Database, Vector Indices (Chroma/SQLite-vec), DPAPI Key Wrappers.
* Dependencies: Local Embedding Model, Local Filesystem.
* Permitted Callers: Core Orchestrator (`SYS-CORE`), Planner (`SYS-PLAN`).
* Forbidden Callers: Execution Workers, Presentation Frontend directly.
* Trust Level: TRUSTED DATA STORE.
* Failure Modes: Vector index corruption, cryptographic lock failure, duplicate memory bloat.
* Recovery Behavior: SQLite WAL recovery; rebuild vector index from relational source-of-truth tables.

### 2.10 Android Companion Gateway (`SYS-AND`)
* Purpose: Secure out-of-band communication hub connecting JARVIS host to paired Android devices.
* Responsibilities:
  * Manage cryptographic device pairing via QR-code / out-of-band key exchange.
  * Maintain mutual TLS / Noise protocol authenticated E2EE tunnels.
  * Dispatch push notifications and receive out-of-band user confirmations (biometric/touch).
* Non-Responsibilities: Executing actions locally on the host; granting authorization without host-side policy validation.
* Inputs: Encrypted Network Packets (LAN / Relay), Notification Payloads.
* Outputs: Authenticated Confirmation Responses, Remote Intent Directives.
* Owned State: Paired Device Keystore, Active Session Nonces, Sequence Counters.
* Dependencies: Host Network Stack, Cryptographic Primitives (X25519, ChaCha20-Poly1305).
* Permitted Callers: Core Orchestrator (`SYS-CORE`), Security Kernel (`SYS-SEC`).
* Forbidden Callers: Generic tool workers.
* Trust Level: SECURE PERIPHERAL GATEWAY.
* Failure Modes: Network disconnection, replay attack detection, pairing secret mismatch.
* Recovery Behavior: Session teardown, immediate revocation of ephemeral session keys, requirement for re-handshake.

### 2.11 Tamper-Evident Audit Logger (`SYS-AUD`)
* Purpose: Append-only cryptographic ledger of all system state transitions, commands, decisions, and observations.
* Responsibilities:
  * Ingest audit events and commit them into a SHA-256 hash-chained sequence.
  * Generate periodic cryptographic Merkle anchors signed by a local host key.
  * Verify ledger integrity upon Core boot; alert and lock down if tampering is detected.
* Non-Responsibilities: Scrubbing or editing historical logs; authorizing actions.
* Inputs: Structured Audit Event Records.
* Outputs: Audit Append Receipts, Cryptographic Verification Proofs, Tamper Alerts.
* Owned State: Hash-Chained Audit Ledger Files, Merkle Tree State.
* Dependencies: Local Disk, Cryptographic Signing Key.
* Permitted Callers: All system components via the append-only endpoint `\\.\pipe\jarvis-audit-append` (append only).
* Forbidden Callers: No component may update, delete, compact, or rebuild the ledger — no such API exists. Read access is granted **only** to Security Kernel (`SYS-SEC`) and the User Console, through a separate read endpoint with its own DACL (XD-05; see ARCHITECTURE_DATA_STORAGE.md §1 and CTR-016).
* Trust Level: IMMUTABLE AUDIT KERNEL.
* Failure Modes: Disk full, write failure, hash chain mismatch upon startup.
* Recovery Behavior: System enters SAFE LOCKDOWN if hash validation fails; refuses to execute state-changing actions until resolved.

### 2.11a Storage Subsystem (`SYS-DATA`)

* Purpose: The persistence layer beneath the Core — SQLite WAL databases (task DAGs, operation ledger, fencing epoch ledger, trust registry), the vector index, and the append-only audit ledger files.
* Nature: A library and driver layer hosted **inside** the Core kernel process, not a separate process. It therefore adds no new IPC boundary and no new trust boundary; its callers are the owning components (`SYS-CORE`, `SYS-FCB`, `SYS-AUD`, `SYS-MEM`, `SYS-TCR`).
* Responsibilities: single-writer discipline per database; WAL durability; `synchronous` configuration per store; `integrity_check` on cold start; transactional rollback; documented behaviour when a store is locked, corrupt, or full.
* Non-Responsibilities: deciding what may be written (each owning component authorizes its own writes); committing fenced resources (that is `SYS-FCB` alone); storing credentials (`SYS-CRED` uses the OS keystore/TPM, not this layer).
* Failure Modes: WAL corruption, disk full, locked database, torn write on power loss.
* Recovery Behavior: replay from WAL; if a store is unrecoverable, the affected tasks transition to `FAILED` or `AMBIGUOUS_HALTED` according to fenceability class, with explicit data-loss reporting to the user — never a silent reset.
* Note: `SYS-DATA` was referenced by the dependency graph, the threat model, and the requirements matrix while being absent from this component taxonomy; registered here (repair-cycle finding `CF-11`).

### 2.12 Fencing & Commit Broker (`SYS-FCB`)

* Purpose: The **single authority** for physical commit of fenced resources and for `OwnershipEpoch` values.
* Responsibilities:
  * Own and durably persist the `EpochLedger` (`fencing.db`, SQLite WAL).
  * Issue `OwnershipGrants`; increment epochs on lease expiry, cancellation, timeout, worker death, Core restart, manual revocation, and conflicting writes.
  * Execute the commit protocol (`BEGIN_TXN` / `STAGE_DATA` / `COMMIT` / `ABORT`) as the only holder of writable resource handles.
  * Operate the Input Gate that serializes UI/CDP input injection under lease.
  * Record `CommitRecord`s and emit `FENCED_COMMIT_APPLIED` / `FENCE_REJECTION` audit events.
* Non-Responsibilities: Business logic, planning, policy decisions, model inference, network egress outside brokered egress, parsing user content.
* Inputs: `FencedCommitCall` frames (data plane), `LEASE_REQUEST` / `REVOKE` frames (admin plane).
* Outputs: `OwnershipGrant`, commit receipts, `FENCE_REJECTED` verdicts, ledger state.
* Owned State: `EpochLedger`, `LeaseTable`, `CommitTable`, staging tree, resource handles.
* Dependencies: Local filesystem, `SYS-AUD` (append), `SYS-SEC` (scope verification).
* Permitted Callers: `SYS-CORE` (admin endpoint), worker hosts holding a per-call capability (data endpoint).
* Forbidden Callers: `SYS-AI`, `SYS-PLAN`, `SYS-BROWSER`, plugins, the frontend, memory, any external content path.
* Trust Level: KERNEL-ADJACENT COMMIT AUTHORITY.
* Security Boundary: Own Medium-Integrity process under `MicrosoftSignedOnly` + ACG + CFG mitigations.
* Failure Modes: Broker crash, ledger I/O failure, staging exhaustion.
* Recovery Behavior: Staging purged; ledger replayed from WAL; leases never auto-renewed; unknown commit outcomes reported `INDETERMINATE` to `SYS-CORE` (never guessed).

### 2.13 Credential Broker (`SYS-CRED`)

* Purpose: Hold and apply all long-lived credentials and browser session material; execute authenticated state-changing requests on behalf of a confirmed intent.
* Responsibilities:
  * Store secrets DPAPI/TPM-bound; never expose values to any other process (no getter API).
  * Mint `CredentialSessionLease` and `CredentialActionLease`; apply cookies/headers at request time.
  * Execute the Authenticated Request Proxy gated on a confirmation challenge hash bound to the exact request bytes.
  * Revoke leases and rotate session material on user action, policy verdict, expiry, or anomaly.
* Non-Responsibilities: Navigation policy, DOM interpretation, planning, direct file access outside its profile store.
* Inputs: `CTR-014` calls.
* Outputs: leases, request outcomes (status + response digest, never credential material).
* Owned State: encrypted secret store, browser profile credential material, active lease table.
* Dependencies: Windows Credential Manager / TPM, `SYS-SEC` (ActionLease minting), `SYS-AUD`.
* Permitted Callers: `SYS-CORE` (action execution), `SYS-BROWSER` (session lease acquisition/use within scope).
* Forbidden Callers: `SYS-AI`, `SYS-PLAN`, memory, plugins, the frontend, and any worker other than the brokered browser.
* Trust Level: SECRET-CUSTODY KERNEL.
* Security Boundary: Own Medium-Integrity process, `MicrosoftSignedOnly`, no network listener, no inbound IPC except its DACL'd pipe.
* Failure Modes: store unreadable, TPM unavailable, lease exhaustion, upstream auth rejection.
* Recovery Behavior: Leases dropped on restart (fail closed); re-authentication required; no silent reuse of pre-crash session material.

### 2.14 Trust Classification Registry (`SYS-TCR`) — state of `SYS-SEC`

* Purpose: Hold the assurance level of every `(capability, version, environment)` tuple and the evidence behind it.
* Responsibilities: Record `ASSURANCE_DECLARED` on registration; accept promotions only from a named human reviewer (`TEAM-SEC`) or from automated evidence pipelines with `SYS-SEC` as the writer; auto-downgrade on version, signature, or environment change, on expiry, and on any fencing rejection attributable to the capability.
* Non-Responsibilities: Executing anything; it is pure state + rule evaluation.
* Owned State: assurance records, evidence references, revocation history.
* Permitted Callers: `SYS-EXEC`, `SYS-PLAN`, `SYS-TOOL`, `SYS-SIM` (read via CTR-015).
* Forbidden Callers: capability authors, plugins, `SYS-AI`, the frontend, external content (no write path exists).
* Trust Level: KERNEL.
* Failure Modes: registry unavailable (treated as `ASSURANCE_DECLARED` for everything, i.e. fail closed).
* Recovery Behavior: rebuild from audit ledger; a record that cannot be reconstructed is treated as `ASSURANCE_DECLARED`.
